<?php
   /**
    * Created by PhpStorm.
    * User: Oculus
    * Date: 2/5/2018
    * Time: 5:34 PM
    */
   //~ $results=$this->getAllBrands();
   //~ echo "<pre>";
   //~ print_r($results);
   //~ echo "</pre>";
?>
<?php
// set IP address and API access key  // free account 10.000 requests / mo
/*$ip = '117.96.247.237';
$access_key = '7d8d824e063d12b949b856471dbb0eda';
$ch = curl_init('http://api.ipstack.com/'.$ip.'?access_key='.$access_key.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$json = curl_exec($ch);
curl_close($ch);
$api_result = json_decode($json, true);
$getCity = !empty($api_result['city']) ? $api_result['city'] : '';*/
	
$sell_plugins_url = plugins_url();
?>

<div class="container">
<div class="page-header">
   <h1>5 MINUTES TO YOUR OFFER-START BELOW</h1>
</div>
<div class="row">
   <div class="col-md-12 sell_cars">
      <div class="panel with-nav-tabs panel-default">
         <div class="panel-heading">
            <ul class="nav nav-tabs sell_cars_tab">
               <li class="active col-md-4 basics_information"><a href="#basics_information" data-toggle="tab" class="disabled"><?php echo '<img src="' .$sell_plugins_url.'/selluscars/assets/images/car_icon.png'. '" >'; ?> 1. Vehicle Information</a></li>
               <li class="col-md-4 aboutyou_information"><a href="#aboutyou_information" data-toggle="tab" class="disabled"><?php echo '<img src="' .$sell_plugins_url.'/selluscars/assets/images/about_us_icon.png'. '" >'; ?> 2. About You</a></li>
               <li class="col-md-4 yourneed_information"><a href="#yourneed_information" data-toggle="tab" class="disabled"><?php echo '<img src="' .$sell_plugins_url.'/selluscars/assets/images/your_needs.png'. '" >'; ?> 3. Your Needs</a></li>
            </ul>
         </div>
         <div class="panel-body">
            <div class="tab-content">
               <form action='https://crm.zoho.com/crm/WebToLeadForm' name=WebToLeads1729068000000091137 method='POST' enctype='multipart/form-data' onSubmit='javascript:document.charset="UTF-8"; return checkMandatory()' accept-charset='UTF-8' id="formCars" class="selluscar">
                            <!-- input type='hidden' name='zc_gad' id='zc_gad' value=''/-->
                            <!-- Do not remove this code. -->
                            <input type='text' style='display:none;' name='xnQsjsdp' value='0e54e974881a953f6a65a3db5234c04b5313ade962ff64c04b4efa62c896ba6d' />
                            <input type='hidden' name='zc_gad' id='zc_gad' value='' />
                            <input type='text' style='display:none;' name='xmIwtLD' value='d78cb86f8c0f31762ca7684927cda4541883f5ee99bb7bc88ba91b3718ed9352' />
                            <input type='text' style='display:none;' name='actionType' value='TGVhZHM=' />

                            <input type='text' style='display:none;' name='returnURL' value='https&#x3a;&#x2f;&#x2f;www.selluscars.co.za&#x2f;thank-you&#x2f;' />
                            <!-- Do not remove this code. -->
                            <input type='text' style='display:none;' id='ldeskuid' name='ldeskuid'></input>
                            <input type='text' style='display:none;' id='LDTuvid' name='LDTuvid'></input>
                  <div class="from_inner">
                     <fieldset id="basics_information" class="">
                      
                        <div class="col-12 in-list">
                           <label for="brand" class="col-form-label">Make: </label>
                           <input class="form-control" placeholder="e.g. TOYOTA" type="text" id="brand" onfocus="sortUl('brand','brand_list_ul')" onkeyup="sortUl('brand','brand_list_ul')" name="LEADCF4" value="" autocomplete="off" required>
                           <div id="brand_list" class="list_data"></div>
                        </div>
                        <div class="col-12 in-list">
                           <label for="model" class="col-form-label">Model: </label>
                           <input class="form-control" type="text" id="model" placeholder="e.g. Corolla" name="LEADCF5" value="" onfocus="sortUl('model','model_list_ul')" onkeyup="sortUl('model','model_list_ul')" required>
                           <div id="model_list" class="list_data"></div>
                        </div>
                         <div class="col-12 in-list">
                           <label for="variant" class="col-form-label">Variant: </label>
                           <input class="form-control" type="text" placeholder="e.g. Corolla 1.3 Advanced Leather" id="variant" name="LEADCF3" value="" onfocus="sortUl('variant','variant_list_ul')" onkeyup="sortUl('variant','variant_list_ul')" required>
                           <div id="variant_list" class="list_data"></div>
                        </div>
                        <h3>Details</h3>
                      
                        
                        <div class="col-12">
                           <label for="Manufactured" class="col-form-label">Year Model: </label>
                           <select class="form-control" required id="Manufactured" name="LEADCF52">
                              <option value="">Choose Year Model</option>
                              <?php 
                               $year = date("Y");
                                 for($number=$year; $number>=$year-50; $number--){ ?>
										<option value="<?php echo $number; ?>"><?php echo $number; ?></option>
							     <?php } ?>
                           </select>
                        </div>
                        
                        <div class="col-12 radio_button">
                           <label class="col-form-label">Fuel type : </label><br/>
                           <label for="Petrol" class="btn btn-secondary fuel" data-name="fuel">
                           <input type="radio" value="Petrol" name="LEADCF6" id="Petrol">Petrol
                           </label>
                           <label for="Diesel" class="btn btn-secondary fuel" data-name="fuel">
                           <input type="radio" value="Diesel" name="LEADCF6" id="Diesel">Diesel
                           </label>
                           <label for="Electric" class="btn btn-secondary fuel" data-name="fuel">
                           <input type="radio" value="Electric" name="LEADCF6" id="Electric">Electric
                           </label>
                           <label for="Hybrid" class="btn btn-secondary fuel" data-name="fuel">
                           <input type="radio" value="Hybrid" name="LEADCF6" id="Hybrid">Hybrid
                           </label>
						   <input class="form-control hide_inp" required  type="text" id="fuelval" name="fuelval" value="" autocomplete="off">
                        </div>
                        <div class="col-12 radio_button">
                           <label class="col-form-label">Transmission : </label><br/>
                           <label for="Manual" class="btn btn-secondary transmission" data-name="transmission">
                           <input type="radio" value="Manual" name="LEADCF7" id="Manual">Manual
                           </label>
                           <label for="Automatic" class="btn btn-secondary transmission" data-name="transmission">
                           <input type="radio" value="Automatic" name="LEADCF7" id="Automatic">Automatic
                           </label>
                             <input class="form-control hide_inp" required  type="text" id="transmissionval" name="transmissionval" value="" autocomplete="off">
                        </div>
                        
                         <div class="col-12">
                           <label for="Odometer_reading" class="col-form-label">Odometer reading :</label>
                            <input class="form-control" type="hidden" id="Odometer_reading_new" name="LEADCF8" value="" >
                           <input class="form-control number" required placeholder="Odometer reading" type="text" id="Odometer_reading" name="" value="" autocomplete="off">
                        </div>
                      <?php /*  <div class="col-12">
                           <label for="Odometer_reading" class="col-form-label">Odometer reading : </label>
                           <select class="form-control" required id="Odometer_reading" name="LEADCF8">
                              <option value="">Choose a range</option>
                              <?php 
                                 $num=0;
                                 $num1=0;
                                 $pnum=1000;
                                 for($number=0;$number<=1000;$number++){?>
                              <option value="<?php echo ($num1) .'-'. ($num+$pnum) ?>"><?php echo ($num1) .'-'. ($num+$pnum) ?></option>
                              <?php
                                 $num=$num+$pnum;
                                 $num1=$num+1;
                                  } ?>
                              <option value="1001001 km PLUS">1001001 km PLUS</option>
                           </select>
                        </div> */ ?>
                        <div class="col-12 radio_button">
                           <label class="col-form-label">Condition : </label><br/>
                           <label for="Excellent" class="btn btn-secondary condition" data-name="condition">
                           <input type="radio" value="Excellent" name="LEADCF10" id="Excellent">Excellent
                           </label>
                           <label for="Good"  class="btn btn-secondary condition" data-name="condition">
                           <input type="radio" value="Good" name="LEADCF10" id="Good">Good
                           </label>
                           <label for="Average" class="btn btn-secondary condition" data-name="condition">
                           <input type="radio" value="Average" name="LEADCF10" id="Average">Average
                           </label>
                           <label for="Poor" class="btn btn-secondary condition" data-name="condition">
                           <input type="radio" value="Poor" name="LEADCF10" id="Poor">Poor
                           </label>
                            <input class="form-control hide_inp" required  type="text" id="conditionval" name="conditionval" value="" autocomplete="off">
                        </div>
                        <div class="col-12">
                         
                            <textarea class="form-control" maxlength='1000' name='LEADCF9' rows="3" placeholder="Optional: Anything we need to know about your vehicle" id="Vehicle" data-toggle="tooltip" data-placement="top" title="Please tell us anything else you feel is important. Tyre condition, extras, any accidents, service history, etc." ></textarea>
                           
                        </div>
                        <div class="col-12">
							
                           <p><a class="btn btn-primary next">CONTINUE TO STEP 2</a></p>
                        </div>
                     </fieldset>
                     <fieldset id="aboutyou_information" class="">
						    <h3>Personal</h3>
                        <div class="col-12">
                           <label for="name" class="col-form-label">Full Name: </label>
                           <input class="form-control" required placeholder="Full Name" type="text" id="name" name="Last Name" value="" autocomplete="off">
                        </div>
                        <div class="col-12">
                           <label for="Email" class="col-form-label">Email: </label>
                           <input class="form-control" required placeholder="Email:" type="email" id="Email" name="Email" value="" autocomplete="off">
                        </div>
                        <div class="col-12">
                           <label for="Mobile" class="col-form-label">Phone: </label>
                           <input class="form-control" required placeholder="Mobile:" type="text" id="Mobile" name="Mobile" value="" autocomplete="off">
                        </div>
                        <div class="col-12">
                           <label for="Phone" class="col-form-label">Landline: </label>
                           <input class="form-control" required placeholder="Phone:" type="text" id="Phone" name="Phone" value="" autocomplete="off">
                        </div>
                        <div class="col-12">
                           <label for="City" class="col-form-label">City: </label>
                           <input class="form-control address" required placeholder="City:" type="text" id="City" name="City" value="" autocomplete="off">
                        </div>
                        <div class="col-12">
                             <p><a class="btn btn-primary previous" data-pre-id="basics_information" >Previous</a><a class="btn btn-primary next">CONTINUE TO STEP 3</a></p>
                        </div>
                     </fieldset>
                     <fieldset id="yourneed_information" class="">
						  <h2>Your Needs</h2>
						  <div class="col-12">
                           <label for="BankSettle" class="col-form-label">Do you have a bank settlement on your car?: </label>
                             <input type="checkbox" class="form-control checkbox" id="BankSettle" name="LEADCF109" onclick="bank_div_show()">
                             
                        </div>
                         <div class="col-12 price_val" id="settle_div">
                         
                        </div>
						
                        <div class="col-12 price_val">
                           <label for="LEADCF66" class="col-form-label">Price estimation: </label>
                          <div class="rate">R</div>
                          <input class="form-control" type="hidden" id="LEADCF66_new" name="LEADCF66" value="" >
                           <input class="form-control number" required placeholder="Your asking price?" type="text" id="LEADCF66" name="LEADxxCF" value="" autocomplete="off"  data-original-title="Your asking price?">
                        </div>
                        <div class="col-12">
                           <label for="City" class="col-form-label">Photos: <span style="">Select up to 3 images of your car to upload (Optional)</span></label><div class="loadings" style="display:none">loading... </div>
                           <div class="file_upload">
                              <span class="file-input btn btn-primary btn-file" id="imgloader">

                              <input type="file" name='theFile' id='theFile' multiple>

                           </div>
                           <div id="error_message" style="color: #e70000;"></div>
                           <div id="success_mesg" style="display:none; color: #69740d;">Your submission is being processed. Please wait until you get our "Thank You" message.</div>
                           <div class="col-12">
                            <a class="btn btn-primary previous" data-pre-id="aboutyou_information">Previous</a> <button type="submit" name="sub" class="btn btn-default submit_application" id="formsubmit">Value My Car</button>
                           </div>
                     </fieldset>
                     
                     </div>
               </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>


<script type="text/javascript">// <![CDATA[
   $jQu(document).ready(function()
   {
       getData('get_brands_data', 'brand');
   });
   function sortUl(in_id, list_id) {
   var input, filter, ul, li, a, i, txtValue;
   input = document.getElementById(in_id);
   filter = input.value.toUpperCase();
   ul = document.getElementById(list_id);
   li = ul.getElementsByTagName("li");
   for (i = 0; i < li.length; i++) {
       a = li[i].getElementsByTagName("a")[0];
       txtValue = a.textContent || a.innerText;
       if (txtValue.toUpperCase().indexOf(filter) > -1) {
           li[i].style.display = "";
       } else {
           li[i].style.display = "none";
       }
   }
   }
 
   function getData(get_from_data, input_id, rec_id="")
   {
   
       $jQu('#'+input_id).addClass("loader");
       $jQu('#model').attr('disabled','disabled');
       $jQu('#variant').attr('disabled','disabled');
       var dataArr  = [];
       dataArr.push({ name: "action", value:"selluscars_ajax"});
       dataArr.push({ name: "task", value:get_from_data});
       if (rec_id!= null && rec_id!= ''){  
          dataArr.push({ name: "rec_id", value:rec_id});
       }
       dataArr.push({ name: "input_id", value:input_id});
       dataArr.push({ name: "security", value:window.selluscars_site_nonce});
       $jQu.ajax({
           method: "POST",
           url: adminAjax,
           data: dataArr,
           crossDomain: true,
           dataType: 'json'
       }).done(function (response) {
           var res = eval(response);
           $jQu('#'+input_id+'_list').empty();
           $jQu('#'+input_id+'_list').html(res.data);
           $jQu('#model').removeAttr('disabled');
           $jQu('#variant').removeAttr('disabled');
           $jQu( "#"+input_id ).removeClass("loader");
       }).fail(function (response) {
           var res = eval(response.responseJSON);
           if (res.success != "undefined" && res.success == 0) {
               warningMessage(res.message);
            $jQu( "#"+input_id ).removeClass("loader");
           }
       });
   }
   $jQu(document).on('click', '.list_data ul li a', function(e) {
   
   var name=$jQu(this).text();
   var input_name=$jQu(this).attr('data-input_id');
   $jQu('#'+input_name+'-error').remove();
   $jQu('#'+input_name+'-success').remove();
   var rec_id=$jQu(this).attr('data-id');
   
   $jQu('#'+input_name).addClass("successClass");
   $jQu('#'+input_name).after('<div id="'+input_name+'-success" class="help-block success">Success</div>');
   $jQu( "#"+input_name ).val(name);
   $jQu('#'+input_name+'-error').remove();
   $jQu('#'+input_name+'_list .typeahead.dropdown-menu').hide();
   if (rec_id!= null && rec_id!= '' && input_name=="brand"){  
	  $jQu('#model').val('');
	  $jQu('#variant').val('');
      getData('get_models_data', 'model', rec_id);
     
    }else if (rec_id!= null && rec_id!= '' && input_name=="model"){
	   $jQu('#variant').val('');
      getData('get_variants_data', 'variant', rec_id);
   }  
   
   return false;
   
   });
   $jQu(document).on('click', '.radio_button label', function(e) {
   var name=$jQu(this).attr('data-name');
   
   $jQu( '#'+name+'val' ).val(1);
   $jQu('#'+name+'val-error').remove();
   $jQu('#'+name+'val-success').remove();
   $jQu('#'+name+'val').after('<div id="'+name+'val-success" class="help-block success">Success</div>');
   $jQu('.radio_button label.'+name).removeClass("active_cls");
   $jQu(this).addClass("active_cls");
   });
   
   $jQu(document).on('focusout', '#brand, #model, #variant', function(e){
	     var id=$jQu(this).attr('id');
	     var current = $jQu('#'+id+'_list').find('ul li.current');
	     if(current.length == 0){
			$jQu( '#'+id ).val('');
			$jQu('#'+id+'-error').remove();
            $jQu('#'+id+'-success').remove();
	        $jQu('#'+id).after('<span id="'+id+'-error" class="help-block success">This field is required.</span>');
	     }
         
   });
   $jQu(document).on('focus', '#brand, #model, #variant', function(e){
   var id = $jQu(this).attr('id');
   $jQu( '#'+id ).val('');
   $jQu('#'+id+'-error').remove();
   $jQu('#'+id+'-success').remove();
  
   $jQu('#'+id+'_list .typeahead.dropdown-menu').show();
   if (id!= null && id!= '' && id=="brand"){ 
	  $jQu('#model_list').empty();
	  $jQu('#variant_list').empty();
	  $jQu('#model').val('');
	  $jQu('#variant').val('');
	  $jQu("#model-error").remove();
      $jQu("#model-success").remove();
      $jQu("#variant-error").remove();
      $jQu("#variant-success").remove();
	
   }else if (id!= null && id!= '' && id=="model"){
	    $jQu('#variant_list').empty();
	    $jQu('#variant').val('');
	   $jQu("#variant-error").remove();
       $jQu("#variant-success").remove();
   }
    
   
   });

   $jQu(document).on('click', '.next', function(e) {
	   var form = $jQu("#formCars");
	   form.validate({
		errorElement: 'span',
		errorClass: 'help-block',
		highlight: function(element, errorClass, validClass) {
			$jQu(element).closest('.form-group').addClass("has-error");
			
		},
		unhighlight: function(element, errorClass, validClass) {
			$jQu(element).closest('.form-group').removeClass("has-error");
		},
		
		rules: {
			brand: {
				required: true,
			},
			model : {
				required: true,
			},
			
		},
		messages: {
			brand: {
				required: "Brand required",
			},
			model : {
				model: "Model required",
			},
		},
		focusInvalid: false,
		invalidHandler: function(form, validator) {
			
			if (!validator.numberOfInvalids())
				return;
			
			$jQu('html, body').animate({
				scrollTop: $jQu(validator.errorList[0].element).offset().top
			}, 1000);
			
		}
	   });
	   
	   if (form.valid() === true){
		if ($jQu('#basics_information').is(":visible")){
			current_fs = $jQu('#basics_information');
			next_fs = $jQu('#aboutyou_information');
			current_fscls = $jQu('.basics_information');
			next_fscls    = $jQu('.aboutyou_information');
		}else if($jQu('#aboutyou_information').is(":visible")){
			current_fs = $jQu('#aboutyou_information');
			next_fs = $jQu('#yourneed_information');
			current_fscls = $jQu('.aboutyou_information');
			next_fscls    = $jQu('.yourneed_information');
		}
		current_fscls.removeClass("active");
		next_fscls.addClass("active");
		next_fs.show(1000); 
		current_fs.hide(1000);
		$jQu(window).scrollTop($jQu('#formCars').offset().top-120);
	   }
		$jQu('.typeahead.dropdown-menu').hide();
	   
	   return false;
   });
 
   $jQu(document).on('click', '.previous', function(e) {   
				if($jQu('#aboutyou_information').is(":visible")){
					current_fs       = $jQu('#aboutyou_information');
					next_fs          = $jQu('#basics_information');
					current_fscls    = $jQu('.aboutyou_information');
					next_fscls       = $jQu('.basics_information');
				}else if ($jQu('#yourneed_information').is(":visible")){
					current_fs    = $jQu('#yourneed_information');
					next_fs       = $jQu('#aboutyou_information');
					current_fscls = $jQu('.yourneed_information');
					next_fscls    = $jQu('.aboutyou_information');
				}
				current_fscls.removeClass("active");
				next_fscls.addClass("active");
				next_fs.show(1000); 
				current_fs.hide(1000);
});
$jQu(document).on('change', 'select', function(event) {
	var selvalue=$jQu(this).val();
	var id=$jQu(this).attr('id');
	//alert(id);
	$jQu('#'+id+'-error').remove();
	$jQu('#'+id+'-success').remove();
	if (selvalue!= null && selvalue!= ''){  
		$jQu('#'+id).after('<div id="'+id+'-success" class="help-block success">Success</div>');
    }else{
		 $jQu('#'+id).after('<span id="'+id+'-error" class="help-block success">This field is required.</span>');
	}
	
});

$jQu('input[type=file]').change(function(){
	var files = jQuery(this)[0].files;
	var len = jQuery(this).get(0).files.length;
	//alert(len);
	if(len <= 3){
		$jQu('.loadings').show();
		$jQu('#error_message').text('');
	}else{
		$jQu('#error_message').text('You can upload a maximum of three files at a time.');
	}
	setTimeout(function(){ 
		$jQu('.loadings').hide();					
	}, 3000);
    //var file = this.files[0];
    //name = file.name;
    //alert(name);
   // size = file.size;
    //type = file.type;
    //your validation
});

$jQu(document).on('focusout', '#aboutyou_information input, #yourneed_information input.number, input#Odometer_reading', function(e){
	     var id=$jQu(this).attr('id');
	     var aria_invalid=$jQu(this).attr('aria-invalid');
	     //alert(aria_invalid);
	     var invalue=$jQu(this).val();
		 $jQu('#'+id+'-error').remove();
		 $jQu('#'+id+'-success').remove();
		if (invalue!= null && invalue!= '' && aria_invalid!= 'true' ){  
			$jQu('#'+id).after('<div id="'+id+'-success" class="help-block success">Success</div>');
		}else{
			$jQu('#'+id).after('<span id="'+id+'-error" class="help-block success">This field is required.</span>');
		}
});
$jQu(document).on('keydown', 'input#brand, input#model, input#variant', function(e) {
	var id=$jQu(this).attr('id');
	var action = '';
    var current = $jQu('#'+id+'_list').find('ul li:visible.current');
    if (e.which == 40) {
      if(current.length == 0){
		 // console.log("[here]", current);
		  current = $jQu('#'+id+'_list').find('ul li:visible:first');
	  }else{
		  current.removeClass('current');
		  current = current.nextAll('li:visible:first');
	 }
	 action = 'next';
	 //$jQu('input#brand').val(current.find('a').html());
    }else if (e.which == 38) {
      if(current.length == 0){
		//  console.log("[here]", current);
		   current = $jQu('#'+id+'_list').find('ul li:visible:first');
	  }else{
		  current.removeClass('current');
		  current = current.prevAll('li:visible:first');
	 }
	  action = 'prev';
    }else if (e.which == 8) {
		$jQu('#'+id+'_list_ul').show();
	}
     
	 var i =$jQu('#'+id+'_list li').index( current );
	 if((i== -1 || i == $jQu('#'+id+'_list li').length) && action == 'next'){
		  current = $jQu('#'+id+'_list').find('ul li:visible:first');
	 }else if(i == -1  && action == 'prev'){
		 current = $jQu('#'+id+'_list').find('ul li:visible:last');
	 }
	 current.addClass('current');
     moveContent(id, current);
	 if (e.which == 13 && current.length > 0){
		 current.find('a').trigger( "click" );
		 //current.find('input#model').trigger( "click" );
		 $jQu('#'+id+'-error').remove();
		 $jQu('#'+id+'-success').remove();
		 $jQu('#'+id).after('<div id="'+id+'-success" class="help-block success">Success</div>');
		return false;
	}
});
function moveContent(id, current) {
	var i =$jQu('#'+id+'_list_ul li:visible').index( current );
	var scroll = i * 42;
	console.log("[here]", scroll);
    $jQu('#'+id+'_list_ul').scrollTop(scroll);

}

function getUserIpDetails(){
	
}

function bank_div_show() {
if (jQuery('#BankSettle').prop('checked') == true) {
	  var str='<label for="LEADCF53" class="col-form-label">Bank Settlement Value: </label><div class="rate">R</div><input class="form-control" type="hidden" id="LEADCF53_new" name="LEADCF53" value="" ><input class="form-control number" required placeholder="Bank Settlement Value" type="text" id="LEADCF53" name="" value="" autocomplete="off" style="-moz-appearance: textfield" data-toggle="tooltip" data-placement="top" title="" data-original-title="Your asking price?" >';
	       $jQu('#settle_div').empty();
           $jQu('#settle_div').html(str);
} else {
	$jQu('#settle_div').empty();
}
}
$jQu( "#formCars" ).validate({

		errorElement: 'span',
		errorClass: 'help-block',
		highlight: function(element, errorClass, validClass) {
			$jQu(element).closest('.form-group').addClass("has-error");
			
		},
		unhighlight: function(element, errorClass, validClass) {
			$jQu(element).closest('.form-group').removeClass("has-error");
		},
		focusInvalid: false,
		invalidHandler: function(form, validator) {
			
			if (!validator.numberOfInvalids())
				return;
			
			$jQu('html, body').animate({
				scrollTop: $jQu(validator.errorList[0].element).offset().top
			}, 1000);
			
		}
});
// ]]>
</script>
<script>
 	  var mndFileds=new Array('Last Name');
 	  var fldLangVal=new Array('Last Name');
		var name='';
		var email='';

	function validateFileUpload(){
		
		 var uploadedFiles = document.getElementById('theFile'); 
		 var totalFileSize =0; 
		 if(uploadedFiles.files.length >3){ 
			 jQuery('#error_message').text('You can upload a maximum of three files at a time.'); 
			 jQuery('#formsubmit').show();
			 return false; 
		 } 
		 if ('files' in uploadedFiles) { 
			 if (uploadedFiles.files.length != 0) { 
				 for (var i = 0; i < uploadedFiles.files.length; i++) { 
					 var file = uploadedFiles.files[i]; 
					 if ('size' in file) { 
						 totalFileSize = totalFileSize + file.size; 
					 } 
				 } 
				 if(totalFileSize > 20971520){ 
					 //alert(''); 
					 jQuery('#error_message').text('Total file(s) size should not exceed 20MB.'); 
					 jQuery('#formsubmit').show();
					 return false; 
				 } 
			 } 
		 } 
		 return true;
	 }
	 
 	  function checkMandatory() {
		var files = jQuery('#theFile')[0].files;
		var len = jQuery('#theFile').get(0).files.length;
		//alert(len);
		//return false;
		var form = $jQu("#formCars");
		jQuery('#formsubmit').hide();
		form.validate({ });
		if (form.valid() === true){
			if( validateFileUpload() == true ){
				jQuery('#success_mesg').show();
				return true;
			}else{
				return false;
			}			
		}else{
			jQuery('#formsubmit').show();
		}
		trackVisitor();
}
</script><script type='text/javascript' id='VisitorTracking'>var $zoho= $zoho || {salesiq:{values:{},ready:function(){$zoho.salesiq.floatbutton.visible('hide');}}};var d=document;s=d.createElement('script');s.type='text/javascript';s.defer=true;s.src='https://salesiq.zoho.com/selluscars/float.ls?embedname=selluscars';t=d.getElementsByTagName('script')[0];t.parentNode.insertBefore(s,t);function trackVisitor(){try{if($zoho){var LDTuvidObj = document.forms['WebToLeads1729068000000091137']['LDTuvid'];if(LDTuvidObj){LDTuvidObj.value = $zoho.salesiq.visitor.uniqueid();}var firstnameObj = document.forms['WebToLeads1729068000000091137']['First Name'];if(firstnameObj){name = firstnameObj.value +' '+name;}$zoho.salesiq.visitor.name(name);var emailObj = document.forms['WebToLeads1729068000000091137']['Email'];if(emailObj){email = emailObj.value;$zoho.salesiq.visitor.email(email);}}} catch(e){}}</script>
     <!-- ZOHO ADWORDS INTEGRATION-->
<script type="text/javascript" src='https://crm.zoho.com/crm/javascript/zcga.js'></script>
<script>
454,454
    // When ready.
  //  $jQu(function() {
        
var form = $jQu( "#formCars" );
var input = form.find( "input.number" );   
$jQu(document).on('keyup', 'input.number', function(e) {
      //   input.on( "keyup", function( event ) {
  
            
            // When user select text in the document, also abort.
            var selection = window.getSelection().toString();
            if ( selection !== '' ) {
                return;
            }
            
            // When the arrow keys are pressed, abort.
            if ( $jQu.inArray( event.keyCode, [38,40,37,39] ) !== -1 ) {
                return;
            }
            
            
            var $this = $jQu( this );
            
            // Get the value.
            var input = $this.val();
            
            var input = input.replace(/[\D\s\._\-]+/g, "");
                    input = input ? parseInt( input, 10 ) : 0;

                    $this.val( function() {454,454
                        return ( input === 0 ) ? "" : input.toLocaleString( "en-US" );
                    } );
 } );
$jQu(document).on('focusout', 'input.number', function(e){
	var value=$jQu( this ).val();
    var id=$jQu(this).attr('id');
    var res = value.replace(/,/g, "");
    $jQu('#'+id+'_new' ).val(res);
 } );

$jQu(document).ready(function(){ 
	/* var ip = '117.96.247.237'
	var access_key = '7d8d824e063d12b949b856471dbb0eda';
	$jQu.ajax({
		url: 'http://api.ipstack.com/' + ip + '?access_key='+ access_key,   
		dataType: 'json',
		success: function(json) {
			// output the "capital" object inside "location"
			alert(json);
			alert(json.location.city);
			
		}
	});
	//http://api.ipstack.com/selluscars/?access_key=7d8d824e063d12b949b856471dbb0eda&output=json&legacy=1
	//http://api.ipstack.com/check?access_key=7d8d824e063d12b949b856471dbb0eda&output=json&legacy=1

   var apiKey = '7d8d824e063d12b949b856471dbb0eda'; // free account 10.000 requests / mo
	$jQu.getJSON('http://api.ipstack.com/117.96.247.237?access_key='+apiKey+'&output=json&legacy=1', function(data) {
		console.log("IP INDFORMATION:", data);
		if(typeof data != "undefined" && typeof data.ip != "undefined"){
			var userData = {};
			 userData['geoip'] = JSON.stringify(data);

		}
	});*/
 });
</script>	
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3&libraries=places&key=AIzaSyCft6py0KzXXhbenO_4DN25kG8n_EDAvbE&ver=3"></script>
<script type="text/javascript">
jQuery( document ).ready( function($) {
 
    //$jQu( "#City" ).click( function(e) {
       // e.preventDefault();
 
        /* Chrome need SSL! */
        var is_chrome = /chrom(e|ium)/.test( navigator.userAgent.toLowerCase() );
        var is_ssl    = 'https:' == document.location.protocol;
        if( is_chrome && ! is_ssl ){
            return false;
        }
 
        /* HTML5 Geolocation */
        navigator.geolocation.getCurrentPosition(
            function( position ){ // success cb
 
                /* Current Coordinate */
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                var google_map_pos = new google.maps.LatLng( lat, lng );
 
                /* Use Geocoder to get address */
                var google_maps_geocoder = new google.maps.Geocoder();
                google_maps_geocoder.geocode(
                    { 'latLng': google_map_pos },
                    function( results, status ) {
                        if ( status == google.maps.GeocoderStatus.OK && results[0] ) {
                            //console.log( results[0].formatted_address );
                            $jQu( "#City" ).val(results[0].formatted_address);
                        }
                    }
                );
            },
            function(){ // fail cb
            }
        );
    //});
 
 
});
</script>
