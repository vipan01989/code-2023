<?php
   /**
    * Created by PhpStorm.
    * User: Oculus
    * Date: 15/10/2020
    * Time: 5:34 PM
    */
   $current_user = wp_get_current_user();

   $name  ='';
   $email ='';
   $phone ='';
  if(!empty($current_user->ID) && !empty($current_user->user_email)){
	   $email =$current_user->user_email;
	     $user_id =$current_user->ID;
	     $phone_number = get_user_meta( $user_id, 'phone_number', true );
		 $first_name   = get_user_meta( $user_id, 'first_name', true ); 
		 $last_name = get_user_meta( $user_id, 'last_name', true ); 
         if(!empty($phone_number)){
            $phone =$phone_number;
		 }
		if(!empty($first_name)){
		  $name =$first_name;
		}	
		if(!empty($last_name)){
			$name .=' '.$last_name;
		}		
  }
   
?>

<div class="container">

<div class="row">
   <div class="col-md-12 sell_carsnew">
   
    <form id="formCarsNew" name="formCarsNew" data-toggle="validator">
	<div id="form_title" class="form_title">
		<h2>start here!</h2>
		<h4>Share your contact details</h4>
	</div>
	<div id="alertMsg" class="alert"></div>
	<div id="aboutyou_information_new" class="">

		<div class="form-group row">
       
          <div class="col-12">
            <input class="form-control main_form_input" required type="text" minlength="2" name="name" id="name" value="<?php echo $name; ?>" placeholder="Full Name">
			  <div class="help-block with-errors">
            </div>
          </div>
        </div>
		
		<div class="form-group row">

          <div class="col-12 formDisplaymain">
            <input class="form-control formDisplayEmail main_form_input" required type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" oninput="this.value=this.value.toLowerCase()" minlength="4" id="email" name="email" value="<?php echo $email; ?>"  placeholder="Email Address">
           	<div class="help-block with-errors">
            </div>
          </div>
        </div>
		<div class="form-group row">
       
          <div class="col-12 formPhonemain">
            <input class="form-control main_form_input" required type="tel" maxlength="13" name="phone" id="phone" value="<?php echo $phone; ?>" placeholder="Phone Number">
			  <div class="help-block with-errors">
            </div>
          </div>
        </div>
		
        <div class="form-group row">
          
          <div class="col-12">
		    <input type="hidden" id="input_id" name="input_id" value="brand" />
            <button type="submit" class="btn btn-primary sunny next" name="submit_form">Get Started
            </button>
			 <br/> <div class="loader">
            </div>
          </div>
		 
        </div>
  </div>
 </form>
 
 <div id="car_info" class="car_info hidden">
   <h2 class="ss_title">Sell My Car</h2>
  <div class='progress_bar'><div class='total_fill'>10%</div></div> 

    <div id="ss_data" class="ss_data">
	<div class="loader"></div>

	<form id="formCarsNewinfo" name="formCarsNewinfo" data-toggle="validator">	
		<fieldset id="Odometer_reading_set" class="Odometer_reading_set hidden">
			<div class="col-12">
				<label for="Odometer_reading" class="note_text col-form-label">You’re amazing! Now, what’s your current mileage? (in kms)</label>
				
				<input class="form-control number numVal" required placeholder="Type your car’s odometer reading" type="text" id="Odometer_reading" name="Odometer_reading" value="" autocomplete="off">
			</div>
			 <div class="col-12">
							
                           <p><a class="btn btn-primary next">Next</a></p>
              </div>
		</fieldset>
		<fieldset id="location_or_city" class="location_or_city hidden">
			<div class="col-12 address_main">
				<label for="City" class="note_text col-form-label">Nice, where are you located?</label>

				<input class="form-control number address" required placeholder="Type your city or suburb" type="text" id="City" name="City" value="" autocomplete="off">
			</div>
			
			
			 <div class="col-12">
				<p><a class="btn btn-primary next">Next</a></p>
              </div>
		</fieldset>
		
		<fieldset id="sell_car_price_set" class="sell_car_price_set hidden">
			<div class="col-12">
				<label for="sell_car_price" class="note_text col-form-label">The important stuff – What price do you have in mind for
your car?</label>
                <span class="price_icon"><?php echo $this->priceIcon; ?></span>
				<input class="form-control number numVal" required placeholder="Type your asking price" type="text" id="sell_car_price" name="" value="" autocomplete="off">
			</div>
			  <div class="col-12">
                           <label for="BankSettle" class="col-form-label">Do you have a bank settlement on your car?: </label>
                             <input type="checkbox" class="form-control checkbox" id="BankSettle" name="BankSettle" onclick="bank_div_show()">
               <div class="col-12 price_val" id="settle_div"></div>              
               </div>
                         
            
			 <div class="col-12">
				<p><a class="btn btn-primary next">Next</a></p>
              </div>
		</fieldset>
		<?php 
		if(!empty($_REQUEST['id'])){
			$cls='';
			
		}else{
			$cls='hidden';
		}
		
		?>
		</form>
		
	    <fieldset id="final_step_set" class="final_step_set <?php echo $cls; ?>">
			<div class="col-12">
			<label for="about_vehicle" class="note_text col-form-label">Awesome, we’re done! Is there anything you’d like to add
about your car before submitting it to us?</label>
				<div class="file_upload">
	            <label for="City" class="col-form-label">Photos: <span style="">Select up to <?php echo $this->maxImagelength ?> images of your car to upload </span></label><div class="loadings" style="display:none">loading... </div>
				<form id="formCarsimg" name="formCarsimg" data-toggle="validator">	
					
					<h3>Optional: Upload images of your car</h3>
					<input id="carImages" type="file" name="carImages[]" multiple="multiple" accept=".jpg, .jpeg, .png"/>
					<div class="hidden error_message"></div>
					<button id="upload" value="Upload" type="button" class="btn btn-primary hidden">upload</button> 
				</div>
				<div class="preview"></div>
				
				</form>
				
				<textarea class="form-control" maxlength="1000" name="about_vehicle" rows="3" placeholder="Optional comments about your car" id="about_vehicle" data-toggle="tooltip" data-placement="top" title="" data-original-title="Please tell us anything else you feel is important. Tyre condition, extras, any accidents, service history, etc."></textarea>
				<p><a class="btn btn-primary next hide_on_moble">GET YOUR OFFER</a></p>
				<p><a class="btn btn-primary next hidden"> >> FINAL  STEP, SUBMIT YOUR CAR</a></p>
				
			
				<input type="hidden" id="user_id" name="user_id" value="" />
				<input type="hidden" id="c_user_id" name="c_user_id" value="" />
				<input type="hidden" id="lead_id" name="lead_id" value="" />
		     </div>
		</fieldset>
		
		
	
 
	</div>
	
 
	
	
	<div id="ss_select_info" class="ss_select_info">
	<h2 class="ss_title current_selected">Currently Selected</h2>
	
		<ul class="list-group">
		
		</ul>
	</div>
	   
   
 </div>
  <fieldset id="thankyou" class="thankyou">
			 	<div class="thankyou" id="last_section" style="display: none;">
					<h2><span class="name"><?php echo $name; ?></span>, your vehicle info has been successfully submitted!</h2>
					<p>Watch for an email and SMS from Selluscars.co.za with your cash offer.</p>
					<p>We’ll contact you at:</p>
					<p class="email"><?php echo $email; ?></p>
					<p class="mobile"><?php echo $phone; ?></p>
					<p classs="">Thanks for choosing <b></span>Selluscars.co.za!</b></p>
					<div class="buttons">
						<a href="<?=home_url( $wp->request );?>" class="" >Go to Home</a>
					</div>
				</div>
		</fieldset>
 </div></div>
</div>
<?php 
 $fueltype_list_ul  =$this->getFuelType(); 
 $geartype_list_ul  =$this->getGearType(); 
 
?>
 <script>

$jQu(document).on('keyup','.numVal',function(event){  

    var selection = window.getSelection().toString(); 
    if (selection !== '') {
        return; 
    }       
    // When the arrow keys are pressed, abort.
    if ($jQu.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
        return; 
    }       
     var $this = $jQu(this);          
    // Get the value.
    var input = $this.val();            
    input = input.replace(/[\D\s\._\-]+/g, ""); 
    input = input?parseInt(input, 10):0; 
    $this.val(function () {
        return (input === 0)?"":input.toLocaleString("en-US"); 
    }); 
}); 

function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? ',' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}
	 
	 
    $jQu(document).ready(function(){
        var form_data     = new FormData();
        var max_len_files ='<?php echo $this->maxImagelength ?>';
		var max_size_files ='<?php echo $this->maxImageSize ?>';
		var inMB ='<?php echo $this->inMB ?>';
		var totalfiles='';
				
       
        /* WHEN YOU UPLOAD ONE OR MULTIPLE FILES */
	
        $jQu(document).on('change','#carImages',function(){
		
		    var $totalfile='';
			var img_error='';
			$jQu('.error_message').html("");
			
			var len_files = $jQu("#carImages").prop("files").length;
            var select_files = $jQu("#final_step_set .preview img.main-img").length;
			
		    totalfiles=len_files+select_files;
		//	console.log(len_files+'--'+select_files+'t'+totalfiles);
			//alert(totalfiles);
				
				if(totalfiles<=max_len_files){
					var construc='';
					//form_data='';
					for (var i = 0; i < len_files; i++) {
						var file_data = $jQu("#carImages").prop("files")[i];
						var fsize = file_data.size||file_data.fileSize;
						if(fsize>max_size_files){
						 img_error=1;	
						}
						form_data.append("carImages[]", file_data);
				   }
				   if(img_error===1){
					  $jQu('.error_message').append('<p>Please upload file less than '+inMB+'. Thanks!</p>'); 
					  $jQu('#carImages').val('');
                      form_data.delete("carImages[]");
					  img_error='';
				   }else{
					saveCarImages();
				   }
				}else{
					$jQu('.error_message').append('<p>You Can Upload Max '+max_len_files+' Files. Thanks!</p>');
					$jQu('#carImages').val('');
				}
			

            
        }); 

        /* WHEN YOU CLICK ON THE IMG IN ORDER TO DELETE IT */
		 $jQu(document).on('click','.img_div span.cross',function(){
	
				var imgId = $jQu(this).attr('data-carimg_id');
				var filename = $jQu(this).attr('data-img-name');
				//console.log(imgId+'--'+filename);
				$jQu("#img_id_"+imgId).remove();
				deleteCarImages(imgId, filename);
			});
			
		function deleteCarImages(imgId, filename){
				 // console.log(imgId+'--'+filename);
				    var form_data     = new FormData();
			        form_data.append("action", 'selluscars_ajax');
					form_data.append("task", 'delete_images_data');
					form_data.append("img_id", imgId);
					form_data.append("img_name", filename);
					form_data.append("security", window.selluscars_site_nonce);
					var select_files = $jQu("#final_step_set .preview img.main-img").length;
					console.log(max_len_files+'--'+select_files);
					if(select_files<max_len_files){
						$jQu('.file_upload').show("");
					}
					if(select_files<=0){
						//$jQu('#final_step_set .next').hide("");
					}
					
					$jQu.ajax({
						url: adminAjax,
						dataType: 'json',
						cache: false,
						contentType: false,
						processData: false,
						data: form_data, // Setting the data attribute of ajax with form_data
						type: 'post',
						success: function(data) {
						              
						}
					});
	  }

        /* UPLOAD CLICK */

			function saveCarImages(){
					 $jQu('.loader').show();
					 $jQu('.file_upload').hide("");
						$jQu('#final_step_set .next').hide("");
					var user_id =$jQu('#user_id').val();
					form_data.append("action", 'selluscars_ajax');
					form_data.append("task", 'save_images_data');
					form_data.append("user_id", user_id);
				    form_data.append("totalfiles", totalfiles);
					form_data.append("security", window.selluscars_site_nonce);
					
					$jQu.ajax({
						url: adminAjax,
						dataType: 'json',
						cache: false,
						contentType: false,
						processData: false,
						data: form_data, // Setting the data attribute of ajax with form_data
						type: 'post',
						success: function(data) {
						               $jQu('.loader').hide();
									   $jQu("#formCarsimg")[0].reset()
										var res = eval(data);
										if (res.success != "undefined" && res.success == 1) {
											$jQu('#final_step_set .preview').append(res.data); 
											form_data.delete("carImages[]");
											if(totalfiles!=max_len_files){
													$jQu('.file_upload').show("");
											}
										
											$jQu('#final_step_set .next').show("");
										}else{
										$jQu('.file_upload').show("");	
										 $jQu('.error_message').append(res.error);
										}
						}
					});
			
        //});
	  }
    });
</script>
<script type="text/javascript">// <![CDATA[
$jQu('#formCarsNew').validator();

 $jQu(document).on('focus','.main_form_input',function(){
  if (!$jQu("body").hasClass("changeform") ){ 
	    $jQu("body").addClass("changeform");
   }
 });

 $jQu(document).on('focusout','#email',function(){
	if (!ValidateEmail($jQu(this))) {
	
		$jQu("#formCarsNew .formDisplaymain .with-errors").empty();
		$jQu("#formCarsNew .formDisplaymain .with-errors").append("Please enter a valid Email");
	
	}
	
});

 $jQu(document).on('focusout','#year',function(){
	if (!checkIsValidYear("input#year")) {
		$jQu("#year").removeClass("success").addClass("error");
	}else{
		$jQu("#year").removeClass("error").addClass("success");
	}
});
 $jQu(document).on('focusout','#phone',function(){
  ValidatePhone("input#phone");
});

function ValidateYear(input_id){
    var year = $jQu(input_id).val();
    var date_regex = /^(19[0-9]{2}|20[0-9]{2})$/;
	if (!(date_regex.test(year))) {
		$jQu(".formPhonemain .with-errors").empty();
		$jQu(".formPhonemain .with-errors").append("<span class='error_msg'>Please enter valid Year</span>");
		return false;
	}
	return true;
}

function checkIsValidYear(input_id)
{
	var year = $jQu(input_id).val();
	var _thisYear = new Date().getFullYear();
	var error = false;
	if (year.length != 4){
		error = true;
	}
	if (!year.match(/\d{4}/)){
		error = true;
	}
	if (parseInt(year) > _thisYear || parseInt(year) < 1900){
		error = true;
	}
	if(error == true){
		$jQu(".formPhonemain .with-errors").empty();
		$jQu(".formPhonemain .with-errors").append("<span class='error_msg'>Please enter valid Year</span>");
		return false;
	}else{
		return true;
	}
}


function ValidatePhone(input_id){
    var phoneno_sp = $jQu(input_id).val();
	 var regPhone = /^([\+]|(0{1,2}))?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,10}$/im;
	var validPhoneNo = regPhone.test(phoneno_sp);
	$jQu(".formPhonemain .with-errors").empty();
	if (!validPhoneNo) {
		$jQu(".formPhonemain .with-errors").empty();
		$jQu(".formPhonemain .with-errors").append("<span class='error_msg'>Please enter valid Phone number</span>");
	    return false;
	}
   return true;
}

  function ValidateEmail(mail) {
           var pem = /^([a-zA-Z0-9_.-]{2,15})+@(([a-zA-Z0-9-]{2})+.)+([a-zA-Z0-9]{2,4})+$/;

            if (pem.test($jQu(mail).val())) {
				
                return true;
                
            }

            return false;
  }
 $jQu('#formCarsNew').validator().on('submit', function (e) {
    var form=$jQu(this);
    
     if (!ValidateEmail($jQu(this).find("#email"))) {
		            $jQu("#formCarsNew .formDisplaymain .with-errors").empty();
                    $jQu("#formCarsNew .formDisplaymain .with-errors").append("Please enter a valid Email");
                    return false;
        }
         if (!ValidatePhone("input#phone")){
		           return false;
		 }

    if (e.isDefaultPrevented()) {
      // handle the invalid form...
    }
    else {
		$jQu('#aboutyou_information_new button.btn.btn-primary.next').hide();
	   $jQu('.loader').show();
      var dataArr = $jQu(this).serializeArray();
      dataArr.push({name: "action", value:"selluscars_ajax"});
      dataArr.push({ name: "task", value:"save_user_details"});
      dataArr.push({ name: "security", value:window.selluscars_site_nonce});
      $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: dataArr,
        crossDomain: true,
        dataType: 'json'
      }).done(function (response) {
        $jQu('.loader').hide();
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {
		   $jQu('#car_info').show();
		   $jQu('#aboutyou_information_new').hide();
		   $jQu('#form_title').hide();
		   $jQu('.ss_data').append(res.html_data);
		   $jQu('#user_id').val(res.id);
		   $jQu('#c_user_id').val(res.user_id);
		   $jQu('#lead_id').val(res.lead_id);
		   $jQu('body').addClass("selluscars_Start");
		  // $jQu( "#year" ).focus();
		   $jQu( "#year" ).click();
		   scroll_top();
        }
        else {
          warningMessage(res.message);
		  $jQu('#aboutyou_information_new button.btn.btn-primary.next').show();
        }
      }).fail(function (response) {
        var res = eval(response.responseJSON);
   
      });
      e.preventDefault();

   
    }
  });
  
    /*Step 1 click code*/
		$jQu(document).on('click', '#year_list_ul li a', function(e) {
			var name        =$jQu(this).text();
			var rec_id      =$jQu(this).attr('data-id'); 
			var input_name  ='brand';
			$jQu('#year').val(name);
			$jQu('.ss_data .loader').show();
			$jQu('.yearlist').hide();
			if($jQu(".brands").length > 0) {
				  $jQu('.brands').remove(); 
			}
		  var dataArr = $jQu(this).serializeArray();
		  dataArr.push({ name: "action", value:"selluscars_ajax"});
		  dataArr.push({ name: "task", value:"get_brands_data"});
		  dataArr.push({ name: "rec_id", value:rec_id});
		  dataArr.push({ name: "input_id", value:input_name});
		  dataArr.push({ name: "select_name", value:name});
		  dataArr.push({ name: "security", value:window.selluscars_site_nonce});
		  $jQu.ajax({
			method: "POST",
			url: adminAjax,
			data: dataArr,
			crossDomain: true,
			dataType: 'json'
		  }).done(function (response) {
			$jQu('.ss_data .loader').hide();
			var res = eval(response);
			if (res.success != "undefined" && res.success == 1) {
				var selectdata='<li id ="year_list_li" data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Year : </strong> &nbsp;'+name+'<span class="cross" ng-show="yearlist">&#x2716;</span></li>';
		        $jQu('.ss_select_info .list-group').append(selectdata);
			    $jQu('.ss_data').append(res.data);
				$jQu( "#brand" ).focus();
			   get_step_no();
			   scroll_top();
			   
			}
			else {
			  warningMessage(res.message);
			}
		  }).fail(function (response) {
			var res = eval(response.responseJSON);
			if (res.success != "undefined" && res.success == 0) {
			   warningMessage(res.message);
			}
		  });
		  e.preventDefault();
		}); 
      /*Step 1 click code end*/


  /*Step 2 click code*/
  $jQu(document).on('click', '#brand_list_ul li a', function(e) {
		var name        =$jQu(this).text();
		var input_name  ='model';
		var rec_id      =$jQu(this).attr('data-id');
		var year        =$jQu('#year_list_li').attr('data-val'); 
	    $jQu('#brand').val(name);
	    $jQu('.ss_data .loader').show();
	    $jQu('.step_wrapper.brands').hide();
	    if($jQu(".models").length > 0) {
			   $jQu('.models').remove(); 
		}
      var dataArr = $jQu(this).serializeArray();
      dataArr.push({ name: "action", value:"selluscars_ajax"});
      dataArr.push({ name: "task", value:"get_models_data"});
	  dataArr.push({ name: "rec_id", value:rec_id});
	  dataArr.push({ name: "input_id", value:input_name});
	  dataArr.push({ name: "year", value:year});
	  dataArr.push({ name: "select_name", value:name});
      dataArr.push({ name: "security", value:window.selluscars_site_nonce});
      $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: dataArr,
        crossDomain: true,
        dataType: 'json'
      }).done(function (response) {
        $jQu('.ss_data .loader').hide();
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {
		
		   $jQu('.ss_select_info .list-group').append(res.selectdata);
		   $jQu('.ss_data').append(res.data);
		   	$jQu( "#model" ).focus();
		   get_step_no();
		   scroll_top();
        }
        else {
          warningMessage(res.message);
        }
      }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
           warningMessage(res.message);
        }
      });
      e.preventDefault();
  }); 
 /*Step 2 click code end*/
  /*Step 3 click code*/
  $jQu(document).on('click', '#model_list_ul li a', function(e) {
		var name        =$jQu(this).text();
		var input_name  ='variant';
		var rec_id      =$jQu(this).attr('data-id'); 
		var year        =$jQu('#year_list_li').attr('data-val'); 
        $jQu('#model').val(name);
	    $jQu('.ss_data .loader').show();
	    $jQu('.models').hide();
	  
	  if($jQu(".variations").length > 0) {
		   $jQu('.variations').remove(); 
	  }
      var dataArr = $jQu(this).serializeArray();
      dataArr.push({ name: "action", value:"selluscars_ajax"});
      dataArr.push({ name: "task", value:"get_models_data"});
	  dataArr.push({ name: "rec_id", value:rec_id});
	  dataArr.push({ name: "year", value:year});
	  dataArr.push({ name: "input_id", value:input_name});
	  dataArr.push({ name: "select_name", value:name});
      dataArr.push({ name: "security", value:window.selluscars_site_nonce});
      $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: dataArr,
        crossDomain: true,
        dataType: 'json'
      }).done(function (response) {
        $jQu('.ss_data .loader').hide();
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {

		   $jQu('.ss_select_info .list-group').append(res.selectdata);
		   $jQu('.ss_data').append(res.data);
		   	$jQu( "#variant" ).focus();
		   scroll_top();
		   get_step_no();
        }
        else {
          warningMessage(res.message);
        }
      }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
           warningMessage(res.message);
        }
      });
      e.preventDefault();
  });
   /*Step 3 click code end*/
  /*Step 4 click code*/
   $jQu(document).on('click', '#variant_list_ul li a', function(e) {
	   var fueltype_list    ='<?php echo $fueltype_list_ul["data"]; ?>';

	   	var name        =$jQu(this).text();
		var rec_id      =$jQu(this).attr('data-id');
		$jQu('#variant').val(name);
		$jQu('.variations').hide();
	
		if($jQu(".fueltype").length > 0) {
		   $jQu('.fueltype').remove(); 
	    }
		var selectdata='<li id ="variant_list_li" data-val="'+name+'" data-vid="'+rec_id+'" class="list-group-item list-group-item-info" ng-show="variations"><strong>Variant : </strong> &nbsp;'+name+'<span class="cross" ng-show="variations">&#x2716;</span></li>';
		$jQu('.ss_select_info .list-group').append(selectdata);
		//$jQu('.ss_data').append(fueltype_list);
		$jQu('#Odometer_reading_set').show();
		 $jQu( "#Odometer_reading" ).focus();
		 get_step_no();
	    e.preventDefault();
  });
   /*Step 4 click code end*/

 /* $jQu(document).on('click', '#fueltype_list_ul li a', function(e) {
	    var geartype_list    ='<?php echo $geartype_list_ul["data"]; ?>';
	   	var name        =$jQu(this).text();
		var rec_id      =$jQu(this).attr('data-id');
		
		$jQu('.fueltype').hide();
		if($jQu(".geartype").length > 0) {
		   $jQu('.geartype').remove(); 
	    }
		var selectdata='<li id ="fueltype_list_li" data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Fuel Type : </strong> &nbsp;'+name+'<span class="cross" ng-show="fueltype">&#x2716;</span></li>';
		$jQu('.ss_select_info .list-group').append(selectdata);
		 get_step_no();
		$jQu('.ss_data').append(geartype_list);
	    e.preventDefault();
  });
  $jQu(document).on('click', '#geartype_list_ul li a', function(e) {
	   var yearsList    ='';
	   	var name        =$jQu(this).text();
		var rec_id      =$jQu(this).attr('data-id');
		var vid      =$jQu("#variant_list_li").attr('data-vid');
		    $jQu('.ss_data .loader').show();
		$jQu('.geartype').hide();
		
	    if($jQu(".yearlist").length > 0) {
		   $jQu('.yearlist').remove(); 
	    }
	    
	  var dataArr = $jQu(this).serializeArray();
      dataArr.push({ name: "action", value:"selluscars_ajax"});
      dataArr.push({ name: "task", value:"get_years_data"});
	  dataArr.push({ name: "vid", value:vid});
      dataArr.push({ name: "security", value:window.selluscars_site_nonce});
      $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: dataArr,
        crossDomain: true,
        dataType: 'json'
      }).done(function (response) {
        $jQu('.ss_data .loader').hide();
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {

			var selectdata='<li id ="geartype_list_li" data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Transmission : </strong> &nbsp;'+name+'<span class="cross" ng-show="geartype">&#x2716;</span></li>';
			$jQu('.ss_select_info .list-group').append(selectdata);
			$jQu('.ss_data').append(res.data);
			get_step_no();
			$jQu('.ss_data .loader').hide();
        }
        else {
          warningMessage(res.message);
          	$jQu('.ss_data .loader').hide();
        }
      }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
           warningMessage(res.message);
        }
        	$jQu('.ss_data .loader').hide();
      });
      e.preventDefault();
	    
	
	    
  });


  
  $jQu(document).on('click', 'a.year_submit', function(e) {
	   	if (!checkIsValidYear($jQu("#year"))) {
			e.preventDefault();
		}else{
			var name        =$jQu("#year").val();
			var rec_id      =$jQu("#year").val();
			$jQu('.yearlist').hide();
			
			var selectdata='<li id ="year_list_li" data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Year : </strong> &nbsp;'+name+'<span class="cross" ng-show="yearlist">&#x2716;</span></li>';
			$jQu('.ss_select_info .list-group').append(selectdata);
			$jQu('#Odometer_reading_set').show();
			get_step_no();
			e.preventDefault();
		}
  });*/

  /*Step 5 click code*/
  $jQu(document).on('click', '#Odometer_reading_set .btn.next', function(e) {
	   	var name  =$jQu('#Odometer_reading').val();
		if(name==''){
			  $jQu('#Odometer_reading').addClass("error_cls");
			  e.preventDefault();
		}else{
			 $jQu('#Odometer_reading').removeClass("error_cls");
			$jQu('#Odometer_reading_set').hide();
			
			var selectdata='<li id ="odometer_reading_li" data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Odometer : </strong> &nbsp;'+name+'<span class="cross" ng-show="Odometer_reading_set">&#x2716;</span></li>';
			$jQu('.ss_select_info .list-group').append(selectdata);
			$jQu('#location_or_city').show();
			$jQu( "#City" ).focus();
			 get_step_no();
		}
	  
  });
 /*Step 5 click code end*/
  /*Step 6 click code*/
  $jQu(document).on('click', '#location_or_city .btn.next', function(e) {
	   	var name  =$jQu('#City').val();
		if(name==''){
			  $jQu('#City').addClass("error_cls");
			  e.preventDefault();
		}else{
			 $jQu('#City').removeClass("error_cls");
			$jQu('#location_or_city').hide();
			
			var selectdata='<li id ="location_or_city_li" data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Your Location or City : </strong> &nbsp;'+name+'<span class="cross" ng-show="location_or_city">&#x2716;</span></li>';
			$jQu('.ss_select_info .list-group').append(selectdata);
			$jQu('#sell_car_price_set').show();
			$jQu( "#sell_car_price" ).focus();
			get_step_no();
		}
	  
  });
 /*Step 6 click code end*/
  /*Step 7 click code*/
   $jQu(document).on('click', '#sell_car_price_set .btn.next', function(e) {
	   	var name  =$jQu('#sell_car_price').val();
	   
	   	
		if(name==''){
			  $jQu('#sell_car_price').addClass("error_cls");
			  e.preventDefault();
		}else{
		if (jQuery('#BankSettle').prop('checked') == true) {
			var name2  =$jQu('#bank_settlementvalue').val();
		
			if(name2==''){
			  $jQu('#bank_settlementvalue').addClass("error_cls");
			  e.preventDefault();
		   }else{
			   
			$jQu('#sell_car_price').removeClass("error_cls");
			$jQu('#bank_settlementvalue').removeClass("error_cls");
			$jQu('#sell_car_price_set').hide();
			
			var selectdata='<li id ="sell_car_price_li"  data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Expected Price : </strong> &nbsp;'+name+'  <strong>&nbsp;&nbsp;Bank Settlement Value:</strong>  &nbsp;'+name2+' <span class="cross" ng-show="sell_car_price_set">&#x2716;</span></li>';
			$jQu('.ss_select_info .list-group').append(selectdata);
			$jQu('#final_step_set').show();
			$jQu( "#about_vehicle" ).focus();
			get_step_no();
			   
		   }
			
		}else{
			
			$jQu('#sell_car_price').removeClass("error_cls");
			$jQu('#sell_car_price_set').hide();
			
			var selectdata='<li id ="sell_car_price_li"  data-val="'+name+'" class="list-group-item list-group-item-info" ><strong>Expected Price : </strong> &nbsp;'+name+'<span class="cross" ng-show="sell_car_price_set">&#x2716;</span></li>';
			$jQu('.ss_select_info .list-group').append(selectdata);
			$jQu('#final_step_set').show();
			$jQu( "#about_vehicle" ).focus();
			 get_step_no();
		}
		}
	  
  });
 /*Step 7 click code end*/
  $jQu(document).on('click', '.list-group li span', function(e) {
	var step_show      = $jQu(this).attr('ng-show');
	$jQu(this).closest( "li" ).nextAll().remove()
	$jQu(this).closest( "li" ).remove()
	$jQu('#ss_data .step_wrapper').hide();
	$jQu('#formCarsNewinfo fieldset').hide();
	$jQu('#final_step_set').hide();
	
	$jQu('.'+step_show).show();
	$jQu('.'+step_show+' input').focus();
	 get_step_no();

	
    });
  /*final step*/	
$jQu(document).on('click', '#final_step_set .btn.next', function(e) {
		var name                    =$jQu("#name").val();
		var brand_list_li      		=$jQu('#brand_list_li').attr('data-val');
		var model_list_li      		=$jQu('#model_list_li').attr('data-val');
		var variant_list_li    		=$jQu('#variant_list_li').attr('data-val');
		//var fueltype_list_li   		=$jQu('#fueltype_list_li').attr('data-val');
		//var geartype_list_li   		=$jQu('#geartype_list_li').attr('data-val');
		
		var year_list_li		    =$jQu('#year_list_li').attr('data-val');
		var odometer_reading_li		=$jQu('#odometer_reading_li').attr('data-val');
		var sell_car_price_li       =$jQu('#sell_car_price_li').attr('data-val');
		var bank_settlementvalue       =$jQu("#bank_settlementvalue").val();
		var user_id                 =$jQu('#user_id').val();
		var c_user_id               =$jQu('#c_user_id').val();
		var lead_id                 =$jQu('#lead_id').val();
		var about_vehicle           =$jQu('#about_vehicle').val();
		var address                 =$jQu('#City').val();

	   $jQu('#final_step_set').hide();
	
        $jQu('#about_vehicle').hide();
        $jQu('#ss_select_info').hide();
	    $jQu('.ss_data .loader').show();
	    var siteUrl='<?php echo get_site_url(); ?>';
	    $jQu('.progress_bar, .ss_title').hide();
	    successMessage('<h2>Please wait while your application is being submitted.</h2>');
	    $jQu('html, body').animate({
				scrollTop: $jQu("#formCarsNew").offset().top -200
		}, 500);
	  
      var dataArr = $jQu(this).serializeArray();
      dataArr.push({ name: "action", value:"selluscars_ajax"});
	  dataArr.push({ name: "task", value:"save_car_details"});
	  dataArr.push({ name: "name", value:name});
	  dataArr.push({ name: "make", value:brand_list_li});
	  dataArr.push({ name: "model", value:model_list_li});
	  dataArr.push({ name: "variant", value:variant_list_li});
	 // dataArr.push({ name: "fuel_type", value:fueltype_list_li});
	  //dataArr.push({ name: "transmission", value:geartype_list_li});
	  dataArr.push({ name: "year", value:year_list_li});
	  dataArr.push({ name: "odometer", value:odometer_reading_li});
	  dataArr.push({ name: "expected_price", value:sell_car_price_li});
	  dataArr.push({ name: "bank_settlementvalue", value:bank_settlementvalue});
	  dataArr.push({ name: "about_vehicle", value:about_vehicle});
	  dataArr.push({ name: "Location", value:address});
	  dataArr.push({ name: "user_id", value:user_id});
	  dataArr.push({ name: "c_user_id", value:c_user_id});
	  
	  dataArr.push({ name: "zoho_id", value:lead_id});
      dataArr.push({ name: "security", value:window.selluscars_site_nonce});
      $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: dataArr,
        crossDomain: true,
        dataType: 'json'
      }).done(function (response) {
        $jQu('.ss_data .loader').hide();
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {
           
             location.replace(siteUrl+'/thank-you/?lead_id='+lead_id);
		 
			
        }
        else {
          warningMessage(res.message);
        }
      }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
           warningMessage(res.message);
        }
      });
      e.preventDefault();
  });
 /*final step end*/	
	$jQu(document).on('click', 'a.car_button, .sell_now_button_2 a, .sell_now a', function(e) {  
		scroll_top();
	});
  
 function scroll_top(){
	    $jQu('html, body').animate({
        scrollTop: $jQu("form").offset().top -100
    }, 2000);	
	return false;
 }
  function get_step_no(){
	  var totalSteps ='<?php echo $this->totalSteps; ?>';
	  var total_step=100/totalSteps;
	  var len=$jQu("#ss_select_info ul li").length;
	  var tot_psnt =total_step*(len+1);
	   $jQu('.progress_bar .total_fill').empty('');
       $jQu(".progress_bar .total_fill").css("width", tot_psnt+"%");
       var percent= Math.round(tot_psnt);
       var step_no=len+1;
       $jQu('.progress_bar .total_fill').append(percent+"%");
       
 }
 $jQu(document).on('click', 'a.car_button, .sell_now_button_2 a, .sell_now a', function(e) {  
	scroll_top();
  });
   function sortUlModel(){
	   sortUl('model', 'model_list_ul');
   }
   function sortUlVariant(){
	   sortUl('variant', 'variant_list_ul');
   }
    function sortUlYear(){
	   sortUl('year', 'year_list_ul');
   }
    function sortUlMake(){
	   sortUl('brand', 'brand_list_ul');
   }
   
   
  
  function sortUl(in_id, list_id) {

   var input, filter, ul, li, a, i, txtValue;
   input = document.getElementById(in_id);
   filter = input.value.toUpperCase();
   ul = document.getElementById(list_id);
   li = ul.getElementsByTagName("li");
   for (i = 0; i < li.length; i++) {
       a = li[i].getElementsByTagName("a")[0];
       txtValue = a.textContent || a.innerText;
       if (txtValue.toUpperCase().indexOf(filter) > -1) {
           li[i].style.display = "";
       } else {
           li[i].style.display = "none";
       }
   }
   }
   $jQu(document).on('keydown', 'input#brand', function(e) {
	var id=$jQu(this).attr('id');
	var action = '';
    var current = $jQu('#'+id+'_list').find('ul li:visible.current');
    if (e.which == 40) {
      if(current.length == 0){
		  current = $jQu('#'+id+'_list').find('ul li:visible:first');
	  }else{
		  current.removeClass('current');
		  current = current.nextAll('li:visible:first');
	 }
	 action = 'next';
    }else if (e.which == 38) {
      if(current.length == 0){
		   current = $jQu('#'+id+'_list').find('ul li:visible:first');
	  }else{
		  current.removeClass('current');
		  current = current.prevAll('li:visible:first');
	 }
	  action = 'prev';
    }else if (e.which == 8) {
		$jQu('#'+id+'_list_ul').show();
	}
     
	 var i =$jQu('#'+id+'_list li').index( current );
	 if((i== -1 || i == $jQu('#'+id+'_list li').length) && action == 'next'){
		  current = $jQu('#'+id+'_list').find('ul li:visible:first');
	 }else if(i == -1  && action == 'prev'){
		 current = $jQu('#'+id+'_list').find('ul li:visible:last');
	 }
	 current.addClass('current');
     moveContent(id, current);
	 if (e.which == 13 && current.length > 0){
		 current.find('a').trigger( "click" );
		return false;
	}
});
function moveContent(id, current) {
	var i =$jQu('#'+id+'_list_ul li:visible').index( current );
	var scroll = i * 42;
	console.log("[here]", scroll);
    $jQu('#'+id+'_list_ul').scrollTop(scroll);

}
function bank_div_show() {
if (jQuery('#BankSettle').prop('checked') == true) {
	  var str='<label for="bank_settlementvalue" class="col-form-label">Bank Settlement Value: </label><span class="price_icon"><?php echo $this->priceIcon; ?></span><input class="form-control" type="hidden" id="bank_settlement_true" name="bank_settlement_true" value="1" ><input class="form-control number number numVal" required placeholder="Bank Settlement Value" type="text" id="bank_settlementvalue" name="bank_settlementvalue" value="" autocomplete="off" maxlength="11">';
	       $jQu('#settle_div').empty();
           $jQu('#settle_div').html(str);
} else {
	$jQu('#settle_div').empty();
}
}
</script>
