<?php
/**
 * Created by PhpStorm.
 * User: oculus
 * Date: 1/30/2017
 * Time: 9:46 AM
 */
$id         =0;
global $wpdb;

?>

<div class="wrap">
	<?php settings_errors(); ?>
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    <h2><?php echo $pagetitle; ?> </h2>
    
			<form method="post" action="options.php">
			<?php screen_icon(); 
			     settings_fields( 'selluscars_options_group' ); 
			?>
			   <table cellspacing="0" class="wp-list-table widefat fixed posts">
					<tbody>
						<tr>
							<td width="20%">Redeem Limit</td>
                            <td>
								<input type="number" id="<?php echo $this->redeemKey ?>" name="<?php echo $this->redeemKey ?>" value="<?php echo get_option($this->redeemKey); ?>" />
							</td>
                        </tr>
                        <tr>
							<td width="20%">One Earned Point</td>
                            <td>
								<input type="text" id="<?php echo $this->earnedPointKey ?>" name="<?php echo $this->earnedPointKey ?>" value="<?php echo get_option($this->earnedPointKey); ?>" />($)
							</td>
                        </tr>
                        
                        <tr>
							<td width="20%">Slider Heading</td>
                            <td>
								<input type="text" id="<?php echo $this->sliderTextHeading ?>" name="<?php echo $this->sliderTextHeading; ?>" value="<?php echo get_option($this->sliderTextHeading); ?>" />
							</td>
                        </tr>
                        
                        <tr>
							<td width="20%">Slider Description</td>
                            <td>
							 <textarea class="medium required"  id="<?php echo $this->sliderTextDescription ?>" name="<?php echo $this->sliderTextDescription ?>"><?php echo get_option($this->sliderTextDescription); ?></textarea>
							</td>
                        </tr>
                        
                        <tr>
							<td width="20%">Market Agency Title</td>
                            <td>
								<input type="text" id="<?php echo $this->marketAgencyTitle ?>" name="<?php echo $this->marketAgencyTitle; ?>" value="<?php echo get_option($this->marketAgencyTitle); ?>" />
							</td>
                        </tr>
                        
                        <tr>
							<td width="20%">Market Agency Description</td>
                            <td>
							 <textarea class="medium required"  id="<?php echo $this->marketAgencyDescription ?>" name="<?php echo $this->marketAgencyDescription ?>"><?php echo get_option($this->marketAgencyDescription); ?></textarea>
							</td>
                        </tr>
                        
                         <tr>
							<td width="20%">Currency Mode</td>
                           
							 <td>
								<input type="text" id="<?php echo $this->currencyMode ?>" name="<?php echo $this->currencyMode; ?>" value="<?php echo get_option($this->currencyMode); ?>" /><span></span>
							</td>
							
                        </tr>
                        
                        <tr><td><h2>Paypal Setting</h2></td></tr>
                        <tr>
							<td width="20%">Paypal Email</td>
                           
							 <td>
								<input type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" id="<?php echo $this->paypalEmailAddress ?>" name="<?php echo $this->paypalEmailAddress; ?>" value="<?php echo get_option($this->paypalEmailAddress); ?>" />
							</td>
							
                        </tr>
                        <tr>
							<td width="20%">Paypal Sandbox</td>
                           
							 <td>
								 
								<input type="checkbox" id="<?php echo $this->paypalSandoxActive ?>" name="<?php echo $this->paypalSandoxActive; ?>" <?php if(get_option($this->paypalSandoxActive)=== 'on') echo 'checked="checked"';?>  />
								
								<span>Enable Paypal Sandbox</span><br/><span>PayPal sandbox can be used to test payments. Sign up for a developer account </span>
							</td>
							
                        </tr>
                        
                        <tr><td><h2>Stripe Setting</h2></td></tr>
                        <tr>
							<td width="20%">Stripe API Key</td>
                           
							 <td>
								<input type="text" id="<?php echo $this->stripeApiKeyValue ?>" name="<?php echo $this->stripeApiKeyValue; ?>" value="<?php echo get_option($this->stripeApiKeyValue); ?>" />
							</td>
							
                        </tr>
                        <tr>
							<td width="20%">Stripe Publishable Key</td>
                           
							 <td>
								<input type="text" id="<?php echo $this->stripePublishableKeyValue ?>" name="<?php echo $this->stripePublishableKeyValue; ?>" value="<?php echo get_option($this->stripePublishableKeyValue); ?>" />
							</td>
							
                        </tr>
                       <tr>
							<td width="20%">Student ID Tooltip Text</td>
                            <td>
							 <textarea class="medium required"  id="<?php echo $this->StudentIdTooltipText ?>" name="<?php echo $this->StudentIdTooltipText ?>"><?php echo get_option($this->StudentIdTooltipText); ?></textarea>
							</td>
                        </tr>
                        <tr><td><h2>Business Setting</h2></td></tr>
                         <tr>
							<td width="20%">Business Membership Amount</td>
                           
							 <td>
								<input type="text" id="<?php echo $this->businessSubscriptionAmount ?>" name="<?php echo $this->businessSubscriptionAmount; ?>" value="<?php echo get_option($this->businessSubscriptionAmount); ?>" />($)
							</td>
							
                        </tr>
                        <tr>
							<td width="20%">Business Renewal Period</td>
                           
							 <td>
								<input type="number" id="<?php echo $this->businessRenewalPeriod ?>" name="<?php echo $this->businessRenewalPeriod; ?>" value="<?php echo get_option($this->businessRenewalPeriod); ?>" /><span>  e.g 1,2 year</span>
							</td>
							
                        </tr>
                        <tr>
							<td width="20%">Amount raised per business registration</td>
                            <td>
								<input type="number" id="<?php echo $this->raisedPerBusinessAmountKey ?>" name="<?php echo $this->raisedPerBusinessAmountKey ?>" value="<?php echo get_option($this->raisedPerBusinessAmountKey); ?>" />($)
							</td>
                        </tr>
                         <tr>
							<td width="20%">Points per business registration</td>
                            <td>
								<input type="number" id="<?php echo $this->earnedBusinessPointKey ?>" name="<?php echo $this->earnedBusinessPointKey ?>" value="<?php echo get_option($this->earnedBusinessPointKey); ?>" />
							</td>
                        </tr>
                        <tr>
							<td width="20%">Business Esign Url</td>
                            <td>
								<input type="url" id="<?php echo $this->businessEsignUrl ?>" name="<?php echo $this->businessEsignUrl ?>" value="<?php echo get_option($this->businessEsignUrl); ?>" />
							</td>
                        </tr>
                        <tr>
							<td width="20%">Coach Esign Url</td>
                            <td>
								<input type="url" id="<?php echo $this->coachEsignUrl ?>" name="<?php echo $this->CoachEsignUrl ?>" value="<?php echo get_option($this->coachEsignUrl); ?>" />
							</td>
                        </tr>
                        <tr>
							<td width="20%">Agreement Content</td>
                            <td>
								
								<?php 
									$settings = array( 'textarea_rows' => 10 );
									wp_editor(get_option($this->agreementContent) ,$this->agreementContent, $settings);
								?>
							</td>
                        </tr>
                        <tr>
							<td width="20%">Parent Permission Content</td>
                            <td>
								
								<?php 
									$settings = array( 'textarea_rows' => 10 );
									wp_editor(get_option($this->parentPermissionContent) ,$this->parentPermissionContent, $settings);
								?>
							</td>
                        </tr>
                        <tr>
							<td colspan="2"><?php  submit_button(); ?></td>
                        </tr>
                    </tbody>
			    </table>
		   
			</form>
</div>

