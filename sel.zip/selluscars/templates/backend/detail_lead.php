<?php
/**
 * Created by PhpStorm.
 * User: oculus
 * Date: 1/30/2017
 * Time: 9:46 AM
 */
$id         =0;
global $wpdb;
$results=array();
$data=array();
if(isset($_GET['id'])){
	  $id=$_GET['id'];
	  $data['id']=$id;
	  
	  
	if(isset($_POST['submit']))
	{
		$dataArray=array();
		$dataArray['id']            =$_POST['id'];
		$dataArray['agent_comment'] =$_POST['agent_comment'];
		$dataArray['contacted']     =$_POST['contacted'];
		$dataArray['action']        =($dataArray['id']==0?"add":"edit");
		
		
		
		if($dataArray['contacted']==''){
			$dataArray['contacted']=0;
		}
	
		$id = $this->createQuery($this->tableUserCarDetails, $dataArray, true);
		if (empty($dataArray['id'])) {
			$message = "Lead saved successfully.";
		} else {
			$message = "Lead updated successfully.";
		}

	}
	  $results=$this->getMembersAllData($data);
	/*  $name='ADRENO';
	  $year='2006,2007,2008,2009,2010,2011,2012,2013,2016,2014,2015';
	  $re = $this->getData($this->tableMake, "WHERE status=1 AND name='".$name."'");
	   if(count($re)>=0){
			  if(!empty($year) && !empty($re[0]['years']) && $re[0]['years']!=$year ){
			  	 $newYear = $this->createYearString($re[0]['years'], $year);
				  $fdata['id']      =$re[0]['id'];
				  $fdata['action']  ='edit';
				  $fdata['years']   =$newYear;
				  $id = $this->createQuery($this->tableMake, $fdata);
			  }
		}
	  echo '<pre>';
	  print_r($re);
	  echo '</pre>';
	  exit;*/
	  $first_name = get_user_meta( $_GET['user_id'], 'first_name', true ); 
	  $last_name  = get_user_meta( $_GET['user_id'], 'last_name', true ); 
    
}
if(count($results)>0){
	//  $images=$this->getCarImagesById($id);
?>
<style>
th.title {
    font-size: 30px;
    font-weight: bold;
}
img.mobile_img {
    width: 200px;
    height: 200px;
}
</style>
<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
        <h2><?php echo "Lead Details"; ?></h2>
        
        
         <table cellspacing="0" class="wp-list-table view widefat fixed posts">
            <tbody>
			 <tr>
			  <th class="title" width="20%">User Details</th>
            </tr>
            <tr>
			  
                <th width="20%">Name</th>
                <td><?php echo $first_name.' '.$last_name; ?></td>
            </tr>
             <tr>
                <th width="20%">Email</th>
                <td><?php echo $results[0]['user_email']; ?></td>
            </tr>
             <tr>
                <th width="20%">Phone</th>
                <td><?php echo $results[0]['phone']; ?></td>
            </tr>
            <tr>
                <th width="20%">Your Location or City</th>
                <td><?php echo $results[0]['Location']; ?></td>
            </tr>
			 <tr>
			  <th class="title"  width="20%">Car Details</th>
            </tr>
			<tr>
                <th width="20%">Make</th>
                <td><?php echo $results[0]['make']; ?></td>
            </tr>
			<tr>
                <th width="20%">Model</th>
                <td><?php echo $results[0]['model']; ?></td>
            </tr>
			<tr>
                <th width="20%">variant</th>
                <td><?php echo $results[0]['variant']; ?></td>
            </tr>
		<?php/*	<tr>
                <th width="20%">Fuel type</th>
                <td><?php echo $results[0]['fuel_type']; ?></td>
            </tr>
			<tr>
                <th width="20%">Transmission</th>
                <td><?php echo $results[0]['transmission']; ?></td>
            </tr>
			*/ ?>
			<tr>
                <th width="20%">year</th>
                <td><?php echo $results[0]['year']; ?></td>
            </tr>
			<tr>
                <th width="20%">Odometer reading</th>
                <td><?php echo $results[0]['odometer']; ?></td>
            </tr>
			
			<tr>
                <th width="20%">Expected price</th>
                <td><?php echo $results[0]['expected_price']; ?></td>
            </tr>
            <tr>
                <th width="20%">Bank settlement value</th>
                <td><?php echo $results[0]['bank_settlementvalue']; ?></td>
            </tr>
            <tr>
			
                <th width="20%">Extra information</th>
                <td><?php echo $results[0]['about_vehicle']; ?></td>
            </tr>
			<?php /*<tr>
			  <th class="title"  width="20%">Images of Cars</th>
            </tr>
			<tr>
               
                <td colspan='2'>
				
				<table cellspacing="0" class="">
				<tbody>
					<tr>
				<?php if(count($images)>0){ 
					foreach ($images as $image){
				
				?>
				
			
				    <td><img class="mobile_img" src="<?php echo $image['image_url']; ?>"></td>
				
				
				<?php } } ?>
				</tr>
				
				<?php */ ?>
				</tbody>
				</table>
				
				
				</td>
            </tr>
			
			
				<tr>
					<td colspan='2'>
						<?php if(isset($message) && $message!=''){ ?>
						<div id="message" class="updated"><p><?php echo $message; ?></p></div>
						<?php } ?>
						<form name="form" id="form" method="post" action="">
							<table cellspacing="0" class="wp-list-table widefat fixed posts">
								<tbody>
								
								<td width="20%">Agent Comment</td>
									<td>
									   <textarea name="agent_comment" class="medium required" ><?php echo @$results[0]['agent_comment']; ?></textarea>
									</td>
								</tr>
								<tr>
									<td width="20%">Contacted</td>
								<td>
									<input type="checkbox" id="contacted" name="contacted" value="1" <?php echo (@$results[0]['contacted']==1 ? 'checked' : '');?>>
								</td>
								</tr>
								<tr>
									<td colspan="2"><input type="submit" class="button button-primary" name="submit" id="submit" value="<?php echo $id==0?'Save':'Update'; ?>" />
										<input type="button" name="cancel" class="button button-primary" id="cancel" value="Cancel" />
										<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
									</td>
								</tr>
								</tbody>
							</table>
						</form>
				 
					</td>
				</tr>
            <tr>
                <td colspan="2"><a href="<?php echo $viewPage; ?>" class="button button-primary">Back To Member</a>
            </tr>
            </tbody>
        </table>
		<div class="car_images">
		<?php
	/*	if(count($images)>0){
		foreach ($images as $image){
			echo $image['image_url'];
		}
		
		}*/
		
		?>
		
		</div>
 </div>
  <?php } ?>

