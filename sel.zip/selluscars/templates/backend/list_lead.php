<?php
/**
 * Created by PhpStorm.
 * User: oculus
 * Date: 10/23/2020
 * Time: 1:46 PM
 */
//$search_data=array();
//$psearch=trim($_REQUEST['search_text'])."&community_id=".trim($_REQUEST['community_id'])."&membership_id=".trim($_REQUEST['membership_id']);
if(isset($_REQUEST['lead_search'])){
	 $search =  $_REQUEST['lead_search'];
}
$search_data= $_REQUEST;
$results            =$this->getMembersAllData($search_data);
$total_record      =$this->getMembersAllData($search_data, true);
$paging            =$libObj->getPages($total_record, $page,'lead',$psearch);

//echo "<pre>";
 //print_r($results);
 //echo "</pre>";

?>

<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
	    <div class="ls_section">
		<div class="ls_left"><h2><?php echo $pagetitle; ?>
		   <span class="subtitle"><?php if(!empty($_REQUEST['lead_search']!="")){ echo "Search results for “".$_REQUEST['lead_search']."”";} ?></span></h2></div>
		<div class="ls_right">
			<form action="" method="post">
				<input type="search" id="lead_search" name="lead_search" value="<?php echo $_REQUEST['lead_search'] ?>">
				<input type="submit" value="Search">
			</form>	
		</div>
	</div>
   
    <div class="fullwidth-panel">
        <table cellspacing="0" class="wp-list-table widefat fixed pages">
            <thead>
            <tr>
                <th>User Name</th>
                <th>Email</th>
                <th>Phone</th>
				<th>Action</th>
               
            </tr>
            </thead>
            <tbody>
            <?php if($total_record>0){
                $count=0;
				//print_r($results);
                foreach($results as $k=>$v) {
					
				//$first_name = get_user_meta( $v['user_id'], 'first_name', true ); 
				//$last_name  = get_user_meta( $v['user_id'], 'last_name', true ); 
					?>
                    <tr <?php echo ($count%2==0?"class='alternate'":''); $count++; ?>>
                        <td>
                            <?php echo $v['f_name'].' '.$v['l_name']; ?>
                            <div class="row-actions">
                                <form method="post" action="">
                                    <input type="hidden" name="id" value="<?php echo $v['user_id']; ?>" />
                                    <a href="<?php echo $detailPage.'&id='.$v['id'].'&user_id='.$v['user_id']; ?>">View</a>
                                    <?php /* | <input type="submit" class="deleteWithChildRecord custom-button" name="delete" value="Delete" /> */ ?>
                                   
                                </form>
                            </div>
                        </td>
                        <td>
							<?php echo $v['user_email']; ?>
                        </td>
						<td>
							<?php echo $v['phone']; ?>
                        </td>
						<td>
							<a href="<?php echo $detailPage.'&id='.$v['id'].'&user_id='.$v['user_id']; ?>">View Lead Details</a>
                        </td>
                        
                    </tr>
                <?php }} else { ?>
                <tr><td colspan="1" class='empty'>No Member found.</td></tr>
            <?php } ?>
            </tbody>
            <tfoot>
            <tr>
				<th>User Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Action</th>
            </tr>
            </tfoot>
        </table>
    </div>
    <div class="tablenav bottom">
        <div class="alignleft actions"></div>
        <?php if( isset($paging) && $paging!= '' ){ echo $paging;} ?>
        <br class="clear">
    </div>
</div>

