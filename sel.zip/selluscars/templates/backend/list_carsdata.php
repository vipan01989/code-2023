<?php
/**
 * Created by PhpStorm.
 * User: oculus
 * Date: 15/01/2020
 * Time: 9:46 AM
 */
if(!empty($_GET['prs'])){?>
<script type="text/javascript">
		window.location.href="<?php echo $viewPage; ?>";	
</script>
	
<?php	} 
$id         =0;
global $wpdb;
$results=array();
$cls='';
$file_path       ='';
$total_record    =0;
$total_saved     =0;
$total_percent   =0;
$file_id         =0;
$clsupload       ='';
$totalcomplted   ='';
$results = $this->getAllDataOfTable($this->selluscarCsvFileStatus, "ORDER by id DESC LIMIT 0,1");

//print_r($results);
//exit;

if(count($results)>0 && empty($results[0]['status'])){
  $file_id       = $results[0]['id'];
  $total_record  = $results[0]['total_record'];
  $total_saved   = $results[0]['total_saved'];
  $total_percent = $results[0]['total_percent'];
  $file_path     = $results[0]['file_path'];
  $totalcomplted = $results[0]['total_saved']."/".$results[0]['total_record'];
  if(!empty($total_percent)){
	  $cls="show_progress";
  }
  $clsupload='hidden';
  	
}
  
?>
<style>



.hidden{
	   display: none;
}
.previous_file_main.show_progress, .show_progress{
    display: block;
}
.button.button-primary {
    margin-left: 10px;
     margin-top: 10px;
    
}
button#Stop_import {
    margin-left: 20px;
    min-width:100px;
}


.loader, #loader {
    margin-top: 10px;
    float: left;
}


</style>
<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
        <h2><?php echo 'Import Car data'; ?>
        <span class="subtitle"><?php if($search_text!=""){ echo "Search results for “".$search_text."”";} ?></span></h2>
        

       <div id="alertMsg" class="alert"></div>

    <form name="form" id="form" action="" method="post" enctype="multipart/form-data">
		<h2>Import All Details Data</h2>
        <table cellspacing="0" class="wp-list-table widefat fixed posts import_student">
            <tbody>
			
             <tr class="clsupload <?php echo $clsupload ?>">
                <td  width="20%">Select File</td>
                <td class="">
					<input type="file" id="file" name="file"  class="required" multiple="" accept=".csv" aria-required="true"/>
                    
                </td>
             </tr>
     
           
            <tr class="clsupload <?php echo $clsupload ?>">
                <td colspan="2"><input type="submit" class="button button-primary" name="submit" id="submit" value="Import New CSV" />
               
                </td>
            </tr>
			<tr class="progressouter">
				<td colspan="2">
					  <span class="totalComplted"><?php echo $totalcomplted; ?></span>
					<div class="progress <?php echo $cls; ?>">
					   
						<div class="progress-bar" role="progressbar" style="width:<?php echo $total_percent; ?>%">
						</div>
					</div>
				</td>
			</tr>
			
			<?php if(count($results)>0 && empty($results[0]['status'])){
			  $cls1="show_progress";
			}
				
				?>	
			  <tr class='previous_file_main hidden <?php echo $cls1; ?>'>
				<td colspan="2">       
					<div class="resume">
				
				    <button type="button" class="button button-primary" name="previous_file" id="previous_file" >Resume Previous CSV</button>
					<button type="button" class="button button-primary" name="upload_new_file" id="upload_new_file" >Select New File</button>
					
					
					</div>
				</td>
			</tr>
			<?php //} ?>
			
			 <tr>
				<td colspan="2"><div id="loader"></div><button type="button" class="button button-primary hidden" name="Stop_import" id="Stop_import" >Stop</button></td>
            </tr>
			
			
            
            </tbody>
        </table>
    </form>
     <h2>Import Makes Form  Main Data</h2>
      <form name="make" id="make" action="" method="post" enctype="multipart/form-data">
		     <div id="alertMakeMsg" class="alert"></div>
         <table cellspacing="0" class="wp-list-table widefat fixed posts ">
            <tbody>
			 <tr>
                <td colspan="2"><input type="submit" class="button button-primary" name="make_submit" id="make_submit" value="Import Make" />
                 <div class="loader"></div>
                </td>
            </tr>
             <tr>
				<td colspan="2">
					  <span class="totalComplted"></span>  
					<div class="progress">
						<div class="progress-bar" role="progressbar">
						</div>
					</div>
				</td>
			</tr>			
			</tbody>
        </table>
      </form>
      <h2>Import Model Form  Main Data</h2>
      <form name="model" id="model" action="" method="post" enctype="multipart/form-data">
		    <div id="alertModelMsg" class="alert"></div>
         <table cellspacing="0" class="wp-list-table widefat fixed posts ">
            <tbody>
			 <tr>
                <td colspan="2"><input type="submit" class="button button-primary" name="model_submit" id="model_submit" value="Import Model" />
                   <div class="loader"></div>
                </td>
            </tr>
             <tr>
				<td colspan="2">
					<span class="totalComplted"></span>         
					<div class="progress">
						<div class="progress-bar" role="progressbar">
						</div>
					</div>
				</td>
			</tr>
			</tbody>
        </table>
      </form>
       <h2>Import Variant Details From Main Data</h2>
      <form name="variant" id="variant" action="" method="post" enctype="multipart/form-data">
		 <div id="alertVariantMsg" class="alert"></div>
         <table cellspacing="0" class="wp-list-table widefat fixed posts ">
            <tbody>
			 <tr>
                <td colspan="2"><input type="submit" class="button button-primary" name="variant_submit" id="variant_submit" value="Import Variant" />
                   <div class="loader"></div>
                </td>
            </tr>
            <tr>
				<td colspan="2">
					<span class="totalComplted"></span>  
					<div class="progress">
						<div class="progress-bar" role="progressbar">
						</div>
					</div>
				</td>
			</tr>
			</tbody>
        </table>
      </form>
    <?php /*  
      <h2>Import variant Details  Form  Main Data</h2>
      <form name="variantDetails" id="variantDetails" action="" method="post" enctype="multipart/form-data">
		 <div id="alertvariantDetailsMsg" class="alert"></div>
         <table cellspacing="0" class="wp-list-table widefat fixed posts ">
            <tbody>
			 <tr>
                <td colspan="2"><input type="submit" class="button button-primary" name="variantDetails_submit" id="variantDetails_submit" value="Import Variant Details" />
                   <div class="loader"></div>
                </td>
            </tr>
            <tr>
				<td colspan="2">   
					<span class="totalComplted"></span>      
					<div class="progress">
						
						<div class="progress-bar" role="progressbar">
						</div>
					</div>
				</td>
			</tr>
			</tbody>
        </table>
      </form> */ ?>
</div>
<script type="text/javascript">

	window.stop_on     =0;
	var file_path       ="<?php echo $file_path ?>";
	var total_record    ="<?php echo $total_record ?>";
	var total_saved     ="<?php echo $total_saved ?>";
	var total_percent   ="<?php echo $total_percent ?>";
	var file_id         ="<?php echo $file_id ?>";
	
    $jQu(document).ready(function(){
      
		$jQu('#submit').on('click',function()
		{
			$jQu("#form").validate();
		});
		scroll_top();
		
    });
    
 $jQu(document).on('click', '#upload_new_file', function(event) {
	 
	// $jQu(".clsupload").show();
	  $jQu('#form .clsupload').css("display","block");
	  $jQu('#form #file').val('');
	  $jQu("#form .totalComplted").empty('');
	  $jQu(".show_progress, .progress").hide();
	 return false;
 });
 function scroll_top(){
	    $jQu('html, body').animate({
        scrollTop: $jQu("#form").offset().top -100
    }, 2000);	
	return false;
 }
$jQu(document).on('submit', '#form', function(event) {
	    var form=$jQu(this);
        var thisElement     =$jQu(this);
	    var image           = event.target.files;
	   	var file_data = $jQu('#file').prop('files')[0];
	   // var operation       = $jQu('#case').val();
	     if (form.validate()){
			if (!event.isDefaultPrevented()) {
				$jQu("#submit").hide();
				$jQu(".progress").hide();
				$jQu("#alertMsg").empty();
			
			    $jQu("#form .progress .progress-bar").empty("");
				$jQu('#form #loader').css("display","inline-block");
				    
				    var data            = new FormData();
				//	if(typeof image != "undefined" && image[0] != null) {
						data.append("file", file_data);
				//	}
					data.append("action","selluscars_ajax");
					data.append("task","save_car_temp_details");
					data.append("security",window.selluscars_site_nonce);
					

					$jQu.ajax({
					method: "POST",
					url: adminAjax,
					crossDomain: true,
					data: data,
					cache: false,
					dataType: 'json',
					processData: false, // Don't process the files
					contentType: false
					}).done(function (response) {
					var res = eval(response);
					if (res.success != "undefined" && res.success == 1) {
			            console.log('file_path:'+res.file_path+' Total:-'+ res.total_record);
			             $jQu("#form .progress").show();
			             $jQu("#form #Stop_import").show();
			             $jQu("#form .progress .progress-bar").css("width", "0.1%");
			             $jQu('#form .clsupload').css("display","none");
			             $jQu("#form .totalComplted").text("0/"+res.total_record);
                         saveCartempData(res.file_path, res.total_record, res.file_id);
					}
					else {
						warningMessage(res.message);
						$jQu("#form #submit").show();
						 $jQu('#form .clsupload').css("display","block");
						 $jQu('#form #loader').hide();

					}
					});
		
				
			
			}
		event.preventDefault();
	    }
  });
  
    
$jQu(document).on('click', '#previous_file', function(event) {
	
	if(confirm("Are you sure you want to Import Previous file data?")){
		

		$jQu("#form #Stop_import").show();
	    $jQu("#form #submit").hide();
	    $jQu("#form #previous_file").hide();
	    $jQu("#form #upload_new_file").hide();
		$jQu('#form #loader').css("display","inline-block");
		$jQu("#form .progress .progress-bar").empty("");
	
		//alert(file_path);
	    saveCartempData(file_path, total_record, file_id, total_saved, total_percent);
    }else{
        return false;
    }
    return false;
}); 
  
  
  function saveCartempData(file_path, total_record, file_id=0, total_saved=0, total_percent=0, total_call=0){
	    
	    var data     = new FormData();
	   // var jqXHR;
		data.append("action","selluscars_ajax");
		data.append("task","save_car_temp_details");
		data.append("file_path",file_path);
		data.append("total_record", total_record);
		data.append("total_saved", total_saved);
		data.append("total_percent", total_percent);
		data.append("file_id", file_id);
		data.append("total_call", total_call);
		data.append("security",window.selluscars_site_nonce);
	   
		
		// console.log("total_step:"+ window.total_step)
       
		$jQu.ajax({
			method: "POST",
			url: adminAjax,
			crossDomain: true,
			data: data,
			cache: false,
			dataType: 'json',
			processData: false, // Don't process the files
			contentType: false
		}).done(function (response) {
			var res = eval(response);
			if (res.success != "undefined" && res.success == 1) {
				 $jQu(".progress .progress-bar").css("width", res.total_percent+"%");
				 $jQu("#form .totalComplted").empty('');
				 if(stop_on!= "undefined" && stop_on!= 'yes'){
					 
					  $jQu("#form .totalComplted").text(res.total_saved+"/"+res.total_record);
					 saveCartempData(res.file_path, res.total_record, res.file_id, res.total_saved, res.total_percent, res.total_call); 
				
				 }else{
					 	 $jQu("#form .totalComplted").text(res.total_saved+"/"+res.total_record);
					     window.stop_on         =0;
					     window.file_path       =res.file_path;
					     window.total_record    =res.total_record;
					     window.file_id         =res.file_id;
					     window.total_saved     =res.total_saved;
					     window.total_percent   =res.total_percent;
					     window.total_call      =res.total_call;
					
						//window.location.href="<?php echo $viewPage;?>&prs=1";
						$jQu("#form #submit").show();
						$jQu('#form #loader').hide();
						$jQu("#form #previous_file").show();
						$jQu("#form .previous_file_main").show();
						$jQu("#form #upload_new_file").show();
						$jQu('#form #Stop_import').hide();
					
				 }
			
                 
			}
			else {
					if (res.success != "undefined" && res.success == 2) {
                    // alert('Completed');
                     successMessage(res.message);
                     $jQu("#form .totalComplted").empty('');
                     $jQu("#form .progress .progress-bar").text('CSV imported successfully');
                     $jQu("#form #submit").show();
                     $jQu('#form #loader').hide();
                     $jQu('#form #file').val('');
                     $jQu('#form #Stop_import').hide();
                      $jQu('#form .clsupload').css("display","block");
                     //$jQu("#form").reset();
                    
				 }
			}
		});
	  
  }
  

  
 //  $jQu('#Stop_import').on('click',function()
   $jQu(document).on('click', '#Stop_import', function(event) {
        	
		if(confirm("Are you sure you want to stop current process?")){
			
			 window.stop_on='yes';
			 $jQu('#form #Stop_import').hide();
			 
              
		}else{
		  return false;
		}
		return false;
            
});

$jQu(document).on('submit', '#make', function(event) {
	
	if(confirm("Are you sure you want to Import Makes data?")){
		$jQu("#make .progress .progress-bar").empty("");
       saveCarMake();
    }else{
        return false;
    }
    return false;
}); 
  
$jQu(document).on('submit', '#model', function(event) {
	
	if(confirm("Are you sure you want to Import Model data?")){
	$jQu("#model .progress .progress-bar").empty("");
     saveCarModel();
    }else{
        return false;
    }
    return false;
}); 
$jQu(document).on('submit', '#variant', function(event) {
	
	if(confirm("Are you sure you want to Import Variant data?")){
		$jQu("#variant .progress .progress-bar").empty("");
       saveCarVariant();
    }else{
        return false;
    }
    return false;
});
$jQu(document).on('submit', '#variantDetails', function(event) {
	
	if(confirm("Are you sure you want to Import Variant Details data?")){
       saveCarVariantDetails();
    }else{
        return false;
    }
    return false;
});

function saveCarVariantDetails(total_record=0, total_saved=0, total_percent=0){
	    
	    var data     = new FormData();
	     $jQu('#variantDetails .loader').css("display","inline-block");
	     $jQu('#variantDetails #variantDetails_submit').hide();
		data.append("action","selluscars_ajax");
		data.append("task","save_car_variant_details");
		data.append("total_record", total_record);
		data.append("total_saved", total_saved);
		data.append("total_percent", total_percent);
		data.append("security",window.selluscars_site_nonce);
       
		$jQu.ajax({
			method: "POST",
			url: adminAjax,
			crossDomain: true,
			data: data,
			cache: false,
			dataType: 'json',
			processData: false, // Don't process the files
			contentType: false
		}).done(function (response) {
			var res = eval(response);
			if (res.success != "undefined" && res.success == 1){
				//alert(res.total_record);
				    $jQu("#variantDetails .progress").show();
			     	$jQu("#variantDetails .progress .progress-bar").css("width", res.total_percent+"%");
			        $jQu("#variantDetails .totalComplted").text(res.total_saved+"/"+res.total_record);
				    saveCarVariantDetails(res.total_record, res.total_saved, res.total_percent)
			}else {
				if (res.success != "undefined" && res.success == 2) {
					 // alert('Completed');
					  $jQu("#variant .progress .progress-bar").text('Completed');
					  successSpecificMessage('alertvariantDetailsMsg', res.message);
					  $jQu('#variantDetails .loader').hide();
					  $jQu('#variantDetails #variantDetails_submit').show();
					  $jQu("#variantDetails .totalComplted").empty();
				}else{
					  $jQu('#variantDetails .loader').hide();
					   $jQu('#variantDetails #variantDetails_submit').show();
					   warningSpecificMessage('alertvariantDetailsMsg', res.message);
					   $jQu("#variantDetails .totalComplted").empty();
					   
				}
                    
			}
		});
	  
}
function saveCarVariant(total_record=0, total_saved=0, total_percent=0){
	    
	    var data     = new FormData();
	     $jQu('#variant .loader').css("display","inline-block");
	     $jQu('#variant #variant_submit').hide();
		data.append("action","selluscars_ajax");
		data.append("task","save_car_variant_data");
		data.append("total_record", total_record);
		data.append("total_saved", total_saved);
		data.append("total_percent", total_percent);
		data.append("security",window.selluscars_site_nonce);
       
		$jQu.ajax({
			method: "POST",
			url: adminAjax,
			crossDomain: true,
			data: data,
			cache: false,
			dataType: 'json',
			processData: false, // Don't process the files
			contentType: false
		}).done(function (response) {
			var res = eval(response);
			if (res.success != "undefined" && res.success == 1){
				//alert(res.total_record);
				    $jQu("#variant .progress").show();
			     	$jQu("#variant .progress .progress-bar").css("width", res.total_percent+"%");
			     	$jQu("#variant .totalComplted").text(res.total_saved+"/"+res.total_record);
				    saveCarVariant(res.total_record, res.total_saved, res.total_percent)
			}else {
				if (res.success != "undefined" && res.success == 2) {
					 // alert('Completed');
					  $jQu("#variant .progress .progress-bar").text('Completed');
					  successSpecificMessage('alertVariantMsg', res.message);
					  $jQu('#variant .loader').hide();
					  $jQu('#variant #variant_submit').show();
					   $jQu("#variant .totalComplted").empty('');
				}else{
					  $jQu('#variant .loader').hide();
					   $jQu('#variant #variant_submit').show();
					    $jQu("#variant .totalComplted").empty('');
					  warningSpecificMessage('alertVariantMsg', res.message);
				}
                    
			}
		});
	  
}

function saveCarModel(total_record=0, total_saved=0, total_percent=0){
	    
	    var data     = new FormData();
	     $jQu('#model .loader').css("display","inline-block");
	        $jQu('#model #model_submit').hide();
		data.append("action","selluscars_ajax");
		data.append("task","save_car_model_data");
		data.append("total_record", total_record);
		data.append("total_saved", total_saved);
		data.append("total_percent", total_percent);
		data.append("security",window.selluscars_site_nonce);
       
		$jQu.ajax({
			method: "POST",
			url: adminAjax,
			crossDomain: true,
			data: data,
			cache: false,
			dataType: 'json',
			processData: false, // Don't process the files
			contentType: false
		}).done(function (response) {
			var res = eval(response);
			if (res.success != "undefined" && res.success == 1){
				//alert(res.total_record);
					$jQu("#model .progress").show();
			     	$jQu("#model .progress .progress-bar").css("width", res.total_percent+"%");
			     		 $jQu("#model .totalComplted").text(res.total_saved+"/"+res.total_record);
				saveCarModel(res.total_record, res.total_saved, res.total_percent)
			}else {
				if (res.success != "undefined" && res.success == 2) {
					 // alert('Completed');
					  $jQu("#model .progress .progress-bar").text('Completed');
					  successSpecificMessage('alertModelMsg', res.message);
					  $jQu('#model .loader').hide();
					   $jQu('#model #model_submit').show();
					    $jQu("#model .totalComplted").empty();
				}else{
					  $jQu('#model .loader').hide();
					   $jQu('#model #model_submit').show();
					     $jQu("#model .totalComplted").empty();
					  warningSpecificMessage('alertModelMsg', res.message);
				}
                    
			}
		});
	  
}
  
function saveCarMake(total_record=0, total_saved=0, total_percent=0){
	    
	    var data     = new FormData();
	    $jQu('#make .loader').css("display","inline-block");
	     $jQu('#make #make_submit').hide();
		data.append("action","selluscars_ajax");
		data.append("task","save_car_make_data");
		data.append("total_record", total_record);
		data.append("total_saved", total_saved);
		data.append("total_percent", total_percent);
		data.append("security",window.selluscars_site_nonce);
       
		$jQu.ajax({
			method: "POST",
			url: adminAjax,
			crossDomain: true,
			data: data,
			cache: false,
			dataType: 'json',
			processData: false, // Don't process the files
			contentType: false
		}).done(function (response) {
			var res = eval(response);
			if (res.success != "undefined" && res.success == 1){
				//alert(res.total_record);
				$jQu("#make .progress").show();
			    $jQu("#make .progress .progress-bar").css("width", res.total_percent+"%");
			    $jQu("#make .totalComplted").text(res.total_saved+"/"+res.total_record);
				saveCarMake(res.total_record, res.total_saved, res.total_percent)
			}else {
				if (res.success != "undefined" && res.success == 2) {
					 // alert('Completed');
					 $jQu("#make .progress .progress-bar").text('Completed');
					  successSpecificMessage('alertMakeMsg', res.message);
					  
					  $jQu('#make #make_submit').show();
					   $jQu("#make .totalComplted").empty();
					  $jQu('#make .loader').hide();
				}else{
					  $jQu('#make .loader').hide();
					  $jQu('#make #make_submit').show();
					  $jQu("#make .totalComplted").empty();
					  warningSpecificMessage('alertMakeMsg', res.message);
				}
                    
			}
		});
	  
}



</script>
