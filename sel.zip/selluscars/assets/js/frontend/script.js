$jQu                        = jQuery;
var selected_city           ="";
var selected_communities    ="";
var selected_categories     ="";
var selected_schools        ="";
var no_community_message    ="There is no Community.";
//var max_image_size          ="1024000";
var modals					= [];
/* alert Message script */
function warningMessage(message)
{
    $jQu('#alertMsg').removeClass('alert-warning').removeClass('alert-success');
    $jQu('#alertMsg').addClass("alert-warning").html(message);
    $jQu('html, body').animate({
        scrollTop: $jQu("form").offset().top -100
    }, 2000);
}
function successMessage(message)
{
    $jQu('#alertMsg').removeClass('alert-warning').removeClass('alert-success');
    $jQu('#alertMsg').addClass("alert-success").html(message);
    $jQu('html, body').animate({
        scrollTop: $jQu("form").offset().top -100
    }, 2000);
}
function warningSpecificMessage(id,message)
{
    $jQu("#"+id).removeClass('alert-warning').removeClass('alert-success');
    $jQu('#'+id).addClass("alert-warning").html(message);
}
function successSpecificMessage(id,message)
{
    $jQu("#"+id).removeClass('alert-warning').removeClass('alert-success');
    $jQu("#"+id).addClass("alert-success").html(message);

}
function modalWarningMessage(modal,message)
{

    modal.find('.alert').removeClass('alert-warning').removeClass('alert-success');
    modal.find('.alert').addClass("alert-warning").html(message);
    
}
function modalSuccessMessage(modal,message)
{
    modal.find('.alert').removeClass('alert-warning').removeClass('alert-success');
    modal.find('.alert').addClass("alert-success").html(message);
    modal.find('form')[0].reset();
   // var timer = modal.data('timer') ? modal.data('timer') : 7000;
    var timer = 800;
    modal.delay(timer).fadeOut(200, function () {
		modal.find('.alert').removeClass('alert-warning').removeClass('alert-success').html("");
        modal.modal('hide');
        if($jQu('.modal:visible').length>0){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
    });
}



