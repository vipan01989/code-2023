<?php
/*
	Plugin Name: selluscars manage
	Plugin URI: https://www.selluscars.co.za
	Description: Manage selluscars settings.
	Author: oculus
	Version: 1.0.0
	Author URI: 
*/
session_start();
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
$selluscarsPluginUrl = plugin_dir_url(__FILE__);
$selluscarsPluginPath = plugin_dir_path(__FILE__);
if(substr($selluscarsPluginUrl, -1) == "/" || substr($selluscarsPluginUrl, -1) == "\\" ){
	$selluscarsPluginUrl  = substr($selluscarsPluginUrl, 0, strlen($selluscarsPluginUrl)-1 );
}
if(substr($selluscarsPluginPath, -1) == "/" || substr($selluscarsPluginPath, -1) == "\\" ){
	$selluscarsPluginPath  = substr($selluscarsPluginPath, 0, strlen($selluscarsPluginPath)-1 );
}

define("SC_BASE_URL", $selluscarsPluginUrl);
define("SC_BASE_PATH", $selluscarsPluginPath);
define("SC_ADMIN_URL", get_admin_url().'admin.php?page=selluscarss');
define("SC_PLUGIN_VERSION", "1.0.0");

define("SCARS_TIMEOUT_SECONDS", 30);
define("SCARS_FILE", __FILE__);

include_once('library/core.php');
include_once('library/hooks.php');
include_once('library/shortcode.php');
include_once('library/plugin.php');
$selluscars_plugin = new selluscars_plugin;
