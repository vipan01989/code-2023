<?php

//https://api-console.zoho.com/
//https://www.zoho.com/mail/help/api/using-oauth-2.html
//Client ID: 1000.UP1WJQ2WHAUEX97GP0MR1D33C5RFZH
//Client Secret: 839c1a39d7ba6955781bffdd3d14db0e6ab5547300
//http://selluscars.oculus-technologies.com/?code=1000.f3f8a5243601d2859c8524f45e829b94.09c9a45c55616d5d4c854eb4a31fecac&location=us&accounts-server=https%3A%2F%2Faccounts.zoho.com
//https://accounts.zoho.com/oauth/v2/auth?scope=ZohoCRM.modules.ALL,ZohoCRM.settings.ALL,ZohoCRM.users.ALL&client_id=1000.UP1WJQ2WHAUEX97GP0MR1D33C5RFZH&response_type=code&access_type=offline&redirect_uri=http://selluscars.oculus-technologies.com



/* Use to create create error log */
function logError($logError = false){
 
	$maindir =dirname(__FILE__);
	$cdate          = date('Y-m-d');
	$errorFileDir = $maindir . '/zohologs';
	$errorFile = $errorFileDir . '/'.$cdate.'_error.log';
	if (!file_exists($errorFileDir)) {
	@mkdir($errorFileDir, 0777, true);
	} else if (substr(fileperms($errorFileDir), 0, -3) != '777') {
				@chmod($errorFileDir, 0777);
	}

	$logErrors = $logError;
	if ($logErrors) {
		ini_set('error_log', $errorFile);
		if (!file_exists($errorFile)) {
			$fh = @fopen($errorFile, 'w');
			@fclose($fh);
			@chmod($errorFile, 0777);
		}
	}
	
}
/* Use to create save error in log file*/
function log_error($error, $onlySelected = false)
{
	if (!empty($onlySelected)) {
		 logError(true);
		 error_log(print_r($error, true));
	}
}

//https://accounts.zoho.com/oauth/v2/auth?scope=ZohoWriter.documentEditor.ALL&client_id=1000.9N38YWO4T0BX61XRGIWQR3G0SG2V1H&response_type=code&access_type=offline&redirect_uri=https://www.pleasurecruising.com.au
function getZohoAuthv2(){
	
//~ $client_id       ='1000.4STYAZQD4Y9FGW29KZUNHFSRUSNW2H';
//~ $client_secret   ='c954c26c32a994fd4ea62684541d522a85abf53ea6';
//$client_id       ='1000.9N38YWO4T0BX61XRGIWQR3G0SG2V1H';
//$client_secret   ='e13b02b8d2ca4ee3d2773a024eeb61367529c4acd0';
//$code            ='1000.7f54916e1a257cd4027c02a4cefdec8e.d01f032c7e7be84cf35a57551a1fbdde';
//$code            ='1000.3362782aff12f7603781d04ffe8535f2.8505d6e6ce84cf09dfcf486377211d94'; 

//$client_id       ='1000.UA85EZO9CK17IQ9I6T4KA880NGXG9J';
//$client_secret   ='147b6d2b4543b2c7e962dad3dfd96d7a4105c1074d';

//$code            ='1000.3138b6133ab50af628f882c0c53b8246.348aad87f733cf0be091abcc84df1958';  //selluscar

$client_id       ='1000.UP1WJQ2WHAUEX97GP0MR1D33C5RFZH';
$client_secret   ='839c1a39d7ba6955781bffdd3d14db0e6ab5547300';
$code            ='1000.f3f8a5243601d2859c8524f45e829b94.09c9a45c55616d5d4c854eb4a31fecac';  //live selluscar



$redirect_uri    ='http://selluscars.oculus-technologies.com';
$grant_type      ='authorization_code';
$fields          =array('client_id' => $client_id,'client_secret' => $client_secret,'redirect_uri' => $redirect_uri,'code' => $code, 'grant_type' => $grant_type);

//~ print_r($fields);
	
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => "https://accounts.zoho.com/oauth/v2/token",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $fields,
));

$response = curl_exec($curl);
curl_close($curl);
return $response;

}
echo $restult = getZohoAuthv2();
echo 'test';
exit;
//https://accounts.zoho.com/oauth/v2/
//auth?scope=ZohoCRM.modules.ALL,ZohoCRM.settings.ALL,ZohoCRM.users.ALL,ZohoCRM.org.ALL,aaaserver.profile.ALL,ZohoCRM.settings.functions.all,ZohoCRM.notifications.all,ZohoCRM.coql.read,ZohoCRM.files.create,ZohoCRM.bulk.all&client_id=1000.9N38YWO4T0BX61XRGIWQR3G0SG2V1H&response_type=code&access_type=offline&redirect_uri=https://www.pleasurecruising.com.au
//echo $restult = getZohoAuthv2();
//exit;
function getZohoAccessTokenV2(){
$response        =array();	
$client_id       ='1000.9N38YWO4T0BX61XRGIWQR3G0SG2V1H';
$client_secret   ='e13b02b8d2ca4ee3d2773a024eeb61367529c4acd0';
//$refresh_token   ='1000.0fac670cac8ee6fd898225dbf40c9227.3cad5830cacb699d661162c1e6927b46';// put refresh_token 
$refresh_token   ='1000.c9b16a7ce952bba13145ca207b18b9bb.d943209bcfa3eb5d1116744b874d975a';// put refresh_token 
$redirect_uri    ='https://www.pleasurecruising.com.au';
$grant_type      ='refresh_token';
$fields          =array('refresh_token' => $refresh_token, 'client_id' => $client_id, 'client_secret' => $client_secret,'redirect_uri' => $redirect_uri, 'grant_type' => $grant_type);
	
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => "https://accounts.zoho.com/oauth/v2/token",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $fields,
));
$result = curl_exec($curl);
$response = json_decode($result, true);
curl_close($curl);
return $response;

}

// $restult = getZohoAccessTokenV2();
 echo '<pre>';
 print_r($restult);
  echo '</pre>';
 exit;

function postZohoDataV2($module_api_name='Tasks',  $token=''){

    if(empty($token)){
		$token  ='1000.8c47ffa7e8bd66dffe86eee168cb6a66.d8ffabfefff65f9146045a36292bacb6';  //put access_token here 
    }
    $apiUrl ="";
	$apiUrl = "https://www.zohoapis.com/crm/v2/".$module_api_name;
	//$id='1181083000033575009';
	if(!empty($id)){
		$apiUrl = $apiUrl."/".$id;	
	}
    $authToken="Zoho-oauthtoken ".$token;
    
	  $dataArray=array(
		"Subject" => "Test",
		"Due_Date" => "2020-02-20",
		"Status" => "Deferred",
		"What_Id" => "1181083000033643001",
		"\$se_module1" => "Leads"
		);
	$fields1=array("data" => [$dataArray]);
   $fields = json_encode($fields1);


	$headers = array(
		'Content-Type: application/json',
		'Content-Length: ' . strlen($fields),
		 sprintf('Authorization: %s', $authToken)
	);
    
    $ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $apiUrl);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);

	$result = curl_exec($ch);
    $result = json_decode($result, true);

	curl_close($ch); 

return $result;
}
$results=postZohoDataV2();
if (count($results)>0 && $results['data'][0]['status']=='error')
{
 echo "here";
}
print_r($results);
//~ if(count($results)>0 && isset($results['data']) && isset($results['data'][0]['code']) && isset($results['data'][0]['details']) && $results['data'][0]['status']=='success'){
	//~ echo $results['data'][0]['details']['id'];
//~ }

//~ echo '<pre>';
//~ print_r($results);
//~ echo '</pre>';



//~ $results=postZohoDataV2();
//~ if(count($results)>0 && $results['code']=="INVALID_TOKEN" && $results['status']=="error"){
   //~ $newToken = array();
   //~ $newToken= getZohoAccessTokenV2();
   //~ if (count($newToken)>0 && array_key_exists("access_token",$newToken) )
	//~ {
		//~ echo $token=$newToken['access_token'];
	//~ }
//~ }


//~ $output['data'] = array();


//~ //$output['data'][] creates a new entry in the array
//~ $output['data'][] = array(
//~ "Subject" => "Test",
//~ "Due_Date" => "2020-02-20",
//~ "Status" => "Deferred",
//~ "What_Id" => "1181083000033643001",
//~ "\$se_module" => "Leads"
//~ );
//~ //Should now output the desired json
//~ $datas = json_encode($output);
//~ echo $datas;
//~ $curl = curl_init();
//~ curl_setopt_array($curl, array(
//~ CURLOPT_URL => "https://www.zohoapis.com/crm/v2/Tasks",
//~ CURLOPT_RETURNTRANSFER => true,
//~ CURLOPT_ENCODING => "",
//~ CURLOPT_MAXREDIRS => 10,
//~ CURLOPT_TIMEOUT => 30,
//~ CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//~ CURLOPT_CUSTOMREQUEST => "POST",
//~ CURLOPT_POSTFIELDS => $datas,
//~ CURLOPT_HTTPHEADER => array(
//~ "Authorization: Bearer 1000.1e3da7ccba8cba2577731a69b4b9b345.954e276ed097cd46eb509c23944ffc21",
//~ "Content-Type: application/json",
//~ ),
//~ ));
//~ $response = curl_exec($curl);
//~ print_r($response );
//~ $err = curl_error($curl);
//~ echo "error ".$err;
//~ curl_close($curl);
?>
