<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class selluscars_hooks extends selluscars_core{
	public function __construct(){
		parent::__construct();
		$this->executeHooks();
	}
	public function executeHooks(){

	}
}
