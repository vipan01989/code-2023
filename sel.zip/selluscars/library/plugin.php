<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
class selluscars_plugin extends selluscars_shortcode
{

    public $logError = false;

    public static function init()
    {
        new self;
    }

    public function __construct()
    {
        parent::__construct();
        $this->subMenu		= array( 
		                             "lead" 		      => "Manage Leads",
									 "carsdata" 		  => "Manage Import Car Data",
								    //"model" 			  => "Manage Models",
								   //  "variants" 	      => "Manage Variants",
								  // "setting" 		      => "Settings"
								);
								

        add_action('admin_menu', array($this,'createAdminMenu'));
        add_action('admin_enqueue_scripts', array($this,'addScriptsAndStyles'));
        add_action('wp_enqueue_scripts', array($this,'addScriptsAndStylesOnFront'));

        add_action('wp_ajax_selluscars_ajax', array($this,'selluscars_admin_ajax'));
        add_action('wp_ajax_nopriv_selluscars_ajax', array($this,'selluscars_admin_ajax'));
        add_filter('body_class', array($this,'add_body_class'));
        add_action('admin_init', array($this,'selluscars_admin_init'));
        add_action('admin_notices', array($this,'selluscars_admin_notices'));
        add_action('admin_init', array($this,'selluscars_register_settings'));

        add_action('wp_footer', array($this,'includeFooterScripts'), 20);
        add_action('in_admin_footer', array($this,'includeAdminFooterScripts'), 20);

        register_activation_hook(SCARS_FILE, array($this,'selluscars_activate'));

        add_action('wp_ajax_get_security_token', array($this,'get_security_token'));
        add_action('wp_ajax_nopriv_get_security_token', array($this,'get_security_token'));
    }


    function errorHandler($errno, $errstr, $errfile, $errline)
    {
        if (!(error_reporting() & $errno)) {
            // This error code is not included in error_reporting
            return;
        }
        $type = $this->FriendlyErrorType($errno);
        $this->errorMessage .= "Error: [" . $type . "] $errstr in $errfile on line number $errline\n";

        /* Don't execute PHP internal error handler */
        return true;
    }

    public function handleErrors()
    {
        $error = error_get_last();

        # Checking if last error is a fatal error
        if (($error['type'] === E_ERROR) || ($error['type'] === E_USER_ERROR)) {
            # Here we handle the error, displaying HTML, logging, ...
            $type = $this->FriendlyErrorType($error['type']);
            $this->errorMessage .= "Error: [" . $type . "] " . $error['message'] . " in " . $error['file'] . " on line number " . $error['line'];
            $result["success"] = false;
            $result["message"] = $this->errorMessage;
            header('content-type: application/json');
            $response = $result;
            echo json_encode($response);
            die();
        } else if ($error['type'] != "") {
            $type = $this->FriendlyErrorType($error['type']);
            $this->errorMessage .= "Error: [" . $type . "] " . $error['message'] . " in " . $error['file'] . " on line number " . $error['line'];
        }
    }

    public function FriendlyErrorType($type)
    {
        switch ($type) {
            case E_ERROR: // 1 //
                return 'E_ERROR';
            case E_WARNING: // 2 //
                return 'E_WARNING';
            case E_PARSE: // 4 //
                return 'E_PARSE';
            case E_NOTICE: // 8 //
                return 'E_NOTICE';
            case E_CORE_ERROR: // 16 //
                return 'E_CORE_ERROR';
            case E_CORE_WARNING: // 32 //
                return 'E_CORE_WARNING';
            case E_COMPILE_ERROR: // 64 //
                return 'E_COMPILE_ERROR';
            case E_COMPILE_WARNING: // 128 //
                return 'E_COMPILE_WARNING';
            case E_USER_ERROR: // 256 //
                return 'E_USER_ERROR';
            case E_USER_WARNING: // 512 //
                return 'E_USER_WARNING';
            case E_USER_NOTICE: // 1024 //
                return 'E_USER_NOTICE';
            case E_STRICT: // 2048 //
                return 'E_STRICT';
            case E_RECOVERABLE_ERROR: // 4096 //
                return 'E_RECOVERABLE_ERROR';
            case E_DEPRECATED: // 8192 //
                return 'E_DEPRECATED';
            case E_USER_DEPRECATED: // 16384 //
                return 'E_USER_DEPRECATED';
        }
        return "";
    }

    public function selluscars_activate()
    {

        $notices = get_option('_selluscars_admin_notices', array());
        $indexedPosts = get_option('_selluscars_indexed_posts');
        if ($indexedPosts != "" && $indexedPosts != 0 && $indexedPosts != false) {
            $syncStatus = parent::getSyncStatus();
            if ($syncStatus) {
                $msg = selluscars_plugin::admin_reindex_messages();
                if (!$this->checkNotices($notices, "recommended to")) {
                    $notices[] = $msg;
                }
            }

        } else {
            $msg = selluscars_plugin::admin_notice_messages();
            if (!$this->checkNotices($notices, "been activated")) {
                $notices[] = $msg;
            }
        }
        update_option('_selluscars_admin_notices', $notices);
        $this->createTables();
    }
        public function createTables()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $sql = "CREATE TABLE IF NOT EXISTS $this->tableMake (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `name` varchar(500) DEFAULT NULL,
				  `years` text,
                  `status` int(11) DEFAULT '1',
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
        $sql = "CREATE TABLE IF NOT EXISTS $this->tableModel (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `model_name` varchar(500) DEFAULT NULL,
                  `make_id` int(11) DEFAULT NULL,
				  `years` text,
                  `status` int(11) DEFAULT '1',
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
		
		$sql = "CREATE TABLE IF NOT EXISTS $this->tableUserCarDetails (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `zoho_id` bigint(244) DEFAULT NULL,
                  `phone` int(11) DEFAULT NULL,
				  `make` varchar(500) DEFAULT NULL,
				  `model` varchar(500) DEFAULT NULL,
				  `variant` varchar(500) DEFAULT NULL,
				  `fuel_type` varchar(500) DEFAULT NULL,
				  `transmission` varchar(500) DEFAULT NULL,
				  `year` varchar(500) DEFAULT NULL,
				  `odometer` varchar(500) DEFAULT NULL,
				  `registration` varchar(500) DEFAULT NULL,
				  `colour` varchar(500) DEFAULT NULL,
				  `expected_price` varchar(500) DEFAULT NULL,
				  `bank_settlementvalue` varchar(500) DEFAULT NULL,
				  `about_vehicle` text,
				  `agent_comment` text,
				  `created_date` datetime DEFAULT NULL,
                  `modified_date` datetime DEFAULT NULL,
				  `status` int(11) DEFAULT '1',
				  `name` varchar(500) DEFAULT NULL,
				  `Location` text,
				  
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
		
        $sql = "CREATE TABLE IF NOT EXISTS $this->tableVariant (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `variant_name` varchar(500) DEFAULT NULL,
                  `model_id` int(11) DEFAULT NULL,
                  `body_shape` varchar(400) DEFAULT NULL,
                  `gear_type` varchar(400) DEFAULT NULL, 
                  `fuel_type` varchar(300) DEFAULT NULL,
                  `engine_size` varchar(300) DEFAULT NULL,
                  `kw` varchar(300) DEFAULT NULL,
                  `horse_power` varchar(300) DEFAULT NULL,
                  `ECE_missions` varchar(300) DEFAULT NULL,
                  `Cylinders` varchar(200) DEFAULT NULL,
                  `Doors` varchar(200) DEFAULT NULL,
                  `GCM` varchar(200) DEFAULT NULL,
                  `GVM` varchar(200) DEFAULT NULL,
                  `kerb_mass` varchar(200) DEFAULT NULL,
                  `intro_month` varchar(200) DEFAULT NULL,
                  `discon_onth` varchar(200) DEFAULT NULL,
                  `status` int(11) DEFAULT '1',
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
            dbDelta($sql);
			
			$sql = "CREATE TABLE IF NOT EXISTS $this->tableUserCarImages (
                          `id` int(11) NOT NULL AUTO_INCREMENT,
                          `lead_id` bigint(244) DEFAULT NULL,
                          `image_url` text,
                          PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
		
	 $sql = "CREATE TABLE IF NOT EXISTS $this->tableCarTempDetails (
                  `id` bigint(244) NOT NULL AUTO_INCREMENT,
                  `MMCode` bigint(244) DEFAULT NULL,
                  `VehicleType` varchar(100) DEFAULT NULL,
				  `Make` varchar(500) DEFAULT NULL,
				  `Model` varchar(500) DEFAULT NULL,
				  `Variant` varchar(500) DEFAULT NULL,
				  `RegYear` year(4) NOT NULL,
				  `PublicationSection` varchar(100) DEFAULT NULL,
				  `Master_Model` varchar(50) DEFAULT NULL,
				  `Make_Code` bigint(244) DEFAULT NULL,
				  `Model_Code` bigint(244) DEFAULT NULL,
				  `VariantCode` bigint(244) DEFAULT NULL,
				  `AxleConfiguration` varchar(100) DEFAULT NULL,
				  `BodyType` varchar(100) DEFAULT NULL,
				  `NoOfDoors` int(11) DEFAULT NULL,
				  `Drive` varchar(50) DEFAULT NULL,
				  `Seats` int(11) DEFAULT NULL,
				  `Use` varchar(50) DEFAULT NULL,	
				  `Wheelbase` varchar(500) DEFAULT NULL,
				  `ManualAuto` varchar(100) DEFAULT NULL,
				  `NoGears` int(11) DEFAULT NULL,
				  `Cooling` varchar(100) DEFAULT NULL,
				  `CubicCapacity` int(11) DEFAULT NULL,
				  `CylConfiguration` varchar(50) DEFAULT NULL,
				  `EngineCycle` int(11) DEFAULT NULL,
				  `FuelTankSize` int(11) DEFAULT NULL,
				  `FuelType` varchar(50) DEFAULT NULL,
				  `Kilowatts` int(11) DEFAULT NULL,
				  `NoCylinders` int(11) DEFAULT NULL,  
				  `TurboOrSuperCharged` varchar(50) DEFAULT NULL,
				  `GCM` int(11) DEFAULT NULL,
				  `GVM` int(11) DEFAULT NULL,
				  `Tare` int(11) DEFAULT NULL,
				  `Origin` varchar(50) DEFAULT NULL,
				  `FrontNoTyres` int(11) DEFAULT '0',
				  `FrontTyreSize` varchar(100) DEFAULT NULL,
				  `RearNoTyres` int(11) DEFAULT '0',
				  `RearTyreSize` varchar(100) DEFAULT NULL,
				  `IntroDate` varchar(100) DEFAULT NULL,
				  `DiscDate` varchar(100) DEFAULT NULL,
				  `CO2` int(11) DEFAULT NULL,
				  `Length` int(11) DEFAULT NULL,
				  `Height` int(11) DEFAULT NULL,
				  `Width` int(11) DEFAULT NULL,
				  `NewListPrice` bigint(244) DEFAULT NULL,
				  
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
        
        
        	 $sql = "CREATE TABLE IF NOT EXISTS $this->tableVariantYearDetails(
                  `id` bigint(244) NOT NULL AUTO_INCREMENT,
                  `Variant_id` bigint(244) DEFAULT NULL,
                  `MMCode` bigint(244) DEFAULT NULL,
                  `VehicleType` varchar(100) DEFAULT NULL,
				  `RegYear` year(4) NOT NULL,
				  `PublicationSection` varchar(100) DEFAULT NULL,
				  `Master_Model` varchar(50) DEFAULT NULL,
				  `Make_Code` bigint(244) DEFAULT NULL,
				  `Model_Code` bigint(244) DEFAULT NULL,
				  `VariantCode` bigint(244) DEFAULT NULL,
				  `AxleConfiguration` varchar(100) DEFAULT NULL,
				  `BodyType` varchar(100) DEFAULT NULL,
				  `NoOfDoors` int(11) DEFAULT NULL,
				  `Drive` varchar(50) DEFAULT NULL,
				  `Seats` int(11) DEFAULT NULL,
				  `Use` varchar(50) DEFAULT NULL,	
				  `Wheelbase` varchar(500) DEFAULT NULL,
				  `ManualAuto` varchar(100) DEFAULT NULL,
				  `NoGears` int(11) DEFAULT NULL,
				  `Cooling` varchar(100) DEFAULT NULL,
				  `CubicCapacity` int(11) DEFAULT NULL,
				  `CylConfiguration` varchar(50) DEFAULT NULL,
				  `EngineCycle` int(11) DEFAULT NULL,
				  `FuelTankSize` int(11) DEFAULT NULL,
				  `FuelType` varchar(50) DEFAULT NULL,
				  `Kilowatts` int(11) DEFAULT NULL,
				  `NoCylinders` int(11) DEFAULT NULL,  
				  `TurboOrSuperCharged` varchar(50) DEFAULT NULL,
				  `GCM` int(11) DEFAULT NULL,
				  `GVM` int(11) DEFAULT NULL,
				  `Tare` int(11) DEFAULT NULL,
				  `Origin` varchar(50) DEFAULT NULL,
				  `FrontNoTyres` int(11) DEFAULT '0',
				  `FrontTyreSize` varchar(100) DEFAULT NULL,
				  `RearNoTyres` int(11) DEFAULT '0',
				  `RearTyreSize` varchar(100) DEFAULT NULL,
				  `IntroDate` varchar(100) DEFAULT NULL,
				  `DiscDate` varchar(100) DEFAULT NULL,
				  `CO2` int(11) DEFAULT NULL,
				  `Length` int(11) DEFAULT NULL,
				  `Height` int(11) DEFAULT NULL,
				  `Width` int(11) DEFAULT NULL,
				  `NewListPrice` bigint(244) DEFAULT NULL,
				  
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
        
        $sql = "CREATE TABLE IF NOT EXISTS $this->selluscarCsvFileStatus (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `file_path` varchar(500) DEFAULT NULL,
				  `total_record` bigint(244) DEFAULT NULL,
				  `total_saved` bigint(244) DEFAULT NULL,
				  `total_percent` varchar(200) DEFAULT NULL,
				  `status` int(11) DEFAULT '0',
				  `created_date` datetime DEFAULT NULL,
                  `modified_date` datetime DEFAULT NULL,
				 
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
		

       }

    public function checkNotices($notices, $word)
    {
        if (count($notices) > 0) {
            foreach ($notices as $k => $v) {
                if (strpos($v, $word) !== false) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function admin_notice_messages()
    {
        return "";
    }

    public function selluscars_admin_init()
    {
        global $selluscarsAPIClient;
        $current_version = SC_PLUGIN_VERSION;

    }

    function selluscars_admin_notices()
    {
        $notices = get_option('_selluscars_admin_notices', array());

        if (count($notices) > 0) {
            foreach ($notices as $notice) {
                echo "<div class='update-nag selluscars-notices'>$notice</div>";
            }
            delete_option('_selluscars_admin_notices');
        }
    }


    public function add_body_class($classes)
    {
        global $post;
        $classes[] = "selluscars_search_page";
        return $classes;
    }

    public function getDomain()
    {
        $domain         = get_option('siteurl');
        $find           = array('http://','https://');
        $replace        = array('','');
        $domain         = str_replace($find, $replace, $domain);
        $this->domain   = strtolower($domain);
        return $this->domain;
    }

    public function createAdminMenu()
    {
        add_menu_page(__('Selluscars', 'selluscars'), __('Selluscars', 'selluscars'), $this->lqMenuCapabilities, 'selluscars', array($this,"dashboard"), SC_BASE_URL . '/assets/images/logo_icon.png');
       if(count($this->subMenu) > 0){
			foreach($this->subMenu as $slug => $menu){
			   add_submenu_page('selluscars',__($menu, 'selluscars'), __($menu, 'selluscars'), $this->lqMenuCapabilities, $slug, array($this, "manageSubmenuItems"));
			}
		}
    }
    
   
    public function addScriptsAndStyles($hook)
    {
        wp_register_style('selluscars_admin_css', SC_BASE_URL . '/assets/css/backend/stylesheet.css', false, time());
        wp_enqueue_style('selluscars_admin_css');
        wp_register_script('selluscars_admin_validate_js', SC_BASE_URL . '/assets/js/backend/jquery.validate.min.js', array('jquery'), time());
        wp_register_script('selluscars_admin_js', SC_BASE_URL . '/assets/js/backend/script.js', array('jquery'), time());

        wp_enqueue_script('selluscars_admin_validate_js');
        wp_enqueue_script('selluscars_admin_js');
    }

    public function includeFooterScripts()
    {
        ?>
        <script type="text/javascript">
            var adminAjax                = '<?php echo admin_url('admin-ajax.php');?>';
            var selluscars_site_nonce   = "<?php echo wp_create_nonce($this->siteNonceString);?>";

        </script>
    <?php }
     public function includeAdminFooterScripts()
    {
        ?>
        <script type="text/javascript">// <![CDATA[
            var adminAjax           = '<?php echo admin_url('admin-ajax.php');?>';
            var selluscars_site_nonce   = "<?php echo wp_create_nonce($this->adminNonceString);?>";
            // ]]>
        </script>
    <?php }

    public function addScriptsAndStylesOnFront()
    {
        if (!is_admin()) {
			wp_register_style('selluscars_bootstrap_css', SC_BASE_URL . '/assets/css/frontend/bootstrap.min.css', true, time());
            wp_register_style('selluscars_front_css', SC_BASE_URL . '/assets/css/frontend/stylesheet.css', false, time());
            
            //wp_enqueue_style('selluscars_bootstrap_css',-1);
            wp_enqueue_style('selluscars_front_css', 99);
            
             wp_register_script('selluscars_tether_js', SC_BASE_URL . '/assets/js/frontend/tether.min.js', array('jquery'), time());
            wp_register_script('selluscars_bootstrap_js', SC_BASE_URL . '/assets/js/frontend/bootstrap.min.js', array('jquery'), time());
            wp_register_script('selluscars_front_js', SC_BASE_URL . '/assets/js/frontend/script.js', array('jquery'), time());
            
			//wp_register_script('selluscars_front_validator_js', SC_BASE_URL . '/assets/js/frontend/jquery.validate.js', array('jquery'), time());
          
           wp_register_script('selluscars_front_validator_js', SC_BASE_URL . '/assets/js/frontend/validator.js', array('jquery'), time());
           
		  wp_register_script('selluscars_front_typeahead_js', SC_BASE_URL . '/assets/js/frontend/typeahead.js', array('jquery'), time());
            
            wp_enqueue_script('selluscars_tether_js');
            wp_enqueue_script('selluscars_bootstrap_js');
            wp_enqueue_script('selluscars_front_validator_js');
            wp_enqueue_script('selluscars_front_typeahead_js');
            wp_enqueue_script('selluscars_front_js');
            
            if (!wp_script_is('jquery', 'enqueued')) {
                wp_enqueue_script('jquery');
            }
        }
    }

	

    public function returnOnDie($message)
    {
        if ($this->resultSent == 0) {
            $result["success"]  = false;
            $result["message"]  = $message;
            $result["errors"]   = $this->errorMessage;
            header('content-type: application/json');
            $response           = $result;
            echo json_encode($response);
            exit;
        }
    }

    public function dieHandler($param)
    {
        die();
    }

    public function checkIfInAdmin()
    {
        if ((strpos(strtolower($_SERVER[HTTP_REFERER]), strtolower(site_url())) !== FALSE && strpos(strtolower($_SERVER[HTTP_REFERER]), "wp-admin") !== FALSE)) {
            return true;
        }
        return false;
    }

    private function checkSecurity($nonce)
    {
        if (!$this->checkIfInAdmin()) {
            register_shutdown_function(array($this,'returnOnDie'), 'Invalid nonce on frontend.');
            if (check_ajax_referer($this->siteNonceString, 'security')) {
                return true;
            }
        } else if (current_user_can("activate_plugins")) {
            register_shutdown_function(array($this,'returnOnDie'), 'Invalid nonce on admin.');
            if (check_ajax_referer($this->adminNonceString, 'security')) {
                return true;
            }
        }
        return false;
    }

    public function selluscars_admin_ajax()
    {
		//echo 'ho';
		//die('yes');
        error_reporting(0);
        register_shutdown_function(array($this,'handleErrors'));
        set_error_handler(array($this,"errorHandler"));
        if (!empty($_POST)) {
            $task = $_POST['task'];
            $nonce = $_POST['security'];
            add_filter('wp_die_ajax_handler', array($this,'dieHandler'));
            if ($this->checkSecurity($nonce)) {
                $post = $this->sanitizeVariables($_POST);
                switch ($task) {
					case "save_user_details":
					//die('yes');
                        $result = $this->saveUserDetails($post);
                        break;
                    case "get_brands_data":
                        $result = $this->getBrands($post);
                        break;
                    case "get_models_data":
					    $result = $this->getCarData($post);
                        break;
                    case "get_variants_data":
                        $result = $this->getCarData($post);
                        break;
					case "save_car_details":
                        $result = $this->saveCarDetails($post);
                      break;
					  case "save_images_data":
                        $result = $this->saveImagesData($post, $_FILES);
                      break;
					   case "delete_images_data":
                        $result = $this->deleteImagesData($post, $_FILES);
                      break;
                      case "save_car_temp_details":
                        $result = $this->saveCarTempDetails($post, $_FILES);
                      break;
					case "save_car_make_data":
						$result = $this->saveCarMakeData($post);
					break;
					case "save_car_model_data":
						$result = $this->saveCarModelData($post);
					break;
					case "save_car_variant_data":
						$result = $this->saveCarVariantData($post);
					break;
					case "save_car_variant_details":
						$result = $this->saveCarVariantDetails($post);
					break;
					case "get_years_data":
						$result = $this->getYearsList($post);
					break;
                    default:
                        $result = array('success' => 0, 'message' => 'Parameter missing, please try again.');
                }
            } else {
                $result = array('success' => 0, 'message' => 'Insecure request, please try again.');
            }
        } else {
            $result = array('success' => 0, 'message' => 'Invalid request, please try again.');
        }

        header('content-type: application/json');
        $result['errors'] = $this->errorMessage;
        $response = $result;
        $this->resultSent = 1;
        echo json_encode($response);
        exit;
    }
    public function saveCarVariantDetails($data){
	   	$response            = array();
		$response['success'] = 0;
		$offset              =0;
		$condition ='';
		
		$this->totalRecordSaveOneTime=200;
		if(!empty($data['total_record'])){
			//print_r($data);
		//	exit;
			if(!empty($data['total_saved'])){
				$total_saved=  $data['total_saved'];
				$offset     =  $total_saved;

			}
			if(!empty($data['total_percent'])){
				$total_percent = $data['total_percent'];
			}
			
			$condition ="ORDER by tbl.id ASC LIMIT ".$offset.','.$this->totalRecordSaveOneTime;
			$resMakeModelData = $this->getMakeModelVarient($condition);
		    if(count($resMakeModelData)>0 ){
			
				
				
			    foreach($resMakeModelData as $rdata){
					$results=array();
					
                    $results = $this->getAllDataOfTable($this->tableCarTempDetails, " WHERE Model='".$rdata['model_name']."' AND Make='".$rdata['name']."' AND Variant='".$rdata['variant_name']."' ORDER by Variant ASC ");
			//	print_r($results);
				//exit;
				   if(count($results)>0){
					  $Mid = $rdata['Mid'];
					   foreach($results as $result){
							$fdata=array();
							$fdata=$result;
							$fdata['action']          ='add';
							$fdata['Variant_id']    = $rdata['Vid'];
							
						    $rIn=$this->checkRecordInData($this->tableVariantYearDetails, " WHERE RegYear='".$fdata['RegYear']."' AND Variant_id='".$rdata['Vid']."' ");
							
							if(empty($rIn)){
								unset($fdata['id']);
								unset($fdata['Make']);
								unset($fdata['Model']);
								unset($fdata['Variant']);
									//print_r($fdata);
								$id = $this->createQuery($this->tableVariantYearDetails, $fdata);
							}
							
						}
					   
				   }
				


				}
				
				
				$response['success']          = 1;
				$response['total_record']     = $data['total_record'];
				$response['total_saved']      = $total_saved+$this->totalRecordSaveOneTime;
				if($response['total_saved']>= $data['total_record']){
				    $response['total_saved']=$data['total_record'];
			   }
				$response['total_percent']    = $response['total_saved']/$response['total_record']*100;
				
		    }else{
				  $response['success'] = 2;
				  $response['message']='Completed';
			}
			
		}else{
			
		    $resMakeModelVariantTotal = $this->getMakeModelVarient('', true);
			
			if(!empty($resMakeModelVariantTotal)){
				$response['success']         = 1;
				$response['total_record']    = $resMakeModelVariantTotal;
				$response['total_saved']     =0;
				$response['total_percent']   = 0;
			}else{
				$response['message']='No records found';
			}
			
		}
		
		return $response; 
		  
	}
    public function saveCarVariantData($data){
	   	$response            = array();
		$response['success'] = 0;
		$offset              =0;
		$condition ='';
		$this->totalRecordSaveOneTime=$this->totalVariantOneTime;
		if(!empty($data['total_record'])){
			//print_r($data);
		//	exit;
			if(!empty($data['total_saved'])){
				$total_saved=  $data['total_saved'];
				$offset     =  $total_saved;

			}
			if(!empty($data['total_percent'])){
				$total_percent = $data['total_percent'];
			}
			
			$condition ="ORDER by tbl.id ASC LIMIT ".$offset.','.$this->totalRecordSaveOneTime;
			$resMakeModelData = $this->getMakeModel($condition);
		    if(count($resMakeModelData)>0 ){
			
				//print_r($resMakeModelData);
				foreach($resMakeModelData as $rdata){
					$results=array();
					if(empty($rdata['is_master'])){
                    $results = $this->getDistinctGroupByData($this->tableCarTempDetails, "Variant", "RegYear", " WHERE Model='".$rdata['model_name']."' AND Make='".$rdata['name']."' GROUP BY Variant ORDER by Variant ASC ");
					}else{
					$results = $this->getDistinctGroupByData($this->tableCarTempDetails, "Variant", "RegYear", " WHERE Master_Model='".$rdata['model_name']."' AND Make='".$rdata['name']."' GROUP BY Variant ORDER by Variant ASC ");
				
					}
					
					//print_r($results);
		            //exit;
				
				   if(count($results)>0){
					  $Mid = $rdata['Mid'];
					   foreach($results as $result){
							$fdata=array();
							$fdata['action']          ='add';
							$fdata['variant_name']    = $result['Variant'];
							$fdata['model_id']        = $Mid;
							$fdata['years']           = $result['years'];
							
							if(empty($this->getData($this->tableVariant, "WHERE status=1 AND variant_name='".$result['Variant']."' AND model_id='".$Mid."'", true))){
								$id = $this->createQuery($this->tableVariant, $fdata);
							}else{
							
								$yearRes = $this->getData($this->tableVariant, "WHERE status=1 AND variant_name='".$result['Variant']."' AND model_id='".$Mid."'");
								//print_r($yearRes);
								 if(!empty($result['years']) && count($yearRes)>=0){
									$year=$result['years'];
									$ydata  =array();
									if(!empty($year) && !empty($yearRes[0]['years']) && $yearRes[0]['years']!=$year ){
									  $newYear = $this->createYearString($yearRes[0]['years'], $year);
									}else{
									  $newYear=$year;
									}
										$ydata = array();
										$ydata['id']      =$yearRes[0]['id'];
										$ydata['action']  ='edit';
										$ydata['years']   =$newYear;
										$id = $this->createQuery($this->tableVariant, $ydata);
								}
							
							}
						}
					   
				   }


				}
				
				
				$response['success'] = 1;
				$response['total_record']     = $data['total_record'];
				$response['total_saved']     = $total_saved+$this->totalRecordSaveOneTime;
			    if($response['total_saved']>= $data['total_record']){
				    $response['total_saved']=$data['total_record'];
			    }
				$response['total_percent']   = $response['total_saved']/$response['total_record']*100;
				
		    }else{
				  $response['success'] = 2;
				  $response['message']='Completed';
			}
			
		}else{
			
			$resMakeModelTotal = $this->getMakeModel('', true);
			if(!empty($resMakeModelTotal)){
				$response['success']         = 1;
				$response['total_record']    = $resMakeModelTotal;
				$response['total_saved']     =0;
				$response['total_percent']   = 0;
			}else{
				$response['message']='No records found';
			}
			
		}
		
		return $response;  
	}
    
   public function saveCarModelData($data){
	   	$response = array();
		$response['success'] = 0;
		$offset   =0;
		$this->totalRecordSaveOneTime=$this->totalModelSaveOneTime;
		
		if(!empty($data['total_record'])){
			
			$total_saved   = 0;
			$total_percent = 0;
			if(!empty($data['total_saved'])){
			 
			  $total_saved=  $data['total_saved'];
			  $offset     =  $total_saved;

			}
			if(!empty($data['total_percent'])){

			   $total_percent=$data['total_percent'];

			}
			
			$resMake = $this->getAllData($this->tableMake, " WHERE name!='' AND status=1 ORDER by id ASC LIMIT ".$offset.','.$this->totalRecordSaveOneTime);
			
			if(count($resMake)>0 ){
				
				foreach($resMake as $rdata){
					$results=array();
					
					//$results = $this->getDistinctData($this->tableCarTempDetails, "Model", " WHERE Make='".$rdata['name']."' ORDER by Model ASC ");
					$results = $this->getDistinctGroupByData($this->tableCarTempDetails, "Master_Model", "RegYear", " WHERE Make='".$rdata['name']."' GROUP BY Master_Model ORDER by Master_Model ASC");
					
					if(count($results)>0){
					        $make_id=$rdata['id'];
								foreach($results as $result){
									$fdata=array();
									$fdata['action']          ='add';
									$fdata['model_name']      = $result['Master_Model'];
									$fdata['years']           = $result['years'];
									$fdata['make_id']          = $make_id;
									$fdata['is_master']          = 1;
									if(!empty($result['Master_Model'])){
									   $id=$this->saveMasterModeldata($fdata, $make_id);
									}else{
										$modelresults = $this->getDistinctGroupByData($this->tableCarTempDetails, "Model", "RegYear", " WHERE Make='".$rdata['name']."' AND Master_Model='' GROUP BY Model ORDER by Model ASC");
					                    foreach($modelresults as $modelresult){
											$fdata['model_name']      = $modelresult['Model'];
									        $fdata['years']           = $modelresult['years'];
											$fdata['is_master']       = 0;
											$id=$this->saveMasterModeldata($fdata, $make_id);
										}
									}
									
								}
					}
					
				}
				
			   $response['success'] = 1;
			   $response['total_record']     = $data['total_record'];
			   $response['total_saved']     = $total_saved+$this->totalRecordSaveOneTime;
			   if($response['total_saved']>= $data['total_record']){
				    $response['total_saved']=$data['total_record'];
			   }
			   $response['total_percent']   = $response['total_saved']/$response['total_record']*100;
				
			}else{
				  $response['success'] = 2;
				  $response['message']='Completed';
			}

			
		}else{
			 $resMakeTotal = $this->getData($this->tableMake, '', "WHERE status=1", true);
			 
			//echo $resMakeTotal;
			//exit;
			
			if(!empty($resMakeTotal)){
			    $response['success']         = 1;
				$response['total_record']    = $resMakeTotal;
				$response['total_saved']     =0;
				$response['total_percent']   = 0;
			}else{
				  $response['message']='No records found';
			}
		
		}
		
		
		
	   return $response;  	
   } 
   public function saveMasterModeldata($fdata, $make_id){
	   
	   
		if(empty($this->checkRecordExists($this->tableModel, 'model_name', $fdata['model_name']))){
			$id = $this->createQuery($this->tableModel, $fdata);
		}else{

			$yearRes = $this->getData($this->tableModel, "WHERE status=1 AND model_name='".$fdata['model_name']."' AND make_id='".$make_id."'");
			//print_r($yearRes);
			if(!empty($fdata['years']) && count($yearRes)>=0){
			$year=$fdata['years'];
			$ydata  =array();
			if(!empty($year) && !empty($yearRes[0]['years']) && $yearRes[0]['years']!=$year ){
			$newYear = $this->createYearString($yearRes[0]['years'], $year);	  
			}else{
			$newYear=$year;
			}
			$ydata['id']      =$yearRes[0]['id'];
			$ydata['action']  ='edit';
			$ydata['years']   =$newYear;
			$id = $this->createQuery($this->tableModel, $ydata);
			}

		}
   return $id;
   
}
    
	public function saveCarMakeData($data){
		$response = array();
		$response['success'] = 0;
		$offset   =0;
		$this->totalRecordSaveOneTime=$this->totalMakeSaveOneTime;
		
		if(!empty($data['total_record'])){
			
			$total_saved   = 0;
			$total_percent = 0;
			if(!empty($data['total_saved'])){
			 
			  $total_saved=  $data['total_saved'];
			  $offset     =  $total_saved;

			}
			if(!empty($data['total_percent'])){

			   $total_percent=$data['total_percent'];

			}
			
			//$results = $this->getDistinctData($this->tableCarTempDetails, "Make", " WHERE Make!='' ORDER by Make ASC LIMIT ".$offset.','.$this->totalRecordSaveOneTime);
			$results = $this->getDistinctGroupByData($this->tableCarTempDetails, "Make", "RegYear", " WHERE Make!='' GROUP BY Make ORDER by Make ASC LIMIT ".$offset.','.$this->totalRecordSaveOneTime);
			//print_r($results);
			//exit;
			
			if(count($results)>0 ){
			  
			   foreach($results as $result){
				    $fdata=array();
				    $fdata['action']    ='add';
				    $fdata['name']      = $result['Make'];
					$fdata['years']     = $result['years'];
				    if(empty($this->checkRecordExists($this->tableMake, 'name', $result['Make']))){
					   $id = $this->createQuery($this->tableMake, $fdata);
					}else{
					
					       $yearRes = $this->getData($this->tableMake, "WHERE status=1 AND name='".$result['Make']."'");
						   if(!empty($result['years']) && count($yearRes)>=0){
						         $year=$result['years'];
								  $ydata  =array();
								  if(!empty($year) && !empty($yearRes[0]['years']) && $yearRes[0]['years']!=$year ){
									 $newYear = $this->createYearString($yearRes[0]['years'], $year);
									  
								  }else{
								    $newYear=$year;
								  }
								      $ydata['id']      =$yearRes[0]['id'];
									  $ydata['action']  ='edit';
									  $ydata['years']   =$newYear;
									  $id = $this->createQuery($this->tableMake, $ydata);
							}
					}
			   }
			  
			   $response['success'] = 1;
			   $response['total_record']     = $data['total_record'];
			   $response['total_saved']      = $total_saved+$this->totalRecordSaveOneTime;
			   if($response['total_saved']>= $data['total_record']){
				    $response['total_saved']=$data['total_record'];
			   }
			   	$response['total_percent']   = $response['total_saved']/$response['total_record']*100;
				
			}else{
				$response['success'] = 2;
				  $response['message']='Completed';
			}

			
		}else{
			$resMakeTotal=$this->getDistinctData($this->tableCarTempDetails, "Make", " WHERE Make!=''", true);
			if(!empty($resMakeTotal)){
			    $response['success'] = 1;
				$response['total_record'] = $resMakeTotal;
				$response['total_saved']     =0;
				$response['total_percent'] = 0;
			}else{
				  $response['message']='No records found';
			}
		
		}
		
	
	 return $response;  
	}
   public function saveCarTempDetails($data){
        $this->totalRecordSaveOneTime=$this->totalCarTempOneTime;
		$response = array();
		$response['success'] = 0;
		
		
		if(!empty($data['file_path']) && !empty($data['total_record'])){
			    $total_saved   = 0;
			    $total_percent = 0;
			    $total_percent = 0;
			    
			    	$total_saved=$data['total_saved'];
					$total_call=1+$data['total_call'];
					$total_percent=$data['total_percent'];
				
					//ini_set('memory_limit', '-1');
					$dataFile = file($data['file_path']);
					//ini_set('memory_limit', '-1');
					$records = array_slice( $dataFile, $total_saved, $this->totalRecordSaveOneTime);
					$resArray=$this->convertToArray($records, $total_saved);
					if(count($resArray)>0){
						foreach($resArray as $res){
							$fdata = array();
							$fdata =$res;
							$fdata['action']='add';
							$id = $this->createQuery($this->tableCarTempDetails, $fdata);
							//print_r($fdata);
						}
						$response['success']         = 1;
						$response['file_path']       = $data['file_path'];
						$response['total_record']    = $data['total_record'];
						$response['total_call']      = $total_call;
						$response['total_saved']     = $total_saved+$this->totalRecordSaveOneTime;
						if($response['total_saved']>= $data['total_record']){
							$response['total_saved']=$data['total_record'];
						}
						$response['total_percent']   = $response['total_saved']/$response['total_record']*100;
						$filedata=array();
						$filedata['action']           ='edit';
						$filedata['id']               =$data['file_id'];
						$filedata['total_saved']      =$response['total_saved'];
						$filedata['total_percent']    =$response['total_percent'];
					    $response['file_id']          = $data['file_id'];
						$id = $this->createQuery($this->selluscarCsvFileStatus, $filedata);
						
					}else{
					  $filedata=array();
					  $response['success']         = 2;
				      $response['message']         ='CSV imported successfully';
				      $filedata['action']           ='edit';
					  $filedata['id']               =$data['file_id'];
					  $filedata['status']           =1;
				      $id = $this->createQuery($this->selluscarCsvFileStatus, $filedata);
				}
					
			
				
		
			
		   return $response;
			
		}
	   
	   if(is_array($_FILES) && !empty($_FILES['file']))  
		{
		$dataArrays= array();
		$filename     =$_FILES['file']['name'];
		$tmp_name     =$_FILES['file']['tmp_name'];
		$path         =$this->selluscarTempDetailsCsvFile;
			if (isset($filename)) {
				if (empty($filename)) {

					$response['message']='Error during file upload ' . $filename;

				}else {
				$acceptedFormats = array('csv');
				if(!in_array(pathinfo($filename, PATHINFO_EXTENSION), $acceptedFormats)) {
					
				     $response['message']='Please upload only csv Format';
				      
				}else{
					
					if (!file_exists($path)) {
                          wp_mkdir_p($path);
                    }
					$res=$this->file_newname($path, $filename);
					$newfile  =$res['newname'];
					$newpath  =$res['newpath'];
					if(move_uploaded_file($tmp_name, $path . $newfile)){
				//	ini_set('memory_limit', '-1');
					$totalRecord  = count(file($newpath));
					//ini_set('memory_limit', '-1');
				
					//$csvFileData  = $this->csv_to_array($newpath);
					//$totalRecord  = count($csvFileData);
					
					 if($totalRecord>0){
							global $wpdb;
							$delete = $wpdb->query("TRUNCATE TABLE $this->tableCarTempDetails");
							
							$filedata['action']          ='add';
							$filedata['file_path']       =$newpath;
							$filedata['total_record']    =$totalRecord;
							$filedata['total_percent']   =1;
							$id = $this->createQuery($this->selluscarCsvFileStatus, $filedata, true);
							
							$response['success']         = 1;
							$response['file_path']       = $newpath;
							$response['total_record']    = $totalRecord;
							$response['file_id']         = $id;
							
						
							
							$response['message']         ='';
					 }else{
						  $response['message']='No records found in ' . $filename . ' file';
					 }
					
						   
					   }
                    
					
				}
				
			    }
			}
		
		
			 //print_r($_FILES);
		}
    return $response;
		
	} 

    /* This function is used to register plugin options */
    Public function selluscars_register_settings() {
        if(count($this->selluscarsOptions) > 0){
            foreach($this->selluscarsOptions as $slug => $value){
                add_option( $slug, $value);
                register_setting( 'selluscars_options_group', $slug, 'selluscars_callback' );
            }
        }
    }
	  /* This function is used to delete image */
	public function deleteImagesData($data){
	
    $oldImageName='';
	
	if(!empty($data['img_id']) && !empty($data['img_name'])){
		$path=$this->selluscarImagePath;
		$deleteData=array();
		$oldImageName=$data['img_name'];
		$deleteData['table']=$this->tableUserCarImages;
		$deleteData['id']   =$data['img_id'];
		$this->deleteRecord($deleteData);
		if(!empty($oldImageName)) {
			if (file_exists($path.$oldImageName)) {
		       unlink($path.$oldImageName);
			}
		}
	}

	}
	private function getFileExtension($path) {
      $qpos = strpos($path, "?");
      if ($qpos!==false) $path = substr($path, 0, $qpos);
      $extension = pathinfo($path, PATHINFO_EXTENSION);
      return strtolower($extension);
    }

	  /* This function is used to save image */
      public function saveImagesData($data){
		   //print_r($_FILES);
		   //exit;
		 $response = array();
		 $output   ='';
		 $error   ='';
		 $response['success'] = 0;
		 $response['data']    ='';
		 $images=array();
		if(is_array($_FILES) && !empty($_FILES['carImages']))  
		{
			$path=$this->selluscarImagePath;
			if (!file_exists($path)) {
				wp_mkdir_p($path);
			}
			//echo count($_FILES['carImages']['name']);
			if($data['totalfiles']>$this->maxImagelength){
				$error=2;
			}else{
				foreach($_FILES['carImages']['name'] as $key => $filename)  
				{
				 $size =$_FILES["carImages"]["size"][$key];
					if($size>=$this->maxImageSize){
						   $error=3;
					}else{
				    $file_name = explode(".", $filename); 
				    $fileExtension = $this->getFileExtension( $filename );
				    $allowed_extension = array("jpg", "jpeg", "png");  
					if(in_array($fileExtension, $allowed_extension))  
					{  
						$newFileName = rand() . '.'. $file_name[1];  
						$sourcePath = $_FILES["carImages"]["tmp_name"][$key];  
						$targetPath = $path . $newFileName;
						$fileNameWithoutExtension = preg_replace('/(.*)\\.[^\\.]*/', '$1', $newFileName);
						$count = 1;
						while (file_exists($path . $newFileName)) {
								$newFileName = $fileNameWithoutExtension . "_" . $count . "." . $fileExtension;
								$count++;
						}
						 $images[$newFileName]=$this->selluscarImageUrl.$newFileName;
						 $targetPath = $path . $newFileName; // Target path where file is to be stored
						 move_uploaded_file($sourcePath, $targetPath); // Moving Uploaded file 
					}else{
						
					   $error=1;
		   
					}
				}					
				} 
		  }			
			if(empty($error) && count($images)>0){
				$dataDetails=array();
				foreach($images as $k => $image)  
				{ 
				        $dataDetails=array();
						$dataDetails['action']  ='add';
						$dataDetails['lead_id'] =$data['user_id'];
						$dataDetails['image_url'] =$image;
						//print_r($dataDetails);
				        $rid  =$this->createQuery($this->tableUserCarImages, $dataDetails);
				
				   $output .= '<div id="img_id_'.$rid.'" class="img_div" align="center"  ><img class="main-img" src="' .  $image .'" width="100px" height="100px"  /><span class="cross" data-carimg_id="'.$rid.'" data-img-name="'.$k.'">&#x2716;</span></div>';  
				}
				
				
				$response['success'] = 1;
				$response['data']    = $output;
			}

			if(!empty($error) && $error==1){
				 $response['error'] = "<p> Upload valid images. Only PNG,JPG and JPEG are allowed.</p>";
			}
			if(!empty($error) && $error==2){
				
				 $response['error'] = '<p>You Can Upload Max '.$this->maxImagelength.' Files. Thanks!</p>';
			}
			if(!empty($error) && $error==3){
				$response['error'] = '<p>Please upload file less than '.$this->inMB.'. Thanks!</p>';
			}
							
	
		}
		 
		  
		return $response; 
		  //print_r($_FILES);
		//  print_r($data);
	  }
   public function manageSubmenuItems(){
		$page       = $_GET['page'];
		$action     = $_GET['action'];
		$viewPage   = $this->siteUrl.'/wp-admin/admin.php?page='.$page;
		$detailPage = $this->siteUrl.'/wp-admin/admin.php?page='.$page.'&action=detail';
		$viewHistoryPage = $this->siteUrl.'/wp-admin/admin.php?page='.$page.'&action=view';
		$pagetitle=$this->subMenu[$page ];
		switch($action){
			case "detail":
				include_once(SC_BASE_PATH . "/templates/backend/detail_".$page.".php");
			break;
			case "view":
			     include_once(SC_BASE_PATH.'/library/libClass.php');
			     $libObj                 = new selluscarsLibrary();
				 $libObj->itemsPerPage   = $this->itemsPerPage;

				$libObj->currentPage    = ($_GET['num']!='') ? $_GET['num'] : 1 ;
				$this->offset           = $libObj->itemsPerPage *($libObj->currentPage-1);
				$search_text            ="";
				$total_record           =0;
				$msg_class              ="";
				$search_status          ="";
				include_once(SC_BASE_PATH . "/templates/backend/view_".$page.".php");
			break;
			default:
				include_once(SC_BASE_PATH.'/library/libClass.php');
				$libObj                 = new selluscarsLibrary();
				$libObj->itemsPerPage   = $this->itemsPerPage;

				$libObj->currentPage    = ($_GET['num']!='') ? $_GET['num'] : 1 ;
				$this->offset           = $libObj->itemsPerPage *($libObj->currentPage-1);
				$search_text            ="";
				$total_record           =0;
				$msg_class              ="";
				$search_status          ="";

				if(isset($_POST['search']))
				{
					$search_text=trim($_POST['input-search']);
					if(isset($_POST['active_status']) && $_POST['active_status']<2){
					 $search_status=trim($_POST['active_status']);
					 if($search_status==''){
						 unset($_REQUEST['active_status']);
					 }
					}
					$libObj->currentPage    = 1 ;
					$this->offset           = $libObj->itemsPerPage *($libObj->currentPage-1);
				}
				else if(isset($_REQUEST['s']))
				{
					$search_text=trim($_REQUEST['s']);
					$_REQUEST['search_text']=$_REQUEST['s'];
				}
				if(isset($_REQUEST['active_status'])){
					$search_status=$_REQUEST['active_status'];
					$_REQUEST['active_status']=$_REQUEST['active_status'];
				}
				include_once(SC_BASE_PATH . "/templates/backend/list_".$page.".php");
		}
    }
    public function dashboard()
	{
		include_once(SC_BASE_PATH . '/templates/backend/dashboard.php');
	}
	

	/* This function is used to get brands  */
    public function getBrands($data)
    {
	  $response = array();
	  $str="";
	  $response['success'] = 1;
	  $results=$this->getAllBrands('', $data['select_name']);
	  $str .='<div class="step_wrapper brands">';
	  $str .='<div class="note_text"><p>Great, now tell us the make of your car</p></div>';
		$str .='<div class="dir_arrow"><input name="brand" id="brand" onfocus="sortUlMake()" placeholder="Type your car’s make" onkeyup="sortUlMake()" autocomplete="off"></div>';
			$str .= '<ul id="'.$data['input_id'].'_list_ul" class="typeahead dropdown-menu" role="listbox">';
		  foreach ($results as $k => $v){
				$str .='<li class="list_'.$v['id'].'"><a class="dropdown-item" href="#" data-id="'.$v['id'].'" data-input_id="'.$data['input_id'].'" role="option">'.$v['name'].'</a></li>'; 
		  }
		$str .='</ul>';
      $str .='</div>';
      $response['data'] =$str;
      return $response;
    }
    /* This function is used to get models  */
    public function getmodels($data)
    {
	  $response = array();
	  $str="";
	  $response['success'] = 1;
	  $rec_id=$data['rec_id'];
	  $str .='<div class="step_wrapper models">';
	  	  $str .='<div class="note_text"><p>Way to go! What model '.$data['select_name'].' is your car?</p></div>';
		$str .='<div class="dir_arrow"><input class="form-control" type="text" id="model" placeholder="Type your car’s model" name="LEADCF5" value="" onfocus="sortUlModel()" onkeyup="sortUlModel()" ></div>';
			$str .='<ul id="'.$data['input_id'].'_list_ul" class="typeahead dropdown-menu" role="listbox">';
		   if(!empty($rec_id)){
			  $results=$this->getAllmodels($rec_id, $data['year']);
			  foreach ($results as $k => $v){
				$str .='<li class="list_'.$v['id'].'"><a class="dropdown-item" href="#" data-id="'.$v['id'].'" data-input_id="'.$data['input_id'].'" role="option">'.$v['model_name'].'</a></li>'; 

			  }
		   }else{
				$str .='<li class="list_'.$v['id'].'"><a class="dropdown-item" href="#" data-id="" role="option">Please select model name </a></li>';
		   }
       
		$str .='</ul>';
      $str .='</div>';
      $response['data'] =$str;
      return $response;
    }
    
    /* This function is used to get Variants dropdown list by id  */
    public function getVariantsDropDownList($data)
    {
	  $response = array();
	  $str="";
	  $response['success'] = 1;
	  $rec_id=$data['rec_id'];
	  $str .='<div class="step_wrapper variations">';
	    $str .='<div class="note_text"><p>Next up, tell us the variant of your '.$data['select_name'].'?</p></div>';
		$str .='<div class="dir_arrow"><input class="form-control" type="text" placeholder="Type your car’s variant" id="variant" name="LEADCF3" value="" onfocus="sortUlVariant()" onkeyup="sortUlVariant()"></div>';
		$str .= '<ul id="'.$data['input_id'].'_list_ul" class="typeahead dropdown-menu" role="listbox">';
		   if(!empty($rec_id)){
			  $results=$this->getAllVariants($rec_id, $data['year']);
			  foreach ($results as $k => $v){
				$str .='<li class="list_'.$v['id'].'"><a class="dropdown-item" href="#" data-id="'.$v['id'].'" data-input_id="'.$data['input_id'].'" role="option">'.$v['variant_name'].'</a></li>'; 
			  }
		   }else{
				$str .='<li class="list_'.$v['id'].'"><a class="dropdown-item" href="#" data-id="" role="option">Please select variant name</a></li>';
		   }
		$str .='</ul>';
      $str .='</div>';
      $response['data'] =$str;
      return $response;
    }
     
	 //~ /* This function is used to get Variants dropdown list by id  */
    //~ public function getVariantsDropDownList($data)
    //~ {
	  //~ $response = array();
	  //~ $str="";
	  //~ $response['success'] = 1;
	  //~ $rec_id=$data['rec_id'];
	  
	  //~ $str ='<label for="variant" class="col-form-label">Variant : </label><select class="form-control" required id="variant" name="LEADCF3">';
	  //~ $str .= '<option value="">Choose a variant</option>';
	  
	  //~ if(!empty($rec_id)){
		  //~ $results=$this->getAllVariants($rec_id);
		  //~ foreach ($results as $k => $v){
  		    //~ $str .='<option  value="'.$v['variant_name'].'">'.$v['variant_name'].'</option>'; 
		  //~ }
       //~ }
       
      //~ $str .= '</select>';
      //~ $response['data'] =$str;
      //~ return $response;
    //~ }
	
/* function used to get refresh Token*/
  public function getZohoAuthV2(){
	
	$client_id       =get_option( 'SC_zoho_client_id');
	$client_secret   =get_option( 'SC_zoho_client_secret');
	$code            ='1000.3138b6133ab50af628f882c0c53b8246.348aad87f733cf0be091abcc84df1958';  //selluscar
	$redirect_uri    = get_site_url();
	$grant_type      ='authorization_code';
	$fields          =array('client_id' => $client_id,'client_secret' => $client_secret,'redirect_uri' => $redirect_uri,'code' => $code, 'grant_type' => $grant_type);

	$curl = curl_init();
	curl_setopt_array($curl, array(
	CURLOPT_URL => "https://accounts.zoho.com/oauth/v2/token",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => $fields,
));

$response = curl_exec($curl);
curl_close($curl);
return $response;

}

/* function used to get Access Token*/
public function getZohoAccessTokenV2(){
	$response        =false;	
	$client_id       =get_option( 'SC_zoho_client_id');
	$client_secret   =get_option( 'SC_zoho_client_secret');
	$refresh_token   =get_option( 'SC_zoho_refresh_token');// put refresh_token 

	if(!empty($client_id) && !empty($client_secret) && !empty($refresh_token)){

		//$redirect_uri    = get_site_url();
		$redirect_uri    = 'https://www.selluscars.co.za';
		$grant_type      ='refresh_token';
		$fields          =array('refresh_token' => $refresh_token, 'client_id' => $client_id, 'client_secret' => $client_secret,'redirect_uri' => $redirect_uri, 'grant_type' => $grant_type);
			
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://accounts.zoho.com/oauth/v2/token",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => $fields,
		));
		$result     = curl_exec($curl);
		$response   = json_decode($result, true);
		curl_close($curl);
        
		if (count($response)>0 && array_key_exists("access_token",$response) )
		{
			$results  =array();
			$token    =$response['access_token'];
			$this->log_error($response, true);
			update_option( 'pl_access_token_token', $token);
			$response =$token;
		}else{
				$this->log_error($response, true);
		
		}

	}else{
		
		 $message="Please Login with admin account add the zoho details on your in general setting.";
		 //$this->zohoErrorEmail($message);
	}
	return $response;
}
/* function used to get post data in zoho*/
public function postZohoDataV2($dataArray, $module_api_name='Leads', $id=""){
//	print_r($dataArray);
	$results =array();
	$res    =array();
    $request  = "POST";
    $apiUrl ="";
	$apiUrl = "https://www.zohoapis.com/crm/v2/".$module_api_name;
	if(!empty($id)){
		$apiUrl = $apiUrl."/".$id;
		$request  = "PUT";
	}
    $fields=array("data" => [$dataArray]);
    //"trigger" => array('approval', 'workflow', 'blueprint')
	
	$results = $this->postZohoV2Curl($apiUrl, $fields, $request);
	
	//print_r($results);
	
	if(count($results)>0 && $results['code']=="INVALID_TOKEN" && $results['status']=="error"){
			$newToken = array();
			$token= $this->getZohoAccessTokenV2();
			if(!empty($token))
			{
				$results  =array();
			    $results  =$this->postZohoV2Curl($apiUrl, $fields, $request, $token);
			}
	 }
	 
	 if (count($results)>0 && $results['data'][0]['status']=='error')
	{
		   //log_error($results, true);
	}
	/*  print_r($results);
	echo  $results['data'][0]['code'];
	echo $results['data'][0]['details']['id'];
	exit;*/
	if(count($results)>0 && $results['data'][0]['code']=="SUCCESS" && $results['data'][0]['status']=="success"){
		$res['lead_id']  =$results['data'][0]['details']['id'];
		$res['status']   =$results['data'][0]['status'];
	}
   return $res;
}
/* function used call curl*/
public function postZohoV2Curl($apiUrl, $fields, $request, $token=''){
	
	$result = array();
	$fields = json_encode($fields);
	if(empty($token)){
		$token  =get_option( 'SC_access_token_token', ''); //put access_token here 
		if(empty($token)){
			$token = $this->getZohoAccessTokenV2();
		}
    }
	$authToken="Zoho-oauthtoken ".$token;
    
	$headers = array(
		'Content-Type: application/json',
		'Content-Length: ' . strlen($fields),
		sprintf('Authorization: %s', $authToken)
	);
    $ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $apiUrl);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $request);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);

	$result = curl_exec($ch);
	//log_error($result, true);
	$result = json_decode($result, true);

	curl_close($ch); 

return $result;
}

/* function used create a tasks*/
public function postZohoTaskV2($id, $fromContact = false, $module='Leads'){
    $dataArray   =array();
    $smID        = get_option( 'zoho_account_assign_to', '' );
   
    $dataArray['Owner']           =  $smID;
    $dataArray['Subject']         =  $sub;
    $dataArray['What_Id']         =  $id;
    $dataArray['Due_Date']        =  date('Y-m-d');
    $dataArray['$se_module']      =  $module;
    $dataArray['Priority']        =  'Highest';
    $dataArray['Description']     =  $des;
    
    $result = $this->postZohoDataV2($dataArray, $module_api_name='tasks');
	
    return $result;
}

public function zohoErrorEmail($text) {

	$admin_email = get_option( 'admin_email' );
	if(!empty($admin_email)){  
		function wpdocs_set_html_mail_content_type() {
			return 'text/html';
		}
		add_filter( 'wp_mail_content_type', 'wpdocs_set_html_mail_content_type' );
		$headers = "MIME-Version: 1.0". "\r\n";
		$headers .= 'From: selluscars <cars@selluscars.co.za>' . "\r\n" ;
		$headers.="Content-type: text/html;charset=utf-8". "\r\n";
		$headers .= "X-Mailer: PHP/". phpversion() ."\r\n";


		$siteUrl  = get_site_url();
		$email    = $admin_email;
		$subject  = "Zoho issue on selluscars";
		$message     ="";
		$message     ="Hi Admin,<br/><br/>";
		$message .= sprintf ( '<p>Attention: Your website <a 
		href="'.$siteUrl.'">"'.$siteUrl.'"</a> has Error encountered  "'.$text.'" while performing Insert form data in Zoho.</p>');
		wp_mail( $email, $subject, $message, $headers );
	}
}
public function sendLeadEmail($siteUrl, $step='1') {

	$admin_email = get_option( 'admin_email' );
	if(!empty($admin_email)){  
		function wpdocs_set_html_mail_content_type() {
			return 'text/html';
		}
		add_filter( 'wp_mail_content_type', 'wpdocs_set_html_mail_content_type' );
		$headers = "MIME-Version: 1.0". "\r\n";
		$headers .= 'From: selluscars <cars@selluscars.co.za>' . "\r\n" ;
		$headers.="Content-type: text/html;charset=utf-8". "\r\n";
		$headers .= "X-Mailer: PHP/". phpversion() ."\r\n";


		//$siteUrl  = get_site_url();
		$email    = $admin_email;
		$subject  = "New lead on selluscars";
		$message  ="";
		$message  .="Hi Admin,<br/><br/>";
		
		if($step==1){
		$message .= sprintf ( '<p>A new lead has been submit on your site. Click on below link to check the details of lead.</p>
		<p><a 
		href="'.$siteUrl.'">'.$siteUrl.'</a></p>
		');
		}else{
		
		$message .= sprintf ( '<p>Car infomation has been submit by user. Click on below link to check the details of lead.</p>
		<p><a 
		href="'.$siteUrl.'">'.$siteUrl.'</a></p>
		');
		
		
		}
		
		
		
		
		
		wp_mail( $email, $subject, $message, $headers );
	}
}

 public function getYearsList($data='')
    {
	  $response = array();
	  $res = array();
	  $str="";
	  $vid='';
	  if(count($data)>0 && isset($data['vid'])){
	     $vid=$data['vid'];
      }
	  $response['success'] = 1;
      $str .=' <div class="step_wrapper yearlist">';
      	$str .= ' <div class="note_text note_text_year"><p>Let’s start by choosing the year model of your car</p></div>';
		$str .= '<div class="year_container">';
			$str .= '<div class="dir_arrow"><input class="form-control" type="text" placeholder="e.g. 1989" id="year" value="" onfocus="sortUlYear()" onkeyup="sortUlYear()"></div>';
			//	$str .= '<a class="year_submit btn btn-primary next">Next</a>';
			$str . '</div>';
			$str .= '<ul id="year_list_ul" class="typeahead dropdown-menu" role="listbox">';
				 
				 if(!empty($vid)){
					  
					  $res=$this->getAllVariantById($vid);
					 // print_r($res);
					  if(count($res)>0){
						  $years=explode(",",$res[0]['years']);
						   $years=array_unique($years);
						  if(count($years)>0){
							  foreach($years as $year){
								  $str .='<li class="list_year_'.$year.'"><a class="dropdown-item" href="#" data-id="'.$year.'" data-input_id="year" role="option">'.$year.'</a></li>'; 
							  }
						  }
					}else{
						 $vid='';
					}
				  }
				 
				 if(empty($vid)){
					  $year = date("Y");
					  for($number=$year; $number>=$year-50; $number--){
							$str .='<li class="list_year_'.$number.'"><a class="dropdown-item" href="#" data-id="'.$number.'" data-input_id="year" role="option">'.$number.'</a></li>'; 
					  }
				  }
		$str .='</ul>';
      $str .='</div>';
      $response['data'] =$str;
      return $response;
    }
	
	public function getAllYearsList($data='')
    {
	  $response = array();
	  $res = array();
	  $str="";
	  $vid='';
	  $name='';
	  if(count($data)>0 && isset($data['vid'])){
	     $vid=$data['vid'];
      }
	  if(!empty($data['name'])){
	   $name=$data['name'];
	  }
	  $response['success'] = 1;
      $str .=' <div class="step_wrapper yearlist">';
	  
		$str .= ' <div class="note_text note_instructions"><p><span>'.$name.'</span>, our wizard will have your car loaded for valuation in a few steps.</p></div>';

		$str .= ' <div class="note_text note_instructions"><p>If you need to reset a selection from any of the steps, simply click or tap the X next to the item which can be found under the
		section “Currently Selected”</p></div>';
	  
      	$str .= ' <div class="note_text note_text_year"><p>Let’s start by choosing the year model of your car</p></div>';
		$str .= '<div class="year_container">';
			$str .= '<div class="dir_arrow"><input class="form-control" type="text" placeholder="Type your car’s year model" id="year" value="" onfocus="sortUlYear()" onkeyup="sortUlYear()" autofocus></div>';
				//$str .= '<a class="year_submit btn btn-primary next">Next</a>';
			$str . '</div>';
			$str .= '<ul id="year_list_ul" class="typeahead dropdown-menu" role="listbox">';
				   
				   $res=$this->getAllMakeYear();
					 // print_r($res);
					if(count($res)>0){
							$years=explode(",",$res[0]['years']);
							$years=array_unique($years);
							rsort($years);
							  if(count($years)>0){
								  foreach($years as $year){
									  $str .='<li class="list_year_'.$year.'"><a class="dropdown-item" href="#" data-id="'.$year.'" data-input_id="year" role="option">'.$year.'</a></li>'; 
								  }
							  }
					}
				 
		$str .='</ul>';
      $str .='</div>';
      $response['data'] =$str;
      return $response;
    }
	

    public function getFuelType()
    {
	  $response = array();
	  $str="";
	  $response['success'] = 1;
	  $rec_id=$data['rec_id'];
	  $str .=' <div class="step_wrapper fueltype">';
		  $str .='<ul id="fueltype_list_ul" class="typeahead dropdown-menu" role="listbox">';
		 
			  $results=$this->FuelTypeArray;
			  foreach ($results as $k => $v){
				$str .='<li class="list_'.$k.'"><a class="dropdown-item" href="#" data-id="'.$k.'" data-input_id="'.$v.'" role="option">'.$v.'</a></li>'; 

			  }
		  
		  $str .='</ul>';
      $str .=' </div>';
      $response['data'] =$str;
      return $response;
    }
	public function getGearType()
    {
	  $response = array();
	  $str="";
	  $response['success'] = 1;
	  $rec_id=$data['rec_id'];
	  $str .=' <div class="step_wrapper geartype">';
		  $str .='<ul id="geartype_list_ul" class="typeahead dropdown-menu" role="listbox">';
		 
			  $results=$this->GearTypeArray;
			  foreach ($results as $k => $v){
				$str .='<li class="list_'.$k.'"><a class="dropdown-item" href="#" data-id="'.$k.'" data-input_id="'.$v.'" role="option">'.$v.'</a></li>'; 

			  }
		  
		  $str .='</ul>';
      $str .=' </div>';
      $response['data'] =$str;
      return $response;
    }
	public function createYearString($exityears, $newyear){
	    $yearstr='';
		 if(count($data)>=0){
			$yearArr1 = explode(",",$exityears);
			$yearArr2 = explode(",",$newyear);
			$yearArr  = array_merge($yearArr1, $yearArr2);
			$yearArr  = array_unique($yearArr);
			$yearstr  = implode(",", $yearArr);
		}
			
		return $yearstr;
	}
	
	

}