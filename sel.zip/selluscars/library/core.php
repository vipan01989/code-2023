<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
class selluscars_core
{


    public $pluginOptions;
    public $pluginSettings;
    public $logErrors;
    public $homeUrl;
    public $useErrorLog = false;
    public $upload_info;
    public $adminNonceString        = "selluscars_admin_nonce";
    public $siteNonceString         = "selluscars_site_nonce";
    public $tablePrefix             = "sc_";
    public $keysExepmtedFromSanitize= array();
    public $itemsPerPage;
    public $offset;
    public $USAStates;
    public $siteUrl;
    public $lqMenuCapabilities;
    public $selluscarsOptions            =array();
    public $sliderTextHeading;
    public $sliderTextDescription;
    public $stateLinkOptionName      ="";
    
    public $tableMake;
    public $tableModel;
    public $tableVariant;
	public $tableUserDetails;
	public $tableUsers;
	public $tableUserCarImages;
	public $tableCarTempDetails;
    public $tableVariantYearDetails;

	
    public $FuelTypeArray            =array();
	public $uploadDirPath;
	public $uploadDirUrl;
	public $selluscarImagePath;
	public $selluscarImageUrl;
	public $selluscarTempDetailsCsvFile;
	public $selluscarCsvFileStatus;
	
	public $maxImageSize;
	public $maxImagelength;
	public $inMB;
	public $priceIcon;
	public $totalSteps;
	public $totalRecordSaveOneTime;
	//public $wp_sc_new_makes='wp_sc_new_makes';
	//public $wp_sc_test_models='wp_sc_new_models';
	//public $wp_sc_test_variant='wp_sc_new_variants';
    public $totalModelSaveOneTime =50;
    public $totalMakeSaveOneTime  =50;
    public $totalVariantOneTime   =300;
    public $totalCarTempOneTime   =1000;

    function __construct()
    {
        $this->setTableNames();
        $this->keysExepmtedFromSanitize       = array('community_id', 'school_id', 'membership', 'image', 'category_id','community','subscription','membership_name','duration','attachment','advertisement_type','discount','type_description','coupon','active','old_attachment');
        $this->itemsPerPage                   = 10;
        $this->offset                         = 0;
        $this->totalRecordSaveOneTime         = 50;
		//$this->maxImageSize                 = "1024000";    //1 MB
		$this->maxImageSize                   = (!empty(get_option('SC_max_image_size')))?get_option('SC_max_image_size'):1024000;    //1 MB
		$inmb                                 = round($this->maxImageSize/1024000);
		$this->inMB                           = $inmb." MB";    //1 MB
		//$this->maxImagelength               = "5";    //1 MB
		$this->maxImagelength                 = (!empty(get_option('SC_max_image_length')))?get_option('SC_max_image_length'):5;  
        $this->totalSteps                     = 9;		
		
		$this->priceIcon                    = "R"; 
        $this->pluginOptions                = array('data_type' => '_selluscars_data_type');
        $this->homeUrl                      = network_home_url();
        $this->siteUrl                      = get_site_url();
	
        $this->upload_info                  = wp_upload_dir();
		$this->uploadDirPath                = $this->upload_info['basedir'];
        $this->uploadDirUrl                 =$this->upload_info['baseurl'];
		$this->selluscarImagePath           = $this->uploadDirPath . "/carsImages/";
        $this->selluscarImageUrl            = $this->uploadDirUrl."/carsImages/";
        $this->selluscarTempDetailsCsvFile  = $this->uploadDirPath . "/CarTempDetailsCsvFile/";
        
        $this->sliderTextHeading            ="_selluscars_slider_heading";
        $this->sliderTextDescription        ="_selluscars_slider_description";
        $this->stateLinkOptionName          ="_selluscars_state_links";
        $this->selluscarsOptions	                = array(
                                                    $this->sliderTextHeading     		=>"",
                                                    $this->sliderTextDescription 		=>""
                                                );
        $this->lqMenuCapabilities           ="manage_options";
		$this->FuelTypeArray	                = array("Diesel"=>"Diesel",
		                                                "Electric"=>"Electric",
														"Hybrid"=>"Hybrid",
														"Petrol"=>"Petrol",
														);
		$this->GearTypeArray	                = array("Manual"=>"Manual",
		                                                "Automatic"=>"Automatic"
														);
        $this->getPluginSettings();
        add_action('current_screen', array($this, 'check_current_screen'), 99);
    }

    public function setTableNames()
    {
		 global $wpdb;
	    
        $this->tableMake                                 = $wpdb->prefix . $this->tablePrefix . "new_makes";
        $this->tableModel                                 = $wpdb->prefix . $this->tablePrefix . "new_models";
        $this->tableVariant                               = $wpdb->prefix . $this->tablePrefix . "new_variants";
		$this->tableUserDetails                           = $wpdb->prefix . $this->tablePrefix . "user_details";
		$this->tableUserCarDetails                        = $wpdb->prefix . $this->tablePrefix . "user_car_details";
		$this->tableCarTempDetails                        = $wpdb->prefix . $this->tablePrefix . "temp_car_details";
		$this->tableUserCarImages                         = $wpdb->prefix . $this->tablePrefix . "user_car_images";
		$this->tableVariantYearDetails                    = $wpdb->prefix . $this->tablePrefix . "variant_year_details";
	    $this->selluscarCsvFileStatus                     = $wpdb->prefix . $this->tablePrefix . "csv_file_status";
		$this->tableUsers                                 = $wpdb->prefix . "users";
		$this->tableMetaUsers                             = $wpdb->prefix . "usermeta "; 
 }

    public function check_current_screen()
    {
        $screen = get_current_screen();
    }

    public function log_error($error, $onlySelected = false)
    {
        if ($this->useErrorLog == true || $onlySelected == true) {
            $this->log(true);
            error_log(print_r($error, true));
        }
    }

    public function log($logError = false)
    {
        $this->errorFileDir = SC_BASE_PATH . '/logs';
        $this->errorFile = $this->errorFileDir . '/error.log';
        if (!file_exists($this->errorFileDir)) {
            @mkdir($this->errorFileDir, 0777, true);
        } else if (substr(fileperms($this->errorFileDir), 0, -3) != '777') {
            @chmod($this->errorFileDir, 0777);
        }

        $this->logErrors = $logError;
        if ($this->logErrors) {
            ini_set('error_log', $this->errorFile);
            if (!file_exists($this->errorFile)) {
                $fh = @fopen($this->errorFile, 'w');
                @fclose($fh);
                @chmod($this->errorFile, 0777);
            }
        }
    }

    function getPluginSettings($param = '')
    {
        $setting = array();

        foreach ($this->pluginOptions as $k => $v) {
            $setting[$k] = get_option($v, NULL);
        }
        $this->pluginSettings = $setting;
        return $setting;
    }

    public function isUrl($string)
    { // check if a url is valid
        $regex = '/^(?:http|https)?(?:\:\/\/)?(?:www.)?(([A-Za-z0-9-]+\.)*[A-Za-z0-9-]+\.[A-Za-z]+)(?:\/.*)?$/im';
        if (preg_match($regex, $string, $matches)) {
            return true;
        }
        return false;
    }

    protected function sanitizeVariables($input)
    {
        $output = array();
        if (is_array($input) && count($input) > 0) {
            foreach ($input as $k => $v) {
                if (!in_array($k, $this->keysExepmtedFromSanitize)) {
                    $output[$k] = sanitize_text_field($v);
                } else {
                    $output[$k] = $v;
                }
            }
        }
        return $output;
    }

    /* Get Data from database */
    /* This function is used to get all data from database */
    public function getAllData($table, $order_by = "", $condition = "", $count = false)
    {
        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
            $query = " SELECT count(*) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
            $query = " SELECT * FROM " . $table . " " . $where . " " . $order_by . "";
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }

    /* This function is used to get all data from database according to limit */
    public function getData($table, $condition = "", $count = false)
    {

        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
            $query = " SELECT count(*) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
            $query = " SELECT * FROM " . $table . " " . $where . "";
            $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
           // echo $query;
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }

    /* This function is used to delete record */
    public function deleteRecord($data)
    {
        global $wpdb;
        $tableName = $data['table'];
        $id = $data['id'];

        global $wpdb;
        $delete = $wpdb->query($wpdb->prepare("DELETE FROM " . $tableName . "  WHERE id = %d ", $id));
        if (is_wp_error($delete)) {
            $return['success'] = 0;
            $return['message'] = $wpdb->last_error;

        } else {
            $return['success'] = 1;
            $return['message'] = "Record deleted successfully.";
        }
        return $return;
    }

    /* This function is used to delete record according to key and value */
    public function deleteChildRecord($data)
    {
        global $wpdb;
        $tableName = $data['table'];
        $key       = $data['key'];
        $value    = $data['value'];

        global $wpdb;
        $delete = $wpdb->query($wpdb->prepare("DELETE FROM " . $tableName . "  WHERE " . $key . " = %d ", $value));
        if (is_wp_error($delete)) {
            $return['success'] = 0;
            $return['message'] = $wpdb->last_error;
        } else {
            $return['success'] = 1;
            $return['message'] = "Record deleted successfully.";
        }
        return $return;
    }

    public function getDbFields($tableName, $labels = false)
    {
        global $wpdb;
        $query = 'SHOW COLUMNS FROM ' . $tableName . '';
        $data = $wpdb->get_results($query);
       // echo $this->specialFields;
        if (!$labels) {
            foreach ($data as $k => $v) {
                if (@array_key_exists($tableName, $this->specialFields)) {
                    if (@array_key_exists($v->Field, $this->specialFields[$tableName])) {
                        $fields[$k] = $this->specialFields[$tableName][$v->Field];
                    } else {
                        $fields[$k] = array(
                            'name' => $v->Field
                        );
                        $fields[$k] = array_merge($fields[$k], $this->getFieldsType($v->Type));
                    }
                } else {
                    $fields[$k] = array(
                        'name' => $v->Field
                    );
                    $fields[$k] = array_merge($fields[$k], $this->getFieldsType($v->Type));
                }
            }
        } else {
            foreach ($data as $k => $v) {
                $fields[$v->Field] = $v->Field;
            }
        }
        return $fields;
    }

    public function getFieldsType($type)
    {
        preg_match('/(.*)\((.*)\)/', $type, $matches);
        if (count($matches) <= 0) {
            $matches[1] = $type;
            $matches[2] = '';
        }
        $typeArray = array(
            'type' => $matches[1],
            'limit' => $matches[2]
        );
        return $typeArray;
    }

    public function createQuery($tableName, $data, $isDate = false)
    {
        global $wpdb;
        $lastId = '';
		
	
        $action = $data['action'];
        $currentDate = date("Y-m-d H:i:s");
        $processedData = $this->generateQuery($data, $tableName);
		//print_r($processedData);
	
        $where = array(
            'id' => $data['id']
        );
        switch ($action) {
            case 'add':
                if ($isDate) {
                    $processedData['created_date'] = $currentDate;
                    $processedData['modified_date'] = $currentDate;
                }
                $wpdb->insert($tableName, $processedData);
				//print_r($wpdb);
                $lastId = $wpdb->insert_id;
                break;

            case 'edit':
                if ($isDate) {
                    $processedData['modified_date'] = $currentDate;
                }
                $wpdb->update($tableName, $processedData, $where);
                $lastId = $data['id'];
                break;
            default:
        }
        return $lastId;
    }

    public function generateQuery($data, $tableName)
    {
        $fieldsArray = array();

        $fields = $this->getDbFields($tableName);

        foreach ($fields as $k => $v) {
            if (array_key_exists($v['name'], $data)) {
                if ($v['type'] == 'date' || $v['type'] == 'datetime') {
                    $data[$v['name']] = date('Y-m-d', strtotime($data[$v['name']]));
                }
                $fieldsArray = array_merge($fieldsArray, array(
                    $v['name'] => stripcslashes($data[$v['name']])
                ));
            }
        }
        return $fieldsArray;
    }
    
    public function getAllBrands($name="", $year='', $status=1)
    {
        global $wpdb;
        $where = " WHERE tbl.status=" . $status;
        if (!empty($name)) {
            $where .= " AND tbl.name LIKE '%".$name."%' ";
        }
		if (!empty($year)) {
            $where .= " AND tbl.years LIKE '%".$year."%' ";
        }
        
        $query  = "SELECT * FROM ".$this->tableMake." tbl ".$where." order by tbl.name ASC";
        $myRows  = $wpdb->get_results($query, ARRAY_A);
      	
      	return $myRows;
    }
    public function getAllmodels($rec_id, $year='', $status=1)
    {
        global $wpdb;
        $where = " WHERE tbl.status=" . $status;
        if (!empty($rec_id)) {
            $where .= " AND tbl.make_id=".$rec_id;
        }
		if (!empty($year)) {
            $where .= " AND tbl.years LIKE '%".$year."%' ";
        }
        
        $query  = "SELECT * FROM ".$this->tableModel." tbl ".$where." order by tbl.model_name ASC";
        $myRows  = $wpdb->get_results($query, ARRAY_A);
      	
      	return $myRows;
    }
    public function getAllVariants($rec_id, $year='', $status=1)
    {
        global $wpdb;
        $where = " WHERE tbl.status=" . $status;
        if (!empty($rec_id)) {
            $where .= " AND tbl.model_id=".$rec_id;
        }
        if (!empty($year)) {
            $where .= " AND tbl.years LIKE '%".$year."%' ";
        }
        $query  = "SELECT * FROM ".$this->tableVariant." tbl ".$where." order by tbl.variant_name ASC";
        $myRows  = $wpdb->get_results($query, ARRAY_A);
      	
      	return $myRows;
    }
    public function getAllVariantById($vid, $status=1)
    {
        global $wpdb;
        $where = " WHERE tbl.status=" . $status;
        if (!empty($vid)) {
            $where .= " AND tbl.id=".$vid;
        }
        
        $query  = "SELECT * FROM ".$this->tableVariant." tbl ".$where." order by tbl.variant_name ASC";
        $myRows  = $wpdb->get_results($query, ARRAY_A);
      	
      	return $myRows;
    }
	
	/* This function is used to save user data  */
    public function saveUserDetails($data)
	{
	  $response            = array();
	  $response['success'] = 0;
	  $lead_id             ='';
	  $id                  ='';
	 
	// echo $id=$this->checkUserExist($data['email']);
	  
	  if(!empty($data['email'])){
		  
			$dataDetails            = array();
			
			$id=$this->checkUserExist($data['email']);
			
			$nameArray=explode(" ",$data['name']);
			$First_Name='';
			$Last_Name='';
			if(count($nameArray)>1){
				$First_Name =$nameArray[0];
				unset($nameArray[0]);
				$Last_Name =implode(" ",$nameArray);
			 
			}else{
				$First_Name=$data['name'];
			}
			
			$dataZoho['First_Name'] = $First_Name;
			
			if(empty($Last_Name)){
				$dataZoho['Last_Name']  ='.';
			}else{
				$dataZoho['Last_Name']  = $Last_Name;
			}
			
			$dataZoho['Email']      = $data['email'];
			$dataZoho['Phone']      = $data['phone'];
             $_SESSION['name'] = $First_Name.$Last_Name;
             $_SESSION['email'] = $data['email'];
             $_SESSION['phone'] = $data['phone'];
			if(empty($id)){
				
				$userData = array(
					'user_login'    => $data['email'],
					'user_nicename' => $First_Name.$Last_Name,
					'display_name'  => $First_Name.$Last_Name,
					'user_email'    => $data['email'],
					'user_pass'     => $data['email'], // When creating an user, `user_pass` is expected.
					'role' => 'subscriber'
				);
				$id = wp_insert_user($userData);
               	update_user_meta( $id, 'phone_number', $data['phone'] );
				update_user_meta( $id, 'first_name', $First_Name );
				update_user_meta( $id, 'last_name', $Last_Name );
			}
			$phone_number  = get_user_meta( $user_id, 'phone_number', true );
			$f_name        = get_user_meta( $user_id, 'first_name', true );
			$l_name        = get_user_meta( $user_id, 'last_name', true );
			
			if(empty($f_name) && !empty($First_Name)){
					update_user_meta( $id, 'first_name', $First_Name );
			}
			if(empty($l_name) && !empty($Last_Name)){
					update_user_meta( $id, 'last_name', $Last_Name );
			}
			
			if(empty($phone_number)){
					update_user_meta( $id, 'phone_number', $data['phone'] );
			}
			if(!empty($id)){
				
				$res = $this->postZohoDataV2($dataZoho);
				if(!empty($res['lead_id'])){
					$lead_id = $res['lead_id'];
				}
				$dataDetails['action']  ='add';
				$dataDetails['zoho_id'] =$lead_id;
				$dataDetails['user_id'] =$id;
				$dataDetails['phone']   =$data['phone'];
				$dataDetails['status']  =1;
			
				$rid=$this->createQuery($this->tableUserCarDetails, $dataDetails, true);
			   
			   $response['success'] = 1;
			   $response['id']      =$rid;
			   $response['user_id'] =$id;
			   $response['lead_id'] =$lead_id;
			
			   $res                 = $this->getAllYearsList($data); 
			   $str='';
			   $siteUrl  = get_site_url();
			   $url=$siteUrl.'/wp-admin/admin.php?page=lead&action=detail&id='.$rid.'&user_id='.$id;
			  // $this->sendLeadEmail($url);
			   $str .=$res['data'];
			   $response['html_data']    = $str;
               $response['message'] = "Record added successfully.";
			}else{
				 $response['message'] = "Error occurring while inserting record.";
			}
			  
	  }else{
		   $response['message'] = 'Email field is empty';
		
	  }
	  
	  
      return $response;
    }
	
	public function checkUserExist($email)
    {
        global $wpdb;
        $return='';
        $query  = "SELECT * FROM ".$this->tableUsers."  where user_email='".$email."'";
		$myRows  = $wpdb->get_results($query, ARRAY_A);
		if(count($myRows)>0){
			$return=$myRows[0]['ID'];
		}
		return $return;
    }
	public function getCarData($data){
	  $response             =  array();
	  $response['success']  = 0;
	  $selectdata           ='';
	   //print_r($data);
	  if($data['input_id']=='model'){
		  $result = $this->getmodels($data);
		 
		  $selectdata='<li id ="brand_list_li" data-val="'.$data['select_name'].'" class="list-group-item list-group-item-info" >
		        <strong>Make: &nbsp;</strong>'.$data['select_name'].'<span class="cross" ng-show="brands">&#x2716;</span>
			</li>';
		
		  
	  }
	 if($data['input_id']=='variant'){
		  $result = $this->getVariantsDropDownList($data);
		  $selectdata='<li id ="model_list_li" data-val="'.$data['select_name'].'" class="list-group-item list-group-item-info" >
		        <strong>Model: </strong> &nbsp;'.$data['select_name'].'<span class="cross" ng-show="models">&#x2716;</span>
			</li>';
		
		  
	  }
	    $response['success']     = 1;
		$response['data']        = $result['data'];
		$response['selectdata']  = $selectdata;
	  return $response;
    }
	public function saveCarDetails($data)
	{
		$response            = array();
		$lid                 ='';
	    $response['success'] = 0;
		 $lid =$data['zoho_id'];
		 $id =$data['user_id'];
		 $c_user_id =$data['c_user_id'];
		 unset($data['action']);
		 unset($data['task']);
		 unset($data['security']);
		 unset($data['zoho_id']);
		 unset($data['user_id']);
		 unset($data['c_user_id']);
		 $data['action']  ='edit';
		 $data['id']  =$id;
		 
		
		$rid=$this->createQuery($this->tableUserCarDetails, $data, true);
		$siteUrl  = get_site_url();
	    $url=$siteUrl.'/wp-admin/admin.php?page=lead&action=detail&id='.$rid.'&user_id='.$c_user_id;
		//$this->sendLeadEmail($url, '2');
		
		if(!empty($id)){
				$imagesUrls='';
				  $images=$this->getCarImagesById($id);
				//  print_r($images);
				   if(count($images)>0){ 
						foreach ($images as $image){
							$imagesUrls .=$image['image_url']. "\n";
						}
						//$imagesUrls=nl2br($imagesUrls);
					}
			}
		
		$dataZoho['Brand']               = $data['make'];
		$dataZoho['Model']               =$data['model'];
	    $dataZoho['Variant']             = $data['variant'];
		//$dataZoho['Fuel_type']           =$data['fuel_type'];
	   // $dataZoho['Transmission']        = $data['transmission'];
		$dataZoho['Odometer_reading']    = $data['odometer'];
		$dataZoho['Year_Model']          =$data['year'];
		if (strpos($data['expected_price'], ',') !== false) {
		 $data['expected_price']          =str_replace(",","",$data['expected_price']);
		}
		
		
		$dataZoho['Indicative_Price']    = $data['expected_price'];
		if(!empty($data['bank_settlementvalue'])){
			if (strpos($data['bank_settlementvalue'], ',') !== false) {
				$data['bank_settlementvalue']          =str_replace(",","",$data['bank_settlementvalue']);
			 
			 
			}
			    $dataZoho['Bank_Settlement_Value']    = $data['bank_settlementvalue'];
			    $dataZoho['Do_you_have_a_bank_settlement_on_your_car']    =true;
		}

        //$dataZoho['Colour']              =$data['colour'];
		//$dataZoho['Registration_Number'] =$data['registration'];
		$dataZoho['Images_links']        =$imagesUrls;
		if(!empty($data['about_vehicle'])){
			$dataZoho['Anything_we_need_to_know_about_your_vehicle']     ="User Note: ".$data['about_vehicle'];
		}
		$dataZoho['City']                = $data['Location'];
		

		
		
		if(!empty($lid)){
			//echo $lid;
	      //  print_r($dataZoho);
			$res = $this->postZohoDataV2($dataZoho, 'Leads', $lid);	
		}
		
		if(!empty($id)){
			   $response['success'] = 1;
               $response['message'] = "<h2>Thank you! Your application will be assessed shortly.</h2><p>Please check your email for our offer. If you're happy with the price, simply reply and we'll arrange a visit to view your car.</p>";
		}
		return $response;
	}
	 /* This function is used to check record exists or not */
    public function checkRecordExists($table, $key, $value)
    {
        global $wpdb;
        $return = false;
        $query = "SELECT COUNT(*) FROM $table WHERE $key='" . $value . "'";
        $count = $wpdb->get_var($query);
        if ($count > 0) {
            $return = true;
        }
        return $return;
    }
	
	 /* This function is used to get all users data */
     public function getMembersAllData($data='', $count = false)
    {
        global $wpdb;
        $myRows = array();
        $where = "";
		$details= "";
        $condition              ="";
		$condition =" tbl.id!=''";
		if(isset($data['id']) && !empty($data['id']))
		{
			$condition .=" AND tbl.id=".$data['id'];
			
			$details='tbl.Location, tbl.make, tbl.model, tbl.variant, tbl.fuel_type, tbl.transmission, tbl.year,  tbl.odometer, tbl.registration, tbl.colour, tbl.expected_price, tbl.bank_settlementvalue, tbl.about_vehicle, tbl.agent_comment, tbl.contacted,';
		}else{
		if(!empty($data['lead_search'])){
		$condition ="CONCAT_WS('',tbl.name,tbl.model,tbl1.display_name, tbl1.user_email, tbl.phone,tbl.make,tbl.year,tbl.variant,tbl.colour) LIKE '%".$data['lead_search']."%'";
		}else{
		$condition="";
		}
		}
        
         if(!empty($condition) )
        {
             $where =" WHERE ".$condition;
        }
		//Select tbl.id,tbl.user_id,tbl1.ID, tbl1.user_email from wp_sc_user_car_details tbl
//INNER JOIN wp_users tbl1 ON tbl.user_id=tbl1.ID
        if ($count == true) {
                $query = "SELECT count(tbl.id)
                            FROM " . $this->tableUserCarDetails . " tbl
                            INNER JOIN " . $this->tableUsers . " tbl1 ON tbl.user_id=tbl1.ID".$where;
                $myRows = $wpdb->get_var($query);
        } else {
		$details='tbl.Location, tbl.make, tbl.model, tbl.variant, tbl.fuel_type, tbl.transmission, tbl.year, tbl.odometer, tbl.registration, tbl.colour, tbl.expected_price, tbl.bank_settlementvalue, tbl.about_vehicle, tbl.agent_comment, tbl.contacted,';
		$where .= "";
        $query = "SELECT ".$details."tbl1.display_name,tbl.id,tbl.name,tbl.user_id, tbl.phone, tbl1.user_email,
  MAX(CASE WHEN tbl2.meta_key = 'first_name' THEN meta_value END) AS f_name,
  MAX(CASE WHEN tbl2.meta_key = 'last_name' THEN meta_value END) AS l_name  
                            FROM ((" . $this->tableUserCarDetails . " tbl
                            INNER JOIN " . $this->tableUsers . " tbl1 ON tbl.user_id=tbl1.ID
                            )INNER JOIN " . $this->tableMetaUsers . " AS tbl2 ON tbl1.id = tbl2.user_id) 
".$where." GROUP BY tbl.id ORDER BY tbl.id DESC";
                            
            $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
            $myRows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myRows;
    }
	
	 /* This function is used to get car images by id */
	public function getCarImagesById($id)
    {
        global $wpdb;
        $return='';
        $query  = "SELECT * FROM ".$this->tableUserCarImages."  where lead_id='".$id."'";
		$myRows  = $wpdb->get_results($query, ARRAY_A);
		
		return $myRows;
	}
	
		    /* Use to create unique file name*/
public function file_newname($path, $filename){
	$results= array();
    if ($pos = strrpos($filename, '.')) {
           $name = substr($filename, 0, $pos);
           $ext = substr($filename, $pos);
    } else {
           $name = $filename;
    }

    $newpath = $path.'/'.$filename;
    $newname = $filename;
    $counter = 0;
    while (file_exists($newpath)) {
           $newname = $name .'_'. $counter . $ext;
           $newpath = $path.'/'.$newname;
           $counter++;
     }
    $newname = str_replace(' ', '', trim(preg_replace('/\s+/', ' ', $newname)));

    $results['newpath']=$path.'/'.$newname;
    $results['newname']=$newname;
    $results['dir']   =$path;
    return $results;
}
/* Use to covert css file data to array name*/
public function csv_to_array($file_name, $startLine = 0, $endLine = 100) {
        $data =  $header = array();
        $i = 0;
        $file = fopen($file_name, 'r');
        
        while (($line = fgetcsv($file)) !== FALSE) {
            if( $i==0 ) {
                $header = $line;
            } else {
                $data[] = $line;        
            }
            $i++;
        }
        fclose($file);
        foreach ($data as $key => $_value) {
            $new_item = array();
            foreach ($_value as $key => $value) {
                $new_item[ $header[$key] ] =$value;
            }
            $_data[] = $new_item;
        }
        return $_data;
  }
  
  /* This function is used to get all  distinct data from database */
    public function getDistinctData($table, $distinct, $condition = "", $count = false)
    {

        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
             $query = " SELECT count( DISTINCT ".$distinct." ) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
           $query = " SELECT  DISTINCT ".$distinct."  FROM " . $table . " " . $where . "";
           
          //  $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }
    
      /*This function is used to get getMakeModel data */
    public function getMakeModel($condition='', $count = false)
    {
        global $wpdb;
        $myRows = array();
        $where = " WHERE tbl.status=1 AND tbl1.status=1 ";
        if(!empty($condition)){
			 $where .= $condition;
			
		}
       
        
        if ($count == true) {
               $query = "SELECT count(tbl1.id)
                            FROM " . $this->tableMake . " tbl
                            INNER JOIN " . $this->tableModel . " tbl1 ON tbl1.make_id=tbl.id ".$where;
            $myRows = $wpdb->get_var($query);
        } else {
           $query = "SELECT tbl.id, tbl.name, tbl1.model_name, tbl1.is_master, tbl1.id as Mid
                            FROM " . $this->tableMake . " tbl
                            INNER JOIN " . $this->tableModel . " tbl1 ON tbl.id=tbl1.make_id". $where;
           // $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
            $myRows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myRows;
    }
    
        /*This function is used to get getMakeModel data */
    public function getMakeModelVarient($condition='', $count = false)
    {
        global $wpdb;
        $myRows = array();
        $where = " WHERE tbl.status=1 AND tbl1.status=1  AND tbl2.status=1 ";
        if(!empty($condition)){
			 $where .= $condition;
			
		}

        
        if ($count == true) {
                        $query = "SELECT count(tbl1.id)
                             FROM " . $this->tableVariant . " tbl
                             INNER JOIN " . $this->tableModel . " tbl1 ON tbl.model_id=tbl1.id
                             INNER JOIN " . $this->tableMake . " tbl2 ON tbl2.id=tbl1.make_id ".$where;
            $myRows = $wpdb->get_var($query);
        } else {
           $query = "SELECT tbl2.id, tbl2.name, tbl1.model_name, tbl1.id as Mid, tbl.id as Vid, tbl.variant_name 
                             FROM " . $this->tableVariant . " tbl
                            INNER JOIN " . $this->tableModel . " tbl1 ON tbl.model_id=tbl1.id
                            INNER JOIN " . $this->tableMake . " tbl2 ON tbl2.id=tbl1.make_id ".$where;
                            
           // $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
            $myRows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myRows;
    }
    
    public function getAllDataOfTable($table, $condition = "", $count = false)
    {
        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
            $query = " SELECT count(*) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
           $query = " SELECT * FROM " . $table . " " . $where . " ";
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }
    
    Public function convertToArray($fData, $total_saved) {
		$results =array();
		if(empty($total_saved)){
			unset($fData[0]);
		}
		if(count($fData)>0){
			$i=0;
			foreach($fData as $res){
				$fndata=explode(",",  $res);
				$data   = array();
				$data['MMCode']             = $fndata[0];
				$data['VehicleType']        =$fndata[1];
				$data['Make']               =$fndata[2];
				$data['Model']              =$fndata[3];
				$data['Variant']            =$fndata[4];
				$data['RegYear']            =$fndata[5];
				$data['PublicationSection'] =$fndata[6];
				$data['Master_Model']       =$fndata[7];
				$data['Make_Code']          =$fndata[8];
				$data['VariantCode']        =$fndata[9];
				$data['AxleConfiguration']  =$fndata[10];
				$data['BodyType']           =$fndata[11];
				$data['NoOfDoors']          =$fndata[12];
				$data['Drive']              =$fndata[13];	
				$data['Seats']              =$fndata[14];
				$data['Use']                =$fndata[15];
				$data['Wheelbase']          =$fndata[16];
				$data['ManualAuto']         =$fndata[17];
				$data['NoGears']            =$fndata[18];
				$data['Cooling']             =$fndata[19];
				$data['CubicCapacity']       =$fndata[20];
				$data['CylConfiguration']    =$fndata[21];
				$data['EngineCycle']         =$fndata[22];
				$data['FuelTankSize']        =$fndata[23];
				$data['FuelType']            =$fndata[24];
				$data['Kilowatts']           =$fndata[25];
				
				$data['Kilowatts']               =$fndata[26];
				$data['NoCylinders']             =$fndata[27];
				$data['TurboOrSuperCharged']     =$fndata[28];
				$data['GCM']                     =$fndata[29];
				$data['GVM']                     =$fndata[30];
				$data['Tare']                    =$fndata[31];
				$data['Origin']                  =$fndata[32];
				$data['FrontNoTyres']            =$fndata[33];
				$data['FrontTyreSize']           =$fndata[34];
				$data['RearNoTyres']             =$fndata[35];
				$data['RearTyreSize']            =$fndata[36];
				$data['IntroDate']               =$fndata[37];
				$data['DiscDate']                =$fndata[38];
				$data['CO2']                     =$fndata[39];
				$data['Length']                  =$fndata[40];
				$data['Height']                  =$fndata[41];
				$data['Width']                   =$fndata[42];
				$data['NewListPrice']            =$fndata[43];
				$results[] =$data;
	
			$i++;	
			}
			
		}
		return $results;
	}
	 /* This function is used to check multiple key data from database */
    public function checkRecordInData($table, $condition = "")
    {
        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        $return = false;
		$query = " SELECT count(*)  FROM " . $table . " " . $where . "";
	   $count = $wpdb->get_var($query);
        if ($count > 0) {
            $return = true;
        }
        return $return;
    }
    
    /* This function is used to get all  distinct data from database */
    public function getDistinctGroupByData($table, $distinct, $groupkey, $condition = "", $count = false)
    {

        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
             $query = " SELECT count( DISTINCT ".$distinct." ) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
        //   echo $query = " SELECT  DISTINCT ".$distinct."  FROM " . $table . " " . $where . "";
             $query ="SELECT ".$distinct.", group_concat(DISTINCT(".$groupkey.")) as years  FROM " . $table . " " . $where . "";
                     
          //  $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }
     public function getAllMakeYear($status=1)
    {
        global $wpdb;
        $where = " WHERE tbl.status=" . $status;
        
         $query  = "SELECT group_concat(DISTINCT(tbl.years)) as years  FROM ".$this->tableMake." tbl group by tbl.status";
	//	group_concat(DISTINCT(years)) as years 
        $myRows  = $wpdb->get_results($query, ARRAY_A);
		
      	
      	return $myRows;
    }
}
