<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class selluscars_shortcode extends selluscars_hooks{
	
	function __construct(){
		parent::__construct();
		add_action( 'init', array($this, 'addShortCodes') );
		add_action( 'admin_init', array($this, 'zoho_settings_register_fields') );
	}

	public function addShortCodes(){
        add_shortcode('sell-us-cars-form',array($this ,'sell_us_cars_form'));
		add_shortcode('sell-us-cars-form-new',array($this ,'sell_us_cars_form_new'));
		add_shortcode('sell-us-cars-form-new',array($this ,'sell_us_cars_form_new'));
	
	}
    public function sell_us_cars_form()
    {
        ob_start();
        include_once(SC_BASE_PATH.'/templates/frontend/sell_us_cars_form.php');
        $content=ob_get_clean();
        return $content;
    }
	  public function sell_us_cars_form_new()
    {
        ob_start();
        include_once(SC_BASE_PATH.'/templates/frontend/sell_us_cars_new_form.php');
        $content=ob_get_clean();
        return $content;
    }
	
     public function zoho_settings_register_fields()
       {

    register_setting('general', 'SC_zoho_client_id', 'esc_attr');
    register_setting('general', 'SC_zoho_client_secret', 'esc_attr');
    register_setting('general', 'SC_zoho_refresh_token', 'esc_attr');
    register_setting('general', 'SC_access_token_token', 'esc_attr');
	register_setting('general', 'SC_zoho_account_assign_to', 'esc_attr');
	
	register_setting('general', 'SC_max_image_length', 'esc_attr');
	register_setting('general', 'SC_max_image_size', 'esc_attr');
    add_settings_section(
        'zoho_settings',
        'Zoho Settings',
         '__return_false',
         'general'
       );

    add_settings_field( 'SC_zoho_client_id', 'Zoho client Id:', array($this ,'SC_zoho_client_id_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_zoho_client_id' ) );

   add_settings_field( 'SC_zoho_client_secret', 'Zoho Client Secret:',  array($this ,'SC_zoho_client_secre_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_zoho_client_secret' ) );

   add_settings_field( 'SC_zoho_refresh_token', 'Zoho Refresh Token :', array($this ,'SC_zoho_refresh_token_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_zoho_refresh_token' ) );

   add_settings_field( 'SC_access_token_token', 'Zoho Access Token:', array($this ,'SC_access_token_token_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_access_token_token' ) );
   add_settings_field( 'SC_zoho_account_assign_to', 'Zoho Assigned To ID:', array($this ,'SC_zoho_account_assign_to_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_zoho_account_assign_to' ) );
  
  
   add_settings_field( 'SC_max_image_length', 'Total car images to upload:', array($this ,'SC_max_image_length_to_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_max_image_length' ) );
   add_settings_field( 'SC_max_image_size', 'Max images size to upload:', array($this ,'SC_max_image_size_to_html'), 'general', 'zoho_settings', array( 'label_for' => 'SC_max_image_size' ) );
  
}
public function SC_zoho_client_id_html()
{
	$value = get_option( 'SC_zoho_client_id', '' );
	echo '<input size="50" type="text" id="SC_zoho_client_id" name="SC_zoho_client_id" value="' . $value . '" />';
}
public function SC_zoho_client_secre_html()
{
	$value = get_option( 'SC_zoho_client_secret', '' );
	echo '<input size="50" type="text" id="SC_zoho_client_secret" name="SC_zoho_client_secret" value="' . $value . '" />';
}
public function SC_zoho_refresh_token_html()
{
	$value = get_option( 'SC_zoho_refresh_token', '' );
	echo '<input size="50" type="text" id="SC_zoho_refresh_token" name="SC_zoho_refresh_token" value="' . $value . '" />';
}

public function SC_access_token_token_html()
{
	$value = get_option( 'SC_access_token_token', '' );
	echo '<input size="50" type="text" id="SC_access_token_token" name="SC_access_token_token" value="' . $value . '" />';
}
public function SC_zoho_account_assign_to_html()

{

    $value = get_option( 'SC_zoho_account_assign_to', '' );
    echo '<input size="50" type="text" id="SC_zoho_account_assign_to" name="SC_zoho_account_assign_to" value="' . $value . '" />';

}

public function SC_max_image_length_to_html()

{

    $value = get_option( 'SC_max_image_length', '' );
    echo '<input type="number" id="SC_max_image_length" name="SC_max_image_length" value="' . $value . '" />';

}
public function SC_max_image_size_to_html()

{

    $value = get_option( 'SC_max_image_size', '' );
    echo '<input type="number" id="SC_max_image_size" name="SC_max_image_size" value="' . $value . '" />';

}
	
}
